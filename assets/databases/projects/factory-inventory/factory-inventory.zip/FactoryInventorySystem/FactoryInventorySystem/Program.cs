// Program.cs
// Factory Inventory Management System — Windows Forms app (.NET 8, C#).
// Entry point: starts the application and opens MainForm.
// Target: .NET 8, Windows Forms. Needs the Microsoft.Data.SqlClient
// NuGet package (see FactoryInventorySystem.csproj).

using System;
using System.Windows.Forms;

namespace FactoryInventorySystem
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new MainForm());
        }
    }
}
