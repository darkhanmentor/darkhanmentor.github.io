// MainForm.cs
// Factory Inventory Management System — main window.
// Shows all products in a grid and lets the user add, update, delete and
// search products. The four query buttons at the bottom run the practical
// queries from the project (low stock alert, supplier-wise orders, stock
// value, orders this month) and show the result in the same grid.
// All database work goes through DatabaseHelper, and every value typed
// by the user is passed as a parameter — never joined into the SQL text.

using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace FactoryInventorySystem
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            LoadProducts();
        }

        // Show all products in the grid.
        private void LoadProducts()
        {
            try
            {
                DataTable products = DatabaseHelper.GetDataTable(
                    "SELECT ProductId, ProductName, Category, UnitPrice, ReorderLevel " +
                    "FROM Products ORDER BY ProductId;");
                dgvProducts.DataSource = products;
                lblStatus.Text = products.Rows.Count + " products loaded.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not load products. Check that FactoryDB exists " +
                    "and the connection string is correct.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // When a grid row is clicked, copy its values into the fields.
        private void dgvProducts_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
            {
                return;
            }

            DataGridViewRow row = dgvProducts.Rows[e.RowIndex];
            txtProductId.Text = row.Cells["ProductId"].Value.ToString();
            txtProductName.Text = row.Cells["ProductName"].Value.ToString();
            txtCategory.Text = row.Cells["Category"].Value.ToString();
            txtUnitPrice.Text = row.Cells["UnitPrice"].Value.ToString();
            txtReorderLevel.Text = row.Cells["ReorderLevel"].Value.ToString();
        }

        // Read the form fields. Returns false and shows a message if
        // anything is missing or in the wrong format.
        private bool ReadFields(out string name, out string category,
            out decimal unitPrice, out int reorderLevel)
        {
            name = txtProductName.Text.Trim();
            category = txtCategory.Text.Trim();
            unitPrice = 0m;
            reorderLevel = 0;

            if (name == "" || category == "")
            {
                MessageBox.Show("Product name and category are required.",
                    "Missing data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!decimal.TryParse(txtUnitPrice.Text.Trim(), out unitPrice) || unitPrice < 0)
            {
                MessageBox.Show("Unit price must be a number, for example 1200.",
                    "Wrong data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!int.TryParse(txtReorderLevel.Text.Trim(), out reorderLevel) || reorderLevel < 0)
            {
                MessageBox.Show("Reorder level must be a whole number, for example 50.",
                    "Wrong data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!ReadFields(out string name, out string category,
                out decimal unitPrice, out int reorderLevel))
            {
                return;
            }

            try
            {
                string sql = "INSERT INTO Products (ProductName, Category, UnitPrice, ReorderLevel) " +
                    "VALUES (@Name, @Category, @Price, @Reorder);";
                int rows = DatabaseHelper.ExecuteNonQuery(sql,
                    new SqlParameter("@Name", name),
                    new SqlParameter("@Category", category),
                    new SqlParameter("@Price", unitPrice),
                    new SqlParameter("@Reorder", reorderLevel));
                lblStatus.Text = "Product added. Rows affected: " + rows;
                ClearFields();
                LoadProducts();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not add the product.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtProductId.Text.Trim() == "")
            {
                MessageBox.Show("Click a product in the grid first, then change its details.",
                    "No product selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!ReadFields(out string name, out string category,
                out decimal unitPrice, out int reorderLevel))
            {
                return;
            }

            try
            {
                string sql = "UPDATE Products SET ProductName = @Name, Category = @Category, " +
                    "UnitPrice = @Price, ReorderLevel = @Reorder WHERE ProductId = @Id;";
                int rows = DatabaseHelper.ExecuteNonQuery(sql,
                    new SqlParameter("@Name", name),
                    new SqlParameter("@Category", category),
                    new SqlParameter("@Price", unitPrice),
                    new SqlParameter("@Reorder", reorderLevel),
                    new SqlParameter("@Id", int.Parse(txtProductId.Text.Trim())));
                lblStatus.Text = "Product updated. Rows affected: " + rows;
                ClearFields();
                LoadProducts();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not update the product.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (txtProductId.Text.Trim() == "")
            {
                MessageBox.Show("Click a product in the grid first.",
                    "No product selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult answer = MessageBox.Show(
                "Delete product '" + txtProductName.Text.Trim() + "'? " +
                "A product that has stock or order details cannot be deleted.",
                "Delete product", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer != DialogResult.Yes)
            {
                return;
            }

            try
            {
                string sql = "DELETE FROM Products WHERE ProductId = @Id;";
                int rows = DatabaseHelper.ExecuteNonQuery(sql,
                    new SqlParameter("@Id", int.Parse(txtProductId.Text.Trim())));
                lblStatus.Text = "Product deleted. Rows affected: " + rows;
                ClearFields();
                LoadProducts();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not delete the product. A product that has a stock " +
                    "row or order details cannot be deleted, because the Stock and " +
                    "OrderDetails tables refer to it. Delete those rows first.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearFields();
            LoadProducts();
        }

        private void ClearFields()
        {
            txtProductId.Text = "";
            txtProductName.Text = "";
            txtCategory.Text = "";
            txtUnitPrice.Text = "";
            txtReorderLevel.Text = "";
        }

        // Search by product name or category. Typing "Textiles" finds the
        // 1 product in the Textiles category (Cotton Fabric).
        private void btnSearch_Click(object sender, EventArgs e)
        {
            string keyword = txtSearch.Text.Trim();
            if (keyword == "")
            {
                LoadProducts();
                return;
            }

            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT ProductId, ProductName, Category, UnitPrice, ReorderLevel " +
                    "FROM Products " +
                    "WHERE ProductName LIKE @Q OR Category LIKE @Q " +
                    "ORDER BY ProductId;",
                    new SqlParameter("@Q", "%" + keyword + "%"));
                dgvProducts.DataSource = result;
                lblStatus.Text = result.Rows.Count + " products found for '" + keyword + "'.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Search failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadProducts();
        }

        // Query 1: low stock alert — products whose stock is at or below
        // the reorder level. Expected result: 3 products — Cotton Fabric
        // (40 < 50), Plastic Bottles (450 < 500), Office Chairs (8 < 10).
        private void btnLowStock_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT p.ProductId, p.ProductName, p.Category, p.UnitPrice, " +
                    "p.ReorderLevel, s.QuantityInStock " +
                    "FROM Products p " +
                    "INNER JOIN Stock s ON s.ProductId = p.ProductId " +
                    "WHERE s.QuantityInStock <= p.ReorderLevel " +
                    "ORDER BY p.ProductName;");
                dgvProducts.DataSource = result;
                lblStatus.Text = "Low stock alert: " + result.Rows.Count + " products at or below reorder level.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Query 2: supplier-wise orders — orders and total amount per supplier.
        // Expected result: Ali Traders 2 orders, 165500; Bilal Supplies
        // 1 order, 225000; Chenab Industries 1 order, 25000;
        // Ravi Enterprises 0 orders, 0.
        private void btnSupplierOrders_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT s.SupplierName, COUNT(o.OrderId) AS TotalOrders, " +
                    "ISNULL(SUM(o.TotalAmount), 0) AS TotalAmount " +
                    "FROM Suppliers s " +
                    "LEFT JOIN Orders o ON o.SupplierId = s.SupplierId " +
                    "GROUP BY s.SupplierName ORDER BY TotalAmount DESC;");
                dgvProducts.DataSource = result;
                lblStatus.Text = "Supplier-wise orders.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Query 3: stock value per product (QuantityInStock x UnitPrice).
        // Expected result: Cotton Fabric 48000, Steel Rods 540000,
        // Plastic Bottles 11250, Wheat Flour 54000, Office Chairs 68000,
        // Soap Bars 47500. Grand total 768750.
        private void btnStockValue_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT p.ProductName, s.QuantityInStock, p.UnitPrice, " +
                    "s.QuantityInStock * p.UnitPrice AS StockValue " +
                    "FROM Products p " +
                    "INNER JOIN Stock s ON s.ProductId = p.ProductId " +
                    "ORDER BY StockValue DESC;");
                dgvProducts.DataSource = result;
                lblStatus.Text = "Stock value per product. Grand total: 768750.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Query 4: orders in November 2026. Expected result: 4 orders.
        private void btnOrdersThisMonth_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT o.OrderId, s.SupplierName, o.OrderDate, o.TotalAmount, o.Status " +
                    "FROM Orders o " +
                    "INNER JOIN Suppliers s ON o.SupplierId = s.SupplierId " +
                    "WHERE o.OrderDate >= '2026-11-01' AND o.OrderDate < '2026-12-01' " +
                    "ORDER BY o.OrderDate;");
                dgvProducts.DataSource = result;
                lblStatus.Text = "Orders in November 2026: " + result.Rows.Count + " orders.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
