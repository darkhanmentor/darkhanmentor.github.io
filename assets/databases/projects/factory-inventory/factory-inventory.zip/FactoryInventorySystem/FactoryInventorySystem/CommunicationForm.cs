// CommunicationForm.cs
// Factory Inventory Management System — SMS / WhatsApp window.
// Lets the user send a message to one phone number, or to a whole
// contact group (for example "All Suppliers"), by SMS (Twilio) or by
// WhatsApp (official WhatsApp Business Cloud API). The "Open WhatsApp
// chat" button opens a wa.me link in the browser — that needs no
// account at all. MainForm opens this window, and the low-stock alert
// button on MainForm opens it already filled in (see Prefill).
// Errors are always shown in lblStatus and in a message box —
// never swallowed silently.

using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace FactoryInventorySystem
{
    public partial class CommunicationForm : Form
    {
        // The groups from CommunicationService, in the same order as
        // the names shown in cmbGroup (after the "Single number" entry).
        private List<ContactGroup> groups = new List<ContactGroup>();

        public CommunicationForm()
        {
            InitializeComponent();
        }

        private void CommunicationForm_Load(object sender, EventArgs e)
        {
            rdoSms.Checked = true;
            cmbGroup.Items.Clear();
            cmbGroup.Items.Add("Single number");
            try
            {
                groups = CommunicationService.GetContactGroups();
                foreach (ContactGroup group in groups)
                {
                    cmbGroup.Items.Add(group.Name + " (" + group.Phones.Count + " numbers)");
                }
            }
            catch (Exception ex)
            {
                // The database is not reachable: groups cannot be
                // listed, but sending to a single typed number still
                // works, so the form stays open and the error is shown.
                lblStatus.Text = "Could not load contact groups: " + ex.Message;
            }
            cmbGroup.SelectedIndex = 0;
        }

        // Fill the form in from another form — for example MainForm's
        // low-stock alert button, which passes the supplier's phone
        // and the alert message. Pass "" for toPhone when there is no
        // number yet; the user types it in.
        public void Prefill(string toPhone, string message)
        {
            cmbGroup.SelectedIndex = 0;
            txtTo.Text = toPhone == null ? "" : toPhone;
            txtMessage.Text = message == null ? "" : message;
        }

        private void cmbGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            // A group is selected (index 0 is "Single number"): the
            // message goes to the whole group, so the single number
            // box is not needed.
            txtTo.Enabled = cmbGroup.SelectedIndex == 0;
            if (cmbGroup.SelectedIndex > 0)
            {
                lblStatus.Text = "Message will go to the whole group: "
                    + groups[cmbGroup.SelectedIndex - 1].Name + ".";
            }
            else
            {
                lblStatus.Text = "Ready.";
            }
        }

        // The group chosen in cmbGroup, or null for "Single number".
        private ContactGroup SelectedGroup()
        {
            if (cmbGroup.SelectedIndex <= 0)
            {
                return null;
            }
            return groups[cmbGroup.SelectedIndex - 1];
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            string message = txtMessage.Text.Trim();
            if (message == "")
            {
                MessageBox.Show("Type a message first.",
                    "Missing message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string result;
                ContactGroup group = SelectedGroup();
                if (rdoSms.Checked)
                {
                    if (group != null)
                    {
                        result = CommunicationService.SendSmsToGroup(group, message);
                    }
                    else
                    {
                        string sid = CommunicationService.SendSms(txtTo.Text.Trim(), message);
                        result = "SMS sent. Twilio message SID: " + sid;
                    }
                }
                else
                {
                    if (group != null)
                    {
                        result = CommunicationService.SendWhatsAppToGroup(group, null);
                    }
                    else
                    {
                        string id = CommunicationService.SendWhatsAppTemplate(txtTo.Text.Trim(), null);
                        result = "WhatsApp message sent. Message ID: " + id;
                    }
                }
                lblStatus.Text = result;
                MessageBox.Show(result, "Sent", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Error: " + ex.Message;
                MessageBox.Show("Could not send the message.\n\n" + ex.Message,
                    "Could not send", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnWhatsAppChat_Click(object sender, EventArgs e)
        {
            try
            {
                string url = CommunicationService.OpenWhatsAppChat(txtTo.Text.Trim(), txtMessage.Text.Trim());
                lblStatus.Text = "WhatsApp chat opened in the browser.";
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Error: " + ex.Message;
                MessageBox.Show("Could not open WhatsApp chat.\n\n" + ex.Message,
                    "Could not open chat", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
