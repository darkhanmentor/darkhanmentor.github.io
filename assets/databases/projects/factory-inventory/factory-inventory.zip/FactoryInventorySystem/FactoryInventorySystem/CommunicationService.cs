// CommunicationService.cs
// Factory Inventory Management System — SMS and WhatsApp sending.
//
// Two channels, both through official services:
//   SMS       — Twilio (NuGet package Twilio, version 7.14.9).
//               TwilioClient.Init(sid, token), then MessageResource.Create.
//   WhatsApp  — the OFFICIAL WhatsApp Business Cloud API (Meta Graph API
//               v26.0): an HttpClient POST to
//               https://graph.facebook.com/v26.0/<phoneNumberId>/messages
//               with a Bearer access token and a template message.
//   wa.me link — a click-to-chat link (https://wa.me/<digits>?text=...)
//               opened in the browser with Process.Start. This needs no
//               account at all — it simply opens WhatsApp.
//
// All secrets come from App.config (appSettings). The values shipped in
// App.config are PLACEHOLDERS ONLY — put your own account details there
// before sending anything. Never put a real SID, token or phone number
// in source code.
//
// WhatsApp groups: the official WhatsApp API cannot create WhatsApp
// groups — groups are created in the WhatsApp app itself. What this
// class does is manage CONTACT groups inside the software (for example
// "All Suppliers") and send a message to each contact in the group,
// one by one, through the official WhatsApp Business API.
//
// Phone numbers: the sample data stores local Pakistani numbers such
// as 0300-1111111. Before sending, a number is normalised — spaces,
// dashes and brackets are removed, and a leading 0 is replaced with
// the Pakistan country code +92 — and only then checked: it must start
// with "+" and the rest must be digits. Anything else throws an
// ArgumentException with a plain message.
//
// Uses: Twilio 7.14.9, System.Configuration.ConfigurationManager 8.0.1
// (see FactoryInventorySystem.csproj).

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

namespace FactoryInventorySystem
{
    /// <summary>
    /// One contact group: a name the user sees, and the phone numbers
    /// in it. Groups live inside the software only — they are NOT
    /// WhatsApp groups (the official WhatsApp API cannot create those).
    /// </summary>
    public class ContactGroup
    {
        public string Name { get; set; }
        public List<string> Phones { get; set; }

        public ContactGroup(string name)
        {
            Name = name;
            Phones = new List<string>();
        }

        public override string ToString()
        {
            return Name;
        }
    }

    public static class CommunicationService
    {
        // Graph API version pinned in one place. v26.0 is the current
        // version (released 29 July 2026). When Meta releases a newer
        // version, change this one line and re-test.
        private const string GraphApiVersion = "v26.0";

        // Placeholder values shipped in App.config. A setting that
        // still holds one of these means "not configured yet".
        private const string TwilioSidPlaceholder = "ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
        private const string TwilioTokenPlaceholder = "YOUR_TWILIO_AUTH_TOKEN";
        private const string TwilioFromPlaceholder = "+10000000000";
        private const string WhatsAppIdPlaceholder = "YOUR_WHATSAPP_PHONE_NUMBER_ID";
        private const string WhatsAppTokenPlaceholder = "YOUR_WHATSAPP_ACCESS_TOKEN";
        private const string DefaultTemplateName = "hello_world";

        private static string Setting(string key)
        {
            string value = ConfigurationManager.AppSettings[key];
            return value == null ? "" : value.Trim();
        }

        private static string TwilioAccountSid
        {
            get { return Setting("TwilioAccountSid"); }
        }

        private static string TwilioAuthToken
        {
            get { return Setting("TwilioAuthToken"); }
        }

        private static string TwilioFromNumber
        {
            get { return Setting("TwilioFromNumber"); }
        }

        private static string WhatsAppPhoneNumberId
        {
            get { return Setting("WhatsAppPhoneNumberId"); }
        }

        private static string WhatsAppAccessToken
        {
            get { return Setting("WhatsAppAccessToken"); }
        }

        private static string WhatsAppTemplateName
        {
            get
            {
                string name = Setting("WhatsAppTemplateName");
                return name == "" ? DefaultTemplateName : name;
            }
        }

        /// <summary>
        /// True only when the Twilio settings in App.config hold real
        /// values, not the shipped placeholders.
        /// </summary>
        public static bool IsTwilioConfigured
        {
            get
            {
                return TwilioAccountSid != ""
                    && TwilioAccountSid != TwilioSidPlaceholder
                    && TwilioAuthToken != ""
                    && TwilioAuthToken != TwilioTokenPlaceholder
                    && TwilioFromNumber != ""
                    && TwilioFromNumber != TwilioFromPlaceholder;
            }
        }

        /// <summary>
        /// True only when the WhatsApp settings in App.config hold real
        /// values, not the shipped placeholders.
        /// </summary>
        public static bool IsWhatsAppConfigured
        {
            get
            {
                return WhatsAppPhoneNumberId != ""
                    && WhatsAppPhoneNumberId != WhatsAppIdPlaceholder
                    && WhatsAppAccessToken != ""
                    && WhatsAppAccessToken != WhatsAppTokenPlaceholder;
            }
        }

        // Normalise a phone number for sending: remove spaces, dashes
        // and brackets, and turn a local Pakistani number (0300...)
        // into international form (+92300...). Then check it: it must
        // start with "+" and the rest must be digits.
        private static string NormalisePhone(string phone)
        {
            if (phone == null || phone.Trim() == "")
            {
                throw new ArgumentException("Phone number is empty. Type a phone number first.");
            }

            string cleaned = phone.Trim()
                .Replace(" ", "")
                .Replace("-", "")
                .Replace("(", "")
                .Replace(")", "");

            if (cleaned.StartsWith("0"))
            {
                // Local Pakistani number, for example 0300-1111111.
                cleaned = "+92" + cleaned.Substring(1);
            }

            if (!cleaned.StartsWith("+"))
            {
                throw new ArgumentException("Phone number must start with + and the country code, for example +92 for Pakistan.");
            }

            for (int i = 1; i < cleaned.Length; i++)
            {
                if (!char.IsDigit(cleaned[i]))
                {
                    throw new ArgumentException("Phone number must contain only digits after the + sign.");
                }
            }

            return cleaned;
        }

        // Digits only, for the wa.me link (no + sign, no spaces).
        private static string DigitsOnly(string phone)
        {
            string normalised = NormalisePhone(phone);
            StringBuilder digits = new StringBuilder();
            foreach (char c in normalised)
            {
                if (char.IsDigit(c))
                {
                    digits.Append(c);
                }
            }
            return digits.ToString();
        }

        /// <summary>
        /// Send one SMS through Twilio. Returns the Twilio message SID.
        /// Throws InvalidOperationException if Twilio is not configured
        /// in App.config, and ArgumentException for a bad phone number.
        /// </summary>
        public static string SendSms(string to, string message)
        {
            string toNumber = NormalisePhone(to);

            if (message == null || message.Trim() == "")
            {
                throw new ArgumentException("Message is empty. Type a message first.");
            }

            if (!IsTwilioConfigured)
            {
                throw new InvalidOperationException(
                    "Twilio is not configured. Open App.config and put your own " +
                    "Twilio account SID, auth token and Twilio phone number in " +
                    "TwilioAccountSid, TwilioAuthToken and TwilioFromNumber. " +
                    "See SETUP-GUIDE.txt, \"SMS AND WHATSAPP SETUP\".");
            }

            TwilioClient.Init(TwilioAccountSid, TwilioAuthToken);
            MessageResource sent = MessageResource.Create(
                to: new PhoneNumber(toNumber),
                from: new PhoneNumber(TwilioFromNumber),
                body: message);
            return sent.Sid;
        }

        /// <summary>
        /// Send one WhatsApp template message through the official
        /// WhatsApp Business Cloud API (Graph API v26.0). Returns the
        /// WhatsApp message ID. Throws InvalidOperationException if
        /// WhatsApp is not configured in App.config, and
        /// ArgumentException for a bad phone number.
        /// </summary>
        public static string SendWhatsAppTemplate(string to, string templateName)
        {
            string toNumber = NormalisePhone(to);

            if (!IsWhatsAppConfigured)
            {
                throw new InvalidOperationException(
                    "WhatsApp is not configured. Open App.config and put your own " +
                    "WhatsApp Business phone number ID and access token in " +
                    "WhatsAppPhoneNumberId and WhatsAppAccessToken. " +
                    "See SETUP-GUIDE.txt, \"SMS AND WHATSAPP SETUP\".");
            }

            string template = templateName == null || templateName.Trim() == ""
                ? WhatsAppTemplateName
                : templateName.Trim();

            string url = "https://graph.facebook.com/" + GraphApiVersion + "/"
                + WhatsAppPhoneNumberId + "/messages";

            string json = JsonSerializer.Serialize(new
            {
                messaging_product = "whatsapp",
                to = toNumber,
                type = "template",
                template = new
                {
                    name = template,
                    language = new { code = "en_US" }
                }
            });

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + WhatsAppAccessToken);
                using (HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, url))
                {
                    request.Content = new StringContent(json, Encoding.UTF8, "application/json");
                    // HttpClient.Send is synchronous on purpose: the form
                    // calls this on the UI thread, and awaiting here could
                    // deadlock. The call blocks until Meta replies.
                    using (HttpResponseMessage response = client.Send(request))
                    {
                        string body = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                        if (!response.IsSuccessStatusCode)
                        {
                            throw new InvalidOperationException(
                                "WhatsApp send failed (" + (int)response.StatusCode + " " + response.ReasonPhrase + "). " + body);
                        }

                        // The reply looks like {"messages":[{"id":"wamid...."}]}.
                        try
                        {
                            using (JsonDocument doc = JsonDocument.Parse(body))
                            {
                                JsonElement root = doc.RootElement;
                                JsonElement messages = root.GetProperty("messages");
                                return messages[0].GetProperty("id").GetString();
                            }
                        }
                        catch (Exception)
                        {
                            return body;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Open a WhatsApp chat with the number in the browser
        /// (wa.me click-to-chat link). Needs no account at all — it
        /// simply opens WhatsApp with the message already typed.
        /// Returns the link that was opened.
        /// </summary>
        public static string OpenWhatsAppChat(string to, string message)
        {
            string digits = DigitsOnly(to);
            string url = "https://wa.me/" + digits
                + "?text=" + Uri.EscapeDataString(message == null ? "" : message);
            Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
            return url;
        }

        /// <summary>
        /// The contact groups inside the software. "All Suppliers"
        /// reads every supplier phone number from the Suppliers table.
        /// Add more groups here when the project grows.
        /// </summary>
        public static List<ContactGroup> GetContactGroups()
        {
            List<ContactGroup> groups = new List<ContactGroup>();

            ContactGroup suppliers = new ContactGroup("All Suppliers");
            DataTable phones = DatabaseHelper.GetDataTable(
                "SELECT Phone FROM Suppliers WHERE Phone IS NOT NULL AND Phone <> '';");
            foreach (DataRow row in phones.Rows)
            {
                string phone = row["Phone"] == null ? "" : row["Phone"].ToString().Trim();
                if (phone != "")
                {
                    suppliers.Phones.Add(phone);
                }
            }
            groups.Add(suppliers);

            return groups;
        }

        /// <summary>
        /// Send one SMS to every member of the group. Returns a short
        /// result string with the sent count and any failures, for
        /// example "SMS sent to 4 of 4 suppliers." Errors are reported
        /// per member — never swallowed silently.
        /// </summary>
        public static string SendSmsToGroup(ContactGroup group, string message)
        {
            if (group == null || group.Phones.Count == 0)
            {
                return "No phone numbers in the group '" + (group == null ? "" : group.Name) + "'.";
            }

            int sent = 0;
            List<string> failures = new List<string>();
            foreach (string phone in group.Phones)
            {
                try
                {
                    SendSms(phone, message);
                    sent++;
                }
                catch (Exception ex)
                {
                    failures.Add(phone + ": " + ex.Message);
                }
            }

            string result = "SMS sent to " + sent + " of " + group.Phones.Count
                + " in '" + group.Name + "'.";
            if (failures.Count > 0)
            {
                result += " Failed: " + string.Join("; ", failures);
            }
            return result;
        }

        /// <summary>
        /// Send one WhatsApp template message to every member of the
        /// group. Returns a short result string with the sent count
        /// and any failures. The template name comes from App.config
        /// (WhatsAppTemplateName, default "hello_world") when empty.
        /// </summary>
        public static string SendWhatsAppToGroup(ContactGroup group, string templateName)
        {
            if (group == null || group.Phones.Count == 0)
            {
                return "No phone numbers in the group '" + (group == null ? "" : group.Name) + "'.";
            }

            int sent = 0;
            List<string> failures = new List<string>();
            foreach (string phone in group.Phones)
            {
                try
                {
                    SendWhatsAppTemplate(phone, templateName);
                    sent++;
                }
                catch (Exception ex)
                {
                    failures.Add(phone + ": " + ex.Message);
                }
            }

            string result = "WhatsApp sent to " + sent + " of " + group.Phones.Count
                + " in '" + group.Name + "'.";
            if (failures.Count > 0)
            {
                result += " Failed: " + string.Join("; ", failures);
            }
            return result;
        }
    }
}
