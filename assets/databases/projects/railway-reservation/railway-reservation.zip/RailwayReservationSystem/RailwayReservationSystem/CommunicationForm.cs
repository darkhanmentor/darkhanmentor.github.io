// CommunicationForm.cs
// Railway Reservation System — SMS / WhatsApp window.
// Sends a message by SMS (Twilio) or WhatsApp (official WhatsApp
// Business Cloud API) to one number or to a whole contact group
// (for example "All Passengers", read from the Passengers table).
// The "Open WhatsApp Chat" button needs no account: it opens a wa.me
// link, so WhatsApp opens with the message already typed.
// Errors are always shown in the status label and a message box —
// they are never swallowed silently.

using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace RailwayReservationSystem
{
    public partial class CommunicationForm : Form
    {
        private List<ContactGroup> groups = new List<ContactGroup>();

        public CommunicationForm()
        {
            InitializeComponent();
        }

        private void CommunicationForm_Load(object sender, EventArgs e)
        {
            rdoSms.Checked = true;
            LoadGroups();
        }

        // Fill the group drop-down: "Single number" first, then the
        // contact groups from CommunicationService.GetContactGroups().
        private void LoadGroups()
        {
            try
            {
                groups = CommunicationService.GetContactGroups();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not load contact groups from the database.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                groups = new List<ContactGroup>();
            }

            cmbGroup.Items.Clear();
            cmbGroup.Items.Add("Single number");
            foreach (ContactGroup group in groups)
            {
                cmbGroup.Items.Add(group.ToString());
            }
            cmbGroup.SelectedIndex = 0;
        }

        // True when a real contact group (not "Single number") is chosen.
        private ContactGroup SelectedGroup()
        {
            if (cmbGroup.SelectedIndex <= 0)
            {
                return null;
            }
            return groups[cmbGroup.SelectedIndex - 1];
        }

        // Fill the form from another screen — for example MainForm's
        // "Send ticket confirmation" button, which passes the
        // passenger's phone number and the ticket message.
        public void Prefill(string toPhone, string message)
        {
            cmbGroup.SelectedIndex = 0;
            txtTo.Text = toPhone ?? "";
            txtMessage.Text = message ?? "";
        }

        private void cmbGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            ContactGroup group = SelectedGroup();
            txtTo.Enabled = (group == null);
            if (group != null)
            {
                lblStatus.Text = "Will send to " + group.Phones.Count
                    + " contacts in '" + group.Name + "'.";
            }
            else
            {
                lblStatus.Text = "Type one phone number, for example +923001234567.";
            }
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            ContactGroup group = SelectedGroup();
            try
            {
                string result;
                if (rdoSms.Checked)
                {
                    if (group != null)
                    {
                        result = CommunicationService.SendSmsToGroup(group, txtMessage.Text.Trim());
                    }
                    else
                    {
                        result = CommunicationService.SendSms(txtTo.Text.Trim(), txtMessage.Text.Trim());
                    }
                }
                else
                {
                    if (group != null)
                    {
                        result = CommunicationService.SendWhatsAppToGroup(group, null);
                    }
                    else
                    {
                        result = CommunicationService.SendWhatsAppTemplate(txtTo.Text.Trim(), null);
                    }
                }
                lblStatus.Text = result;
                MessageBox.Show(result, "Message sent", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Failed: " + ex.Message;
                MessageBox.Show(ex.Message, "Could not send", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnWhatsAppChat_Click(object sender, EventArgs e)
        {
            try
            {
                string result = CommunicationService.OpenWhatsAppChat(txtTo.Text.Trim(), txtMessage.Text.Trim());
                lblStatus.Text = result;
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Failed: " + ex.Message;
                MessageBox.Show(ex.Message, "Could not open WhatsApp", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
