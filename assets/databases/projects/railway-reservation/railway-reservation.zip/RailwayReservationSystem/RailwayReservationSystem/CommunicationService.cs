// CommunicationService.cs
// Railway Reservation System — SMS and WhatsApp sending.
//
// SMS goes through Twilio (NuGet package Twilio, version 7.14.9).
// WhatsApp goes through the OFFICIAL WhatsApp Business Cloud API
// (Meta Graph API, version v26.0) — an HttpClient POST to
// https://graph.facebook.com/v26.0/<phone-number-id>/messages.
// A third option needs no account at all: a wa.me click-to-chat link
// (https://wa.me/<digits>?text=...) simply opens WhatsApp.
//
// All secrets come from App.config (appSettings). The values shipped
// in App.config are PLACEHOLDERS ONLY — put your own Twilio and
// WhatsApp Business account details there before sending anything.
// Nothing is sent until you do: SendSms / SendWhatsAppTemplate throw
// an InvalidOperationException if the account is not configured.
//
// Phone numbers: Twilio and WhatsApp both want the international
// format, for example +923001234567. Numbers stored in the database
// are in the local Pakistani format (0300-1234567), so NormalizePhone
// converts a leading 0 to +92 (and a leading 00 to +) before the
// number is validated. A number that still does not start with "+"
// and contain only digits after it is rejected with ArgumentException.
//
// IMPORTANT — WhatsApp groups: no software can create a WhatsApp
// group through the official API. Groups are created in the WhatsApp
// app itself. What this service does is manage CONTACT groups inside
// the program (for example "All Passengers", read from the Passengers
// table) and send a message to each member of the group, one by one,
// through the official WhatsApp Business API.

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

namespace RailwayReservationSystem
{
    /// <summary>A contact group kept inside the program: a name and its phone numbers.</summary>
    public class ContactGroup
    {
        public string Name { get; set; }
        public List<string> Phones { get; set; }

        public ContactGroup(string name)
        {
            Name = name;
            Phones = new List<string>();
        }

        public override string ToString()
        {
            return Name + " (" + Phones.Count + " contacts)";
        }
    }

    /// <summary>Sends SMS (Twilio) and WhatsApp messages (official Cloud API).</summary>
    public static class CommunicationService
    {
        // Graph API version used for the WhatsApp Cloud API calls.
        // v26.0 is the current version (released 29 July 2026).
        private const string GraphApiVersion = "v26.0";

        // Placeholder values shipped in App.config. A setting still
        // holding one of these means "not configured yet".
        private const string TwilioSidPlaceholder = "ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
        private const string TwilioTokenPlaceholder = "YOUR_TWILIO_AUTH_TOKEN";
        private const string TwilioFromPlaceholder = "+10000000000";
        private const string WhatsAppIdPlaceholder = "YOUR_WHATSAPP_PHONE_NUMBER_ID";
        private const string WhatsAppTokenPlaceholder = "YOUR_WHATSAPP_ACCESS_TOKEN";

        private static string Setting(string key)
        {
            return (ConfigurationManager.AppSettings[key] ?? "").Trim();
        }

        private static string TwilioSid { get { return Setting("TwilioAccountSid"); } }
        private static string TwilioToken { get { return Setting("TwilioAuthToken"); } }
        private static string TwilioFrom { get { return Setting("TwilioFromNumber"); } }
        private static string WhatsAppPhoneNumberId { get { return Setting("WhatsAppPhoneNumberId"); } }
        private static string WhatsAppToken { get { return Setting("WhatsAppAccessToken"); } }
        private static string WhatsAppTemplate { get { return Setting("WhatsAppTemplateName"); } }

        /// <summary>True when a real Twilio SID, token and sender number are in App.config.</summary>
        public static bool IsTwilioConfigured
        {
            get
            {
                return TwilioSid != "" && TwilioSid != TwilioSidPlaceholder
                    && TwilioToken != "" && TwilioToken != TwilioTokenPlaceholder
                    && TwilioFrom != "" && TwilioFrom != TwilioFromPlaceholder;
            }
        }

        /// <summary>True when a real WhatsApp phone number ID and access token are in App.config.</summary>
        public static bool IsWhatsAppConfigured
        {
            get
            {
                return WhatsAppPhoneNumberId != "" && WhatsAppPhoneNumberId != WhatsAppIdPlaceholder
                    && WhatsAppToken != "" && WhatsAppToken != WhatsAppTokenPlaceholder;
            }
        }

        /// <summary>
        /// Normalises a phone number to international format: spaces and
        /// dashes are removed, a leading 00 becomes +, and a leading 0
        /// (Pakistani local format, for example 0300-1234567) becomes +92.
        /// </summary>
        public static string NormalizePhone(string phone)
        {
            if (phone == null)
            {
                return "";
            }
            string digits = phone.Trim().Replace(" ", "").Replace("-", "");
            if (digits.StartsWith("00"))
            {
                digits = "+" + digits.Substring(2);
            }
            else if (digits.StartsWith("0"))
            {
                digits = "+92" + digits.Substring(1);
            }
            return digits;
        }

        /// <summary>
        /// Checks a phone number: it must start with "+" and the rest
        /// must be digits only. Throws ArgumentException otherwise.
        /// </summary>
        public static string ValidatePhone(string phone)
        {
            string normal = NormalizePhone(phone);
            if (normal.Length < 8 || !normal.StartsWith("+"))
            {
                throw new ArgumentException(
                    "Phone number must be in international format, for example +923001234567.");
            }
            for (int i = 1; i < normal.Length; i++)
            {
                if (!char.IsDigit(normal[i]))
                {
                    throw new ArgumentException(
                        "Phone number must be in international format, for example +923001234567.");
                }
            }
            return normal;
        }

        /// <summary>Sends one SMS through Twilio. Returns a short result string.</summary>
        public static string SendSms(string to, string message)
        {
            string toNumber = ValidatePhone(to);
            if (string.IsNullOrWhiteSpace(message))
            {
                throw new ArgumentException("Message text is empty. Type a message first.");
            }
            if (!IsTwilioConfigured)
            {
                throw new InvalidOperationException(
                    "Twilio is not configured. Put your own Twilio Account SID, Auth Token " +
                    "and Twilio phone number in App.config (see SETUP-GUIDE.txt, " +
                    "\"SMS AND WHATSAPP SETUP\") before sending an SMS.");
            }

            TwilioClient.Init(TwilioSid, TwilioToken);
            var sent = MessageResource.Create(
                to: new PhoneNumber(toNumber),
                from: new PhoneNumber(TwilioFrom),
                body: message);
            return "SMS sent to " + toNumber + " (SID " + sent.Sid + ").";
        }

        /// <summary>
        /// Sends one approved WhatsApp template message through the official
        /// WhatsApp Business Cloud API. Returns a short result string.
        /// </summary>
        public static string SendWhatsAppTemplate(string to, string templateName)
        {
            string toNumber = ValidatePhone(to);
            if (!IsWhatsAppConfigured)
            {
                throw new InvalidOperationException(
                    "WhatsApp is not configured. Put your own WhatsApp Phone Number ID " +
                    "and Access Token in App.config (see SETUP-GUIDE.txt, " +
                    "\"SMS AND WHATSAPP SETUP\") before sending a WhatsApp message.");
            }

            string template = string.IsNullOrWhiteSpace(templateName)
                ? (string.IsNullOrWhiteSpace(WhatsAppTemplate) ? "hello_world" : WhatsAppTemplate)
                : templateName.Trim();

            string url = "https://graph.facebook.com/" + GraphApiVersion + "/"
                + WhatsAppPhoneNumberId + "/messages";

            // WhatsApp wants the number without the leading "+".
            string json = JsonSerializer.Serialize(new
            {
                messaging_product = "whatsapp",
                to = toNumber.TrimStart('+'),
                type = "template",
                template = new
                {
                    name = template,
                    language = new { code = "en_US" }
                }
            });

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", WhatsAppToken);
                using (StringContent content = new StringContent(json, Encoding.UTF8, "application/json"))
                using (HttpResponseMessage response = client.PostAsync(url, content).GetAwaiter().GetResult())
                {
                    string body = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                    if (!response.IsSuccessStatusCode)
                    {
                        throw new InvalidOperationException(
                            "WhatsApp API returned " + (int)response.StatusCode + ": " + body);
                    }
                    return "WhatsApp template '" + template + "' sent to " + toNumber + ".";
                }
            }
        }

        /// <summary>
        /// Opens a WhatsApp chat with the number in the browser / WhatsApp
        /// app, with the message already typed. Needs no API account.
        /// </summary>
        public static string OpenWhatsAppChat(string to, string message)
        {
            string toNumber = ValidatePhone(to);
            string digits = toNumber.TrimStart('+');
            string link = "https://wa.me/" + digits
                + "?text=" + Uri.EscapeDataString(message ?? "");
            Process.Start(new ProcessStartInfo(link) { UseShellExecute = true });
            return "WhatsApp chat opened for " + toNumber + ".";
        }

        /// <summary>
        /// The contact groups kept inside the program. "All Passengers"
        /// is read live from the Passengers table (Phone column).
        /// </summary>
        public static List<ContactGroup> GetContactGroups()
        {
            List<ContactGroup> groups = new List<ContactGroup>();

            ContactGroup allPassengers = new ContactGroup("All Passengers");
            DataTable phones = DatabaseHelper.GetDataTable(
                "SELECT Phone FROM Passengers WHERE Phone IS NOT NULL AND Phone <> '';");
            foreach (DataRow row in phones.Rows)
            {
                string phone = (row["Phone"] == DBNull.Value) ? "" : row["Phone"].ToString().Trim();
                if (phone != "")
                {
                    allPassengers.Phones.Add(phone);
                }
            }
            groups.Add(allPassengers);

            return groups;
        }

        /// <summary>Sends an SMS to every member of a group. Returns sent count + failures.</summary>
        public static string SendSmsToGroup(ContactGroup group, string message)
        {
            if (group == null || group.Phones.Count == 0)
            {
                throw new ArgumentException("The group has no contacts to send to.");
            }
            int sent = 0;
            List<string> failures = new List<string>();
            foreach (string phone in group.Phones)
            {
                try
                {
                    SendSms(phone, message);
                    sent++;
                }
                catch (Exception ex)
                {
                    failures.Add(phone + ": " + ex.Message);
                }
            }
            string result = "SMS sent to " + sent + " of " + group.Phones.Count
                + " contacts in '" + group.Name + "'.";
            if (failures.Count > 0)
            {
                result += " Failed: " + failures.Count + " (" + string.Join("; ", failures) + ")";
            }
            return result;
        }

        /// <summary>Sends a WhatsApp template to every member of a group. Returns sent count + failures.</summary>
        public static string SendWhatsAppToGroup(ContactGroup group, string templateName)
        {
            if (group == null || group.Phones.Count == 0)
            {
                throw new ArgumentException("The group has no contacts to send to.");
            }
            int sent = 0;
            List<string> failures = new List<string>();
            foreach (string phone in group.Phones)
            {
                try
                {
                    SendWhatsAppTemplate(phone, templateName);
                    sent++;
                }
                catch (Exception ex)
                {
                    failures.Add(phone + ": " + ex.Message);
                }
            }
            string result = "WhatsApp sent to " + sent + " of " + group.Phones.Count
                + " contacts in '" + group.Name + "'.";
            if (failures.Count > 0)
            {
                result += " Failed: " + failures.Count + " (" + string.Join("; ", failures) + ")";
            }
            return result;
        }
    }
}
