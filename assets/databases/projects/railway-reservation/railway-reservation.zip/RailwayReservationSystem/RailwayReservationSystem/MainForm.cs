// MainForm.cs
// Railway Reservation System — main window.
// Shows all trains in a grid and lets the user add, update, delete and
// search trains. The four query buttons at the bottom run the practical
// queries from the project (seat availability, train schedule, passenger
// bookings, revenue per train) and show the result in the same grid.
// All database work goes through DatabaseHelper, and every value typed
// by the user is passed as a parameter — never joined into the SQL text.

using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace RailwayReservationSystem
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            LoadStations();
            LoadTrains();
        }

        // Fill both station drop-downs from the Stations table.
        private void LoadStations()
        {
            DataTable stations = DatabaseHelper.GetDataTable(
                "SELECT StationId, StationName FROM Stations ORDER BY StationName;");

            cmbSource.DataSource = stations;
            cmbSource.DisplayMember = "StationName";
            cmbSource.ValueMember = "StationId";

            // A second copy is needed because two controls cannot share
            // one DataTable as their DataSource.
            DataTable stationsCopy = stations.Copy();
            cmbDestination.DataSource = stationsCopy;
            cmbDestination.DisplayMember = "StationName";
            cmbDestination.ValueMember = "StationId";
        }

        // Show all trains with their station names in the grid.
        private void LoadTrains()
        {
            try
            {
                DataTable trains = DatabaseHelper.GetDataTable(
                    "SELECT t.TrainId, t.TrainName, t.TrainNumber, " +
                    "s1.StationName AS SourceStation, s2.StationName AS DestinationStation, " +
                    "t.DepartureTime, t.ArrivalTime, t.TotalSeats, t.FarePerSeat, " +
                    "t.SourceStationId, t.DestinationStationId " +
                    "FROM Trains t " +
                    "INNER JOIN Stations s1 ON t.SourceStationId = s1.StationId " +
                    "INNER JOIN Stations s2 ON t.DestinationStationId = s2.StationId " +
                    "ORDER BY t.TrainId;");
                dgvTrains.DataSource = trains;
                dgvTrains.Columns["SourceStationId"].Visible = false;
                dgvTrains.Columns["DestinationStationId"].Visible = false;
                lblStatus.Text = trains.Rows.Count + " trains loaded.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not load trains. Check that RailwayDB exists " +
                    "and the connection string is correct.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // When a grid row is clicked, copy its values into the fields.
        private void dgvTrains_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
            {
                return;
            }

            DataGridViewRow row = dgvTrains.Rows[e.RowIndex];
            txtTrainId.Text = row.Cells["TrainId"].Value.ToString();
            txtTrainName.Text = row.Cells["TrainName"].Value.ToString();
            txtTrainNumber.Text = row.Cells["TrainNumber"].Value.ToString();
            cmbSource.SelectedValue = row.Cells["SourceStationId"].Value;
            cmbDestination.SelectedValue = row.Cells["DestinationStationId"].Value;
            txtDeparture.Text = row.Cells["DepartureTime"].Value.ToString();
            txtArrival.Text = row.Cells["ArrivalTime"].Value.ToString();
            txtTotalSeats.Text = row.Cells["TotalSeats"].Value.ToString();
            txtFare.Text = row.Cells["FarePerSeat"].Value.ToString();
        }

        // Read the form fields. Returns false and shows a message if
        // anything is missing or in the wrong format.
        private bool ReadFields(out string name, out string number,
            out int sourceId, out int destinationId,
            out TimeSpan departure, out TimeSpan arrival,
            out int seats, out decimal fare)
        {
            name = txtTrainName.Text.Trim();
            number = txtTrainNumber.Text.Trim();
            sourceId = 0;
            destinationId = 0;
            departure = TimeSpan.Zero;
            arrival = TimeSpan.Zero;
            seats = 0;
            fare = 0m;

            if (name == "" || number == "")
            {
                MessageBox.Show("Train name and train number are required.",
                    "Missing data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (cmbSource.SelectedValue == null || cmbDestination.SelectedValue == null)
            {
                MessageBox.Show("Choose a source station and a destination station.",
                    "Missing data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            sourceId = (int)cmbSource.SelectedValue;
            destinationId = (int)cmbDestination.SelectedValue;

            if (sourceId == destinationId)
            {
                MessageBox.Show("Source and destination stations must be different.",
                    "Wrong data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!TimeSpan.TryParse(txtDeparture.Text.Trim(), out departure) ||
                !TimeSpan.TryParse(txtArrival.Text.Trim(), out arrival))
            {
                MessageBox.Show("Departure and arrival times must look like 08:00 or 17:30.",
                    "Wrong data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!int.TryParse(txtTotalSeats.Text.Trim(), out seats) || seats <= 0)
            {
                MessageBox.Show("Total seats must be a whole number above zero.",
                    "Wrong data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!decimal.TryParse(txtFare.Text.Trim(), out fare) || fare < 0)
            {
                MessageBox.Show("Fare must be a number, for example 4500.",
                    "Wrong data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!ReadFields(out string name, out string number,
                out int sourceId, out int destinationId,
                out TimeSpan departure, out TimeSpan arrival,
                out int seats, out decimal fare))
            {
                return;
            }

            try
            {
                string sql = "INSERT INTO Trains (TrainName, TrainNumber, SourceStationId, " +
                    "DestinationStationId, DepartureTime, ArrivalTime, TotalSeats, FarePerSeat) " +
                    "VALUES (@Name, @Number, @Source, @Destination, @Departure, @Arrival, @Seats, @Fare);";
                int rows = DatabaseHelper.ExecuteNonQuery(sql,
                    new SqlParameter("@Name", name),
                    new SqlParameter("@Number", number),
                    new SqlParameter("@Source", sourceId),
                    new SqlParameter("@Destination", destinationId),
                    new SqlParameter("@Departure", SqlDbType.Time) { Value = departure },
                    new SqlParameter("@Arrival", SqlDbType.Time) { Value = arrival },
                    new SqlParameter("@Seats", seats),
                    new SqlParameter("@Fare", fare));
                lblStatus.Text = "Train added. Rows affected: " + rows;
                ClearFields();
                LoadTrains();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not add the train.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtTrainId.Text.Trim() == "")
            {
                MessageBox.Show("Click a train in the grid first, then change its details.",
                    "No train selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!ReadFields(out string name, out string number,
                out int sourceId, out int destinationId,
                out TimeSpan departure, out TimeSpan arrival,
                out int seats, out decimal fare))
            {
                return;
            }

            try
            {
                string sql = "UPDATE Trains SET TrainName = @Name, TrainNumber = @Number, " +
                    "SourceStationId = @Source, DestinationStationId = @Destination, " +
                    "DepartureTime = @Departure, ArrivalTime = @Arrival, " +
                    "TotalSeats = @Seats, FarePerSeat = @Fare WHERE TrainId = @Id;";
                int rows = DatabaseHelper.ExecuteNonQuery(sql,
                    new SqlParameter("@Name", name),
                    new SqlParameter("@Number", number),
                    new SqlParameter("@Source", sourceId),
                    new SqlParameter("@Destination", destinationId),
                    new SqlParameter("@Departure", SqlDbType.Time) { Value = departure },
                    new SqlParameter("@Arrival", SqlDbType.Time) { Value = arrival },
                    new SqlParameter("@Seats", seats),
                    new SqlParameter("@Fare", fare),
                    new SqlParameter("@Id", int.Parse(txtTrainId.Text.Trim())));
                lblStatus.Text = "Train updated. Rows affected: " + rows;
                ClearFields();
                LoadTrains();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not update the train.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (txtTrainId.Text.Trim() == "")
            {
                MessageBox.Show("Click a train in the grid first.",
                    "No train selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult answer = MessageBox.Show(
                "Delete train '" + txtTrainName.Text.Trim() + "'? " +
                "A train with bookings cannot be deleted.",
                "Delete train", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer != DialogResult.Yes)
            {
                return;
            }

            try
            {
                string sql = "DELETE FROM Trains WHERE TrainId = @Id;";
                int rows = DatabaseHelper.ExecuteNonQuery(sql,
                    new SqlParameter("@Id", int.Parse(txtTrainId.Text.Trim())));
                lblStatus.Text = "Train deleted. Rows affected: " + rows;
                ClearFields();
                LoadTrains();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not delete the train. A train with bookings " +
                    "cannot be deleted because the Bookings table refers to it.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearFields();
            LoadTrains();
        }

        private void ClearFields()
        {
            txtTrainId.Text = "";
            txtTrainName.Text = "";
            txtTrainNumber.Text = "";
            txtDeparture.Text = "";
            txtArrival.Text = "";
            txtTotalSeats.Text = "";
            txtFare.Text = "";
            if (cmbSource.Items.Count > 0)
            {
                cmbSource.SelectedIndex = 0;
            }
            if (cmbDestination.Items.Count > 0)
            {
                cmbDestination.SelectedIndex = 0;
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string keyword = txtSearch.Text.Trim();
            if (keyword == "")
            {
                LoadTrains();
                return;
            }

            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT t.TrainId, t.TrainName, t.TrainNumber, " +
                    "s1.StationName AS SourceStation, s2.StationName AS DestinationStation, " +
                    "t.DepartureTime, t.ArrivalTime, t.TotalSeats, t.FarePerSeat, " +
                    "t.SourceStationId, t.DestinationStationId " +
                    "FROM Trains t " +
                    "INNER JOIN Stations s1 ON t.SourceStationId = s1.StationId " +
                    "INNER JOIN Stations s2 ON t.DestinationStationId = s2.StationId " +
                    "WHERE t.TrainName LIKE @Q OR t.TrainNumber LIKE @Q " +
                    "ORDER BY t.TrainId;",
                    new SqlParameter("@Q", "%" + keyword + "%"));
                dgvTrains.DataSource = result;
                dgvTrains.Columns["SourceStationId"].Visible = false;
                dgvTrains.Columns["DestinationStationId"].Visible = false;
                lblStatus.Text = result.Rows.Count + " trains found for '" + keyword + "'.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Search failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadTrains();
        }

        // Query 1: free seats on every train for travel on 2026-11-20.
        // Green Line Express should show 237 free seats
        // (240 total - 3 booked on that date).
        private void btnSeatAvailability_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT t.TrainName, t.TotalSeats, " +
                    "ISNULL(SUM(b.SeatsBooked), 0) AS BookedSeats, " +
                    "t.TotalSeats - ISNULL(SUM(b.SeatsBooked), 0) AS FreeSeats " +
                    "FROM Trains t " +
                    "LEFT JOIN Bookings b ON b.TrainId = t.TrainId " +
                    "AND b.TravelDate = '2026-11-20' " +
                    "GROUP BY t.TrainName, t.TotalSeats ORDER BY t.TrainName;");
                dgvTrains.DataSource = result;
                lblStatus.Text = "Seat availability for travel on 20 Nov 2026.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Query 2: full train schedule with station names.
        private void btnSchedule_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT t.TrainName, t.TrainNumber, " +
                    "s1.StationName AS SourceStation, s2.StationName AS DestinationStation, " +
                    "t.DepartureTime, t.ArrivalTime, t.FarePerSeat " +
                    "FROM Trains t " +
                    "INNER JOIN Stations s1 ON t.SourceStationId = s1.StationId " +
                    "INNER JOIN Stations s2 ON t.DestinationStationId = s2.StationId " +
                    "ORDER BY t.DepartureTime;");
                dgvTrains.DataSource = result;
                lblStatus.Text = "Full train schedule.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Query 3: every booking with passenger and train names.
        private void btnPassengerBookings_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT p.FullName AS Passenger, t.TrainName, t.TrainNumber, " +
                    "b.TravelDate, b.SeatsBooked, b.TotalFare " +
                    "FROM Bookings b " +
                    "INNER JOIN Passengers p ON b.PassengerId = p.PassengerId " +
                    "INNER JOIN Trains t ON b.TrainId = t.TrainId " +
                    "ORDER BY b.TravelDate, p.FullName;");
                dgvTrains.DataSource = result;
                lblStatus.Text = "All passenger bookings.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Query 4: total revenue per train.
        private void btnRevenue_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT t.TrainName, COUNT(b.BookingId) AS TotalBookings, " +
                    "SUM(b.TotalFare) AS TotalRevenue " +
                    "FROM Trains t " +
                    "LEFT JOIN Bookings b ON b.TrainId = t.TrainId " +
                    "GROUP BY t.TrainName ORDER BY TotalRevenue DESC;");
                dgvTrains.DataSource = result;
                lblStatus.Text = "Total revenue per train.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
