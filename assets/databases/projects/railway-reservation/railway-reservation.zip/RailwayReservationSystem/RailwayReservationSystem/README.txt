Railway Reservation System — C# Windows Forms + SQL Server (Oracle option included)
==================================================================================

A complete desktop project: book trains, manage trains and stations,
and see seat availability, schedules, passenger bookings and revenue
per train — all stored in a SQL Server database.

WHAT IS INSIDE THIS PROJECT
- RailwayReservationSystem.sln — double-click this to open the project in Visual Studio.
- RailwayReservationSystem/ folder — the C# source code:
    Program.cs            — starts the app and opens the main window.
    MainForm.cs           — all the screen logic (add / update / delete / search trains,
                            and the four practical query buttons, plus the
                            SMS / WhatsApp buttons).
    MainForm.Designer.cs  — the layout of the main window.
    CommunicationForm.cs  — the SMS / WhatsApp window (one number or a
                            contact group, SMS or WhatsApp, plus a wa.me
                            chat link that needs no account).
    CommunicationForm.Designer.cs — the layout of the SMS / WhatsApp window.
    CommunicationService.cs — sends SMS through Twilio and WhatsApp
                            messages through the official WhatsApp Business
                            Cloud API; contact groups from the Passengers
                            table. See SETUP-GUIDE.txt, "SMS AND WHATSAPP SETUP".
    App.config            — Twilio and WhatsApp settings. The values in
                            it are PLACEHOLDERS ONLY — put your own account
                            details there before sending any message.
    DatabaseHelper.cs     — the connection string and all database calls.
    DatabaseScripts/      — the two database scripts:
        railway-reservation-sqlserver.sql — SQL Server version (default).
        railway-reservation-oracle.sql    — Oracle version.
- Screenshots/ folder (at the solution level) — form previews rendered
  from the Designer.cs layout files (the app cannot run on every
  computer, so these are design-time previews, not running screenshots):
  mainform-preview.png, commform-preview.png, and one cropped zoom
  per control type (crop-textbox.png, crop-button.png,
  crop-combobox.png, crop-datagridview.png).
- SETUP-GUIDE.txt — full step-by-step setup for your own Windows laptop,
  including the connection string and troubleshooting. Read it first.
- The matching tutorial article and complete project report (PDF) are on
  the Database blog: https://database-learning-worldwide-dk.blogspot.com/

QUICK START (details in SETUP-GUIDE.txt)
1. Install Visual Studio 2022 Community (free) and SQL Server Express
   LocalDB (it comes with Visual Studio) or SQL Server 2022 Express.
2. In SQL Server Management Studio (SSMS), open and run
   DatabaseScripts/railway-reservation-sqlserver.sql.
3. Double-click RailwayReservationSystem.sln, press F5, and the program runs.
   The main window shows the 5 sample trains.

DATABASE: RailwayDB — tables: Stations (5 rows), Trains (5 rows),
Passengers (6 rows), Bookings (6 rows), Tickets (13 rows).
CONNECTION (default, in DatabaseHelper.cs):
  Server=(localdb)\MSSQLLocalDB;Database=RailwayDB;Trusted_Connection=True;
For a full SQL Server Express instance use Server=.\SQLEXPRESS instead.
For Oracle, see the "Oracle option" section of the article and SETUP-GUIDE.txt.

REQUIREMENTS: Windows 10/11, Visual Studio 2022, .NET 8,
SQL Server Express / LocalDB (or Oracle XE for the Oracle version),
internet once for the first NuGet restore (Microsoft.Data.SqlClient).
