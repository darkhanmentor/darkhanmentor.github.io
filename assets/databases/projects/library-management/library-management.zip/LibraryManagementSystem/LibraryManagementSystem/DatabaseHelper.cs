// DatabaseHelper.cs
// Library Management System — one small helper class for all database work.
// Every form in this project talks to SQL Server only through this class,
// so the connection string lives in exactly one place.
//
// Connection string used by default:
//   Server=(localdb)\MSSQLLocalDB;Database=LibraryDB;Trusted_Connection=True;
// That is SQL Server Express LocalDB, which comes with Visual Studio.
// If you use a full SQL Server Express instance instead, change Server to
//   Server=.\SQLEXPRESS
// (see SETUP-GUIDE.txt, step 4, for exactly where to change it).
//
// Uses Microsoft.Data.SqlClient (NuGet package, version 6.1.7).
// For the Oracle version of this project, see the article section
// "Oracle option in C#" — Oracle.ManagedDataAccess replaces
// Microsoft.Data.SqlClient there.

using System.Data;
using Microsoft.Data.SqlClient;

namespace LibraryManagementSystem
{
    internal static class DatabaseHelper
    {
        public const string ConnectionString =
            @"Server=(localdb)\MSSQLLocalDB;Database=LibraryDB;Trusted_Connection=True;";

        // Runs a SELECT and returns the result as a DataTable.
        // The table can be bound straight to a DataGridView:
        //   dgvBooks.DataSource = DatabaseHelper.GetDataTable("SELECT ...");
        public static DataTable GetDataTable(string sql, params SqlParameter[] parameters)
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                if (parameters != null && parameters.Length > 0)
                {
                    command.Parameters.AddRange(parameters);
                }

                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    return table;
                }
            }
        }

        // Runs an INSERT, UPDATE or DELETE and returns how many rows changed.
        public static int ExecuteNonQuery(string sql, params SqlParameter[] parameters)
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                if (parameters != null && parameters.Length > 0)
                {
                    command.Parameters.AddRange(parameters);
                }

                connection.Open();
                return command.ExecuteNonQuery();
            }
        }

        // Runs a query that returns a single value, for example SELECT COUNT(*).
        public static object ExecuteScalar(string sql, params SqlParameter[] parameters)
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                if (parameters != null && parameters.Length > 0)
                {
                    command.Parameters.AddRange(parameters);
                }

                connection.Open();
                return command.ExecuteScalar();
            }
        }
    }
}
