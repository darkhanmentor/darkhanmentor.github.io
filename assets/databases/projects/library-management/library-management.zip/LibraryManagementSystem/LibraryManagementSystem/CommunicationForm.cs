// CommunicationForm.cs
// Library Management System — the SMS / WhatsApp window.
// Sends a message to one phone number or to a whole contact group
// (for example "All Members") by SMS through Twilio or by WhatsApp
// through the official WhatsApp Business Cloud API. The
// "Open WhatsApp Chat" button opens a wa.me link instead — it needs
// no account, it simply opens WhatsApp with the message already typed.
//
// The group list comes from CommunicationService.GetContactGroups().
// Choosing "Single number" sends to the number typed in txtTo.
// Errors are always shown in a message box — never swallowed.

using System;
using System.Windows.Forms;

namespace LibraryManagementSystem
{
    public partial class CommunicationForm : Form
    {
        public CommunicationForm()
        {
            InitializeComponent();
        }

        private void CommunicationForm_Load(object sender, EventArgs e)
        {
            rdoSms.Checked = true;
            cmbGroup.Items.Add("Single number");
            try
            {
                foreach (ContactGroup group in CommunicationService.GetContactGroups())
                {
                    cmbGroup.Items.Add(group);
                }
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Could not load member groups: " + ex.Message;
            }
            cmbGroup.SelectedIndex = 0;
        }

        // Fill the form from another screen — for example the
        // "Send Overdue Reminder" button on MainForm, which passes the
        // member's phone number and the reminder message.
        public void Prefill(string toPhone, string message)
        {
            txtTo.Text = toPhone ?? "";
            txtMessage.Text = message ?? "";
            if (cmbGroup.Items.Count > 0)
            {
                cmbGroup.SelectedIndex = 0; // "Single number"
            }
        }

        // When a group is selected the single-number box is disabled,
        // because the message goes to the whole group instead.
        private void cmbGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtTo.Enabled = !(cmbGroup.SelectedItem is ContactGroup);
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                string message = txtMessage.Text.Trim();
                string result;

                if (cmbGroup.SelectedItem is ContactGroup group)
                {
                    // A group is selected: send to every member of it.
                    if (rdoSms.Checked)
                    {
                        result = CommunicationService.SendSmsToGroup(group, message);
                    }
                    else
                    {
                        result = CommunicationService.SendWhatsAppToGroup(
                            group, CommunicationService.WhatsAppTemplateName());
                    }
                }
                else
                {
                    // "Single number": send to the number in txtTo.
                    if (rdoSms.Checked)
                    {
                        string sid = CommunicationService.SendSms(txtTo.Text.Trim(), message);
                        result = "SMS sent. Twilio message SID: " + sid;
                    }
                    else
                    {
                        CommunicationService.SendWhatsAppTemplate(
                            txtTo.Text.Trim(), CommunicationService.WhatsAppTemplateName());
                        result = "WhatsApp template '" + CommunicationService.WhatsAppTemplateName()
                            + "' sent to " + txtTo.Text.Trim()
                            + ". (A template message is the approved template text — "
                            + "the message typed above is used for SMS and for the WhatsApp chat link, not for the API template.)";
                    }
                }

                lblStatus.Text = result;
                MessageBox.Show(result, "Message sent",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Send failed: " + ex.Message;
                MessageBox.Show("Could not send the message.\n\n" + ex.Message,
                    "Send failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Open WhatsApp in the browser with the typed message already
        // filled in. Needs no Twilio or WhatsApp API account.
        private void btnWhatsAppChat_Click(object sender, EventArgs e)
        {
            try
            {
                CommunicationService.OpenWhatsAppChat(txtTo.Text.Trim(), txtMessage.Text.Trim());
                lblStatus.Text = "WhatsApp chat opened in the browser.";
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Could not open WhatsApp chat: " + ex.Message;
                MessageBox.Show("Could not open the WhatsApp chat.\n\n" + ex.Message,
                    "WhatsApp chat", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
