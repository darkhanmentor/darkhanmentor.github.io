// CommunicationService.cs
// Library Management System — SMS and WhatsApp messaging.
// Sends SMS through Twilio and WhatsApp messages through the OFFICIAL
// WhatsApp Business Cloud API (Meta Graph API). It also opens a wa.me
// click-to-chat link, which needs no account at all — it simply opens
// WhatsApp in the browser with the message already typed.
//
// SETUP: put your own account details in App.config (appSettings).
// The values shipped in App.config are PLACEHOLDERS ONLY — no message
// is actually sent until you replace them with your own Twilio account
// (for SMS) and your own WhatsApp Business account (for WhatsApp).
// See SETUP-GUIDE.txt, "SMS AND WHATSAPP SETUP".
//
// HONEST LIMITS — please read:
// (1) WhatsApp groups cannot be created by any software through
// WhatsApp's official API — groups are created in the WhatsApp app
// itself. What this class does is manage CONTACT groups inside the
// software (for example "All Members") and send messages to those
// contacts one by one through the official API.
// (2) The wa.me chat link works without any account. The Twilio SMS
// and WhatsApp API calls need your own accounts and internet.
// (3) This code was checked by reading it carefully, not by compiling
// it (this computer has no .NET SDK) — the first build in Visual
// Studio is the real test.
//
// Phone numbers: the Members table stores Pakistani numbers in local
// form, for example 0300-1234567. NormalizePhone converts a leading 0
// to the Pakistan country code +92, so 0300-1234567 becomes
// +923001234567. Numbers that already start with + are left alone.

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

namespace LibraryManagementSystem
{
    // One contact group inside the software: a name and a list of
    // phone numbers. This is NOT a WhatsApp group — WhatsApp groups
    // can only be created in the WhatsApp app itself.
    public class ContactGroup
    {
        public string Name { get; set; }
        public List<string> Phones { get; set; }

        public ContactGroup(string name)
        {
            Name = name;
            Phones = new List<string>();
        }

        // So a ComboBox shows the group name, not the type name.
        public override string ToString()
        {
            return Name;
        }
    }

    internal static class CommunicationService
    {
        // Meta Graph API version pinned in one place. Check Meta's
        // Graph API changelog before upgrading to a newer version.
        // Current version at the time of writing: v26.0 (July 2026).
        private const string WhatsAppGraphVersion = "v26.0";

        // Placeholder values shipped in App.config. A setting is only
        // treated as configured when it differs from its placeholder.
        private const string TwilioSidPlaceholder = "ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
        private const string TwilioTokenPlaceholder = "YOUR_TWILIO_AUTH_TOKEN";
        private const string TwilioFromPlaceholder = "+10000000000";
        private const string WhatsAppIdPlaceholder = "YOUR_WHATSAPP_PHONE_NUMBER_ID";
        private const string WhatsAppTokenPlaceholder = "YOUR_WHATSAPP_ACCESS_TOKEN";

        private static string Setting(string key)
        {
            return ConfigurationManager.AppSettings[key];
        }

        // True only when a real Twilio SID, token and sender number
        // have been put in App.config (not the placeholders).
        public static bool IsTwilioConfigured()
        {
            string sid = Setting("TwilioAccountSid");
            string token = Setting("TwilioAuthToken");
            string from = Setting("TwilioFromNumber");
            return !string.IsNullOrWhiteSpace(sid) && sid != TwilioSidPlaceholder
                && !string.IsNullOrWhiteSpace(token) && token != TwilioTokenPlaceholder
                && !string.IsNullOrWhiteSpace(from) && from != TwilioFromPlaceholder;
        }

        // True only when a real WhatsApp Phone Number ID and access
        // token have been put in App.config (not the placeholders).
        public static bool IsWhatsAppConfigured()
        {
            string id = Setting("WhatsAppPhoneNumberId");
            string token = Setting("WhatsAppAccessToken");
            return !string.IsNullOrWhiteSpace(id) && id != WhatsAppIdPlaceholder
                && !string.IsNullOrWhiteSpace(token) && token != WhatsAppTokenPlaceholder;
        }

        // The message template name from App.config (default hello_world).
        public static string WhatsAppTemplateName()
        {
            string name = Setting("WhatsAppTemplateName");
            return string.IsNullOrWhiteSpace(name) ? "hello_world" : name.Trim();
        }

        // Convert a phone number to international form: remove spaces
        // and dashes; a leading 0 becomes the Pakistan country code
        // +92. Numbers that already start with + are left alone.
        public static string NormalizePhone(string phone)
        {
            if (phone == null)
            {
                return "";
            }
            string digits = phone.Trim().Replace(" ", "").Replace("-", "");
            if (digits.StartsWith("0"))
            {
                digits = "+92" + digits.Substring(1);
            }
            return digits;
        }

        // A phone number is valid only when it starts with + followed
        // by digits, for example +923001234567.
        public static void ValidatePhone(string phone)
        {
            if (string.IsNullOrWhiteSpace(phone))
            {
                throw new ArgumentException(
                    "Phone number is empty. Type a phone number starting with + and the country code, for example +923001234567.");
            }
            string number = phone.Trim();
            if (!number.StartsWith("+"))
            {
                throw new ArgumentException(
                    "Phone number must start with + and the country code, for example +923001234567.");
            }
            if (number.Length < 8)
            {
                throw new ArgumentException(
                    "Phone number is too short. Type a full number starting with + and the country code, for example +923001234567.");
            }
            for (int i = 1; i < number.Length; i++)
            {
                if (!char.IsDigit(number[i]))
                {
                    throw new ArgumentException(
                        "Phone number must contain only digits after the +, for example +923001234567.");
                }
            }
        }

        // Send one SMS through Twilio. Returns the Twilio message SID.
        // Throws InvalidOperationException when Twilio is not
        // configured, and ArgumentException for a bad phone number.
        public static string SendSms(string to, string message)
        {
            if (!IsTwilioConfigured())
            {
                throw new InvalidOperationException(
                    "Twilio is not configured. Put your own Twilio Account SID, Auth Token and Twilio phone number in App.config (see SETUP-GUIDE.txt, \"SMS AND WHATSAPP SETUP\").");
            }
            string phone = NormalizePhone(to);
            ValidatePhone(phone);
            if (string.IsNullOrWhiteSpace(message))
            {
                throw new ArgumentException("Message is empty. Type a message first.");
            }

            TwilioClient.Init(Setting("TwilioAccountSid"), Setting("TwilioAuthToken"));
            MessageResource sent = MessageResource.Create(
                to: new PhoneNumber(phone),
                from: new PhoneNumber(Setting("TwilioFromNumber")),
                body: message);
            return sent.Sid;
        }

        // Send one WhatsApp template message through the OFFICIAL
        // WhatsApp Business Cloud API (Meta Graph API). The free-form
        // text of a template cannot be changed from here — the message
        // sent is the approved template with the given name (default
        // hello_world). Returns the API response body.
        // Throws InvalidOperationException when WhatsApp is not
        // configured or when the API answers with an error.
        public static string SendWhatsAppTemplate(string to, string templateName)
        {
            if (!IsWhatsAppConfigured())
            {
                throw new InvalidOperationException(
                    "WhatsApp is not configured. Put your own WhatsApp Phone Number ID and Access Token in App.config (see SETUP-GUIDE.txt, \"SMS AND WHATSAPP SETUP\").");
            }
            string phone = NormalizePhone(to);
            ValidatePhone(phone);
            if (string.IsNullOrWhiteSpace(templateName))
            {
                templateName = WhatsAppTemplateName();
            }

            string url = "https://graph.facebook.com/" + WhatsAppGraphVersion + "/"
                + Setting("WhatsAppPhoneNumberId") + "/messages";
            // The WhatsApp Cloud API wants the number WITHOUT the +.
            string waTo = phone.Substring(1);
            string json = JsonSerializer.Serialize(new
            {
                messaging_product = "whatsapp",
                to = waTo,
                type = "template",
                template = new
                {
                    name = templateName,
                    language = new { code = "en_US" }
                }
            });

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", Setting("WhatsAppAccessToken"));
                using (StringContent content = new StringContent(json, Encoding.UTF8, "application/json"))
                using (HttpResponseMessage response = client.PostAsync(url, content).GetAwaiter().GetResult())
                {
                    string body = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                    if (!response.IsSuccessStatusCode)
                    {
                        throw new InvalidOperationException(
                            "WhatsApp API returned " + (int)response.StatusCode + ": " + body);
                    }
                    return body;
                }
            }
        }

        // Open a wa.me click-to-chat link in the browser: it opens
        // WhatsApp with the message already typed, ready to send.
        // Needs no Twilio or WhatsApp API account — only internet.
        public static void OpenWhatsAppChat(string to, string message)
        {
            string phone = NormalizePhone(to);
            ValidatePhone(phone);
            // wa.me wants the number WITHOUT the +.
            string url = "https://wa.me/" + phone.Substring(1);
            if (!string.IsNullOrWhiteSpace(message))
            {
                url += "?text=" + Uri.EscapeDataString(message);
            }
            Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
        }

        // The contact groups managed inside the software. At the
        // moment there is one group, "All Members": every member who
        // has a phone number in the Members table. More groups (for
        // example "Overdue Members") can be added here later.
        public static List<ContactGroup> GetContactGroups()
        {
            List<ContactGroup> groups = new List<ContactGroup>();
            ContactGroup allMembers = new ContactGroup("All Members");
            DataTable phones = DatabaseHelper.GetDataTable(
                "SELECT Phone FROM Members WHERE Phone IS NOT NULL AND Phone <> '' ORDER BY FullName;");
            foreach (DataRow row in phones.Rows)
            {
                string phone = NormalizePhone(row["Phone"].ToString());
                if (phone != "" && !allMembers.Phones.Contains(phone))
                {
                    allMembers.Phones.Add(phone);
                }
            }
            groups.Add(allMembers);
            return groups;
        }

        // Send the same SMS to every member of a group. Sends one by
        // one and returns a short result: how many were sent and which
        // numbers failed, for example:
        //   "Sent 4 of 5 SMS to 'All Members'. Failures: +923001234567: ..."
        // A failure on one number never stops the rest of the group.
        public static string SendSmsToGroup(ContactGroup group, string message)
        {
            if (group == null)
            {
                throw new ArgumentException("No contact group selected.");
            }
            int sent = 0;
            List<string> failures = new List<string>();
            foreach (string phone in group.Phones)
            {
                try
                {
                    SendSms(phone, message);
                    sent++;
                }
                catch (Exception ex)
                {
                    failures.Add(phone + ": " + ex.Message);
                }
            }
            string result = "Sent " + sent + " of " + group.Phones.Count
                + " SMS to '" + group.Name + "'.";
            if (failures.Count > 0)
            {
                result += " Failures: " + string.Join("; ", failures);
            }
            return result;
        }

        // Send the same WhatsApp template message to every member of
        // a group. Returns a short result with the sent count and any
        // failures, in the same form as SendSmsToGroup.
        public static string SendWhatsAppToGroup(ContactGroup group, string templateName)
        {
            if (group == null)
            {
                throw new ArgumentException("No contact group selected.");
            }
            int sent = 0;
            List<string> failures = new List<string>();
            foreach (string phone in group.Phones)
            {
                try
                {
                    SendWhatsAppTemplate(phone, templateName);
                    sent++;
                }
                catch (Exception ex)
                {
                    failures.Add(phone + ": " + ex.Message);
                }
            }
            string result = "Sent " + sent + " of " + group.Phones.Count
                + " WhatsApp messages to '" + group.Name + "'.";
            if (failures.Count > 0)
            {
                result += " Failures: " + string.Join("; ", failures);
            }
            return result;
        }
    }
}
