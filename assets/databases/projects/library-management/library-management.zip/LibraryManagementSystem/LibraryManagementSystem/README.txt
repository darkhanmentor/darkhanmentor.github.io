Library Management System — C# Windows Forms + SQL Server (Oracle option included)
====================================================================================

A complete desktop project: manage a library's books and members, record
book issues and returns, find overdue books, view a member's borrowing
history, count available books by category and see the total fine
collected — all stored in a SQL Server database.

WHAT IS INSIDE THIS PROJECT
- LibraryManagementSystem.sln — double-click this to open the project in Visual Studio.
- LibraryManagementSystem/ folder — the C# source code:
    Program.cs            — starts the app and opens the main window.
    MainForm.cs           — all the screen logic (add / update / delete / search books,
                            and the four practical query buttons).
    MainForm.Designer.cs  — the layout of the main window.
    CommunicationService.cs — SMS (Twilio) and WhatsApp (official Business Cloud API)
                            sending, contact groups, and the wa.me chat link.
    CommunicationForm.cs  — the SMS / WhatsApp window (send to one number or a group).
    CommunicationForm.Designer.cs — the layout of the SMS / WhatsApp window.
    App.config            — your Twilio and WhatsApp account details (placeholders only —
                            replace them with your own, see SETUP-GUIDE.txt).
    DatabaseHelper.cs     — the connection string and all database calls.
    DatabaseScripts/      — the two database scripts:
        library-management-sqlserver.sql — SQL Server version (default).
        library-management-oracle.sql    — Oracle version.
- Screenshots/ — form previews rendered from the Designer files
  (main window, SMS / WhatsApp window, and cropped zooms of one
  TextBox, Button, ComboBox and DataGridView), with matching previews
  in the tutorial article on the Database blog.
- SETUP-GUIDE.txt — full step-by-step setup for your own Windows laptop,
  including the connection string and troubleshooting. Read it first.
- The matching tutorial article and complete project report (PDF) are on
  the Database blog: https://database-learning-worldwide-dk.blogspot.com/

QUICK START (details in SETUP-GUIDE.txt)
1. Install Visual Studio 2022 Community (free) and SQL Server Express
   LocalDB (it comes with Visual Studio) or SQL Server 2022 Express.
2. In SQL Server Management Studio (SSMS), open and run
   DatabaseScripts/library-management-sqlserver.sql.
3. Double-click LibraryManagementSystem.sln, press F5, and the program runs.
   The main window shows the 6 sample books.

DATABASE: LibraryDB — tables: Books (6 rows), Members (5 rows), Issues (6 rows).
CONNECTION (default, in DatabaseHelper.cs):
  Server=(localdb)\MSSQLLocalDB;Database=LibraryDB;Trusted_Connection=True;
For a full SQL Server Express instance use Server=.\SQLEXPRESS instead.
For Oracle, see the "Oracle option" section of the article and SETUP-GUIDE.txt.

REQUIREMENTS: Windows 10/11, Visual Studio 2022, .NET 8,
SQL Server Express / LocalDB (or Oracle XE for the Oracle version),
internet once for the first NuGet restore (Microsoft.Data.SqlClient,
Twilio, System.Configuration.ConfigurationManager) and whenever you
send an SMS or WhatsApp message (Twilio / WhatsApp need internet).
