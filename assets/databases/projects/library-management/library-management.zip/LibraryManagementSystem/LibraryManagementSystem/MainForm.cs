// MainForm.cs
// Library Management System — main window.
// Shows all books in a grid and lets the user add, update, delete and
// search books. The four query buttons at the bottom run the practical
// queries from the project (overdue books, member history, available
// books by category, total fine collected) and show the result in the
// same grid. All database work goes through DatabaseHelper, and every
// value typed by the user is passed as a parameter — never joined into
// the SQL text.

using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace LibraryManagementSystem
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            LoadBooks();
        }

        // Show all books in the grid.
        private void LoadBooks()
        {
            try
            {
                DataTable books = DatabaseHelper.GetDataTable(
                    "SELECT BookId, Title, Author, ISBN, Category, " +
                    "TotalCopies, AvailableCopies FROM Books ORDER BY BookId;");
                dgvBooks.DataSource = books;
                lblStatus.Text = books.Rows.Count + " books loaded.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not load books. Check that LibraryDB exists " +
                    "and the connection string is correct.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // When a grid row is clicked, copy its values into the fields.
        private void dgvBooks_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
            {
                return;
            }

            DataGridViewRow row = dgvBooks.Rows[e.RowIndex];
            txtBookId.Text = row.Cells["BookId"].Value.ToString();
            txtTitle.Text = row.Cells["Title"].Value.ToString();
            txtAuthor.Text = row.Cells["Author"].Value.ToString();
            txtISBN.Text = row.Cells["ISBN"].Value.ToString();
            txtCategory.Text = row.Cells["Category"].Value.ToString();
            txtTotalCopies.Text = row.Cells["TotalCopies"].Value.ToString();
            txtAvailableCopies.Text = row.Cells["AvailableCopies"].Value.ToString();
        }

        // Read the form fields. Returns false and shows a message if
        // anything is missing or in the wrong format.
        private bool ReadFields(out string title, out string author,
            out string isbn, out string category,
            out int totalCopies, out int availableCopies)
        {
            title = txtTitle.Text.Trim();
            author = txtAuthor.Text.Trim();
            isbn = txtISBN.Text.Trim();
            category = txtCategory.Text.Trim();
            totalCopies = 0;
            availableCopies = 0;

            if (title == "" || author == "" || isbn == "")
            {
                MessageBox.Show("Title, author and ISBN are required.",
                    "Missing data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!int.TryParse(txtTotalCopies.Text.Trim(), out totalCopies) || totalCopies <= 0)
            {
                MessageBox.Show("Total copies must be a whole number above zero.",
                    "Wrong data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!int.TryParse(txtAvailableCopies.Text.Trim(), out availableCopies) || availableCopies < 0)
            {
                MessageBox.Show("Available copies must be a whole number, zero or more.",
                    "Wrong data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (availableCopies > totalCopies)
            {
                MessageBox.Show("Available copies cannot be more than total copies.",
                    "Wrong data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!ReadFields(out string title, out string author,
                out string isbn, out string category,
                out int totalCopies, out int availableCopies))
            {
                return;
            }

            try
            {
                string sql = "INSERT INTO Books (Title, Author, ISBN, Category, " +
                    "TotalCopies, AvailableCopies) " +
                    "VALUES (@Title, @Author, @ISBN, @Category, @Total, @Available);";
                int rows = DatabaseHelper.ExecuteNonQuery(sql,
                    new SqlParameter("@Title", title),
                    new SqlParameter("@Author", author),
                    new SqlParameter("@ISBN", isbn),
                    new SqlParameter("@Category", category),
                    new SqlParameter("@Total", totalCopies),
                    new SqlParameter("@Available", availableCopies));
                lblStatus.Text = "Book added. Rows affected: " + rows;
                ClearFields();
                LoadBooks();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not add the book.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtBookId.Text.Trim() == "")
            {
                MessageBox.Show("Click a book in the grid first, then change its details.",
                    "No book selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!ReadFields(out string title, out string author,
                out string isbn, out string category,
                out int totalCopies, out int availableCopies))
            {
                return;
            }

            try
            {
                string sql = "UPDATE Books SET Title = @Title, Author = @Author, " +
                    "ISBN = @ISBN, Category = @Category, " +
                    "TotalCopies = @Total, AvailableCopies = @Available " +
                    "WHERE BookId = @Id;";
                int rows = DatabaseHelper.ExecuteNonQuery(sql,
                    new SqlParameter("@Title", title),
                    new SqlParameter("@Author", author),
                    new SqlParameter("@ISBN", isbn),
                    new SqlParameter("@Category", category),
                    new SqlParameter("@Total", totalCopies),
                    new SqlParameter("@Available", availableCopies),
                    new SqlParameter("@Id", int.Parse(txtBookId.Text.Trim())));
                lblStatus.Text = "Book updated. Rows affected: " + rows;
                ClearFields();
                LoadBooks();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not update the book.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (txtBookId.Text.Trim() == "")
            {
                MessageBox.Show("Click a book in the grid first.",
                    "No book selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult answer = MessageBox.Show(
                "Delete book '" + txtTitle.Text.Trim() + "'? " +
                "A book with issue records cannot be deleted.",
                "Delete book", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer != DialogResult.Yes)
            {
                return;
            }

            try
            {
                string sql = "DELETE FROM Books WHERE BookId = @Id;";
                int rows = DatabaseHelper.ExecuteNonQuery(sql,
                    new SqlParameter("@Id", int.Parse(txtBookId.Text.Trim())));
                lblStatus.Text = "Book deleted. Rows affected: " + rows;
                ClearFields();
                LoadBooks();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not delete the book. A book with issue records " +
                    "cannot be deleted because the Issues table refers to it.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearFields();
            LoadBooks();
        }

        private void ClearFields()
        {
            txtBookId.Text = "";
            txtTitle.Text = "";
            txtAuthor.Text = "";
            txtISBN.Text = "";
            txtCategory.Text = "";
            txtTotalCopies.Text = "";
            txtAvailableCopies.Text = "";
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string keyword = txtSearch.Text.Trim();
            if (keyword == "")
            {
                LoadBooks();
                return;
            }

            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT BookId, Title, Author, ISBN, Category, " +
                    "TotalCopies, AvailableCopies FROM Books " +
                    "WHERE Title LIKE @Q OR Author LIKE @Q OR ISBN LIKE @Q " +
                    "ORDER BY BookId;",
                    new SqlParameter("@Q", "%" + keyword + "%"));
                dgvBooks.DataSource = result;
                lblStatus.Text = result.Rows.Count + " books found for '" + keyword + "'.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Search failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadBooks();
        }

        // Query 1: overdue books — issued, not returned, and past the due date.
        // "Today" for this query is 20 November 2026. Expected result: 2 rows —
        // Issue 1 (Learn C Programming, Ahmed Raza, due 2026-11-10) and
        // Issue 3 (English Grammar, Ahmed Raza, due 2026-11-12).
        private void btnOverdue_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT i.IssueId, b.Title, m.FullName AS Member, " +
                    "i.IssueDate, i.DueDate " +
                    "FROM Issues i " +
                    "INNER JOIN Books b ON i.BookId = b.BookId " +
                    "INNER JOIN Members m ON i.MemberId = m.MemberId " +
                    "WHERE i.DueDate < '2026-11-20' AND i.ReturnDate IS NULL " +
                    "ORDER BY i.DueDate;");
                dgvBooks.DataSource = result;
                lblStatus.Text = result.Rows.Count + " overdue books (due before 20 Nov 2026, not returned).";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Query 2: borrowing history of one member.
        // MemberId 1 is Ahmed Raza. Expected result: 2 rows — Issue 1
        // (Learn C Programming) and Issue 3 (English Grammar).
        // To see another member's history, change the 1 below to that
        // member's MemberId (for example 2 for Fatima Khan).
        private void btnMemberHistory_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT m.FullName AS Member, b.Title, " +
                    "i.IssueDate, i.DueDate, i.ReturnDate, i.Fine " +
                    "FROM Issues i " +
                    "INNER JOIN Members m ON i.MemberId = m.MemberId " +
                    "INNER JOIN Books b ON i.BookId = b.BookId " +
                    "WHERE i.MemberId = @MemberId " +
                    "ORDER BY i.IssueDate;",
                    new SqlParameter("@MemberId", 1));
                dgvBooks.DataSource = result;
                lblStatus.Text = "Borrowing history of Ahmed Raza (MemberId 1): " +
                    result.Rows.Count + " issues.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Query 3: available books grouped by category.
        // Expected result: Programming 5, Language 5, Mathematics 1,
        // Science 4, Social Studies 2.
        private void btnAvailableByCategory_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT Category, SUM(AvailableCopies) AS AvailableBooks, " +
                    "COUNT(BookId) AS TotalTitles " +
                    "FROM Books GROUP BY Category ORDER BY AvailableBooks DESC;");
                dgvBooks.DataSource = result;
                lblStatus.Text = "Available books by category.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Query 4: total fine collected from all issues.
        // Expected result: one row, 100 (only Issue 5 has a fine of 100).
        private void btnTotalFine_Click(object sender, EventArgs e)
        {
            try
            {
                object total = DatabaseHelper.ExecuteScalar(
                    "SELECT SUM(Fine) FROM Issues;");
                lblStatus.Text = "Total fine collected: " + total;
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT SUM(Fine) AS TotalFineCollected FROM Issues;");
                dgvBooks.DataSource = result;
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Open the SMS / WhatsApp window. From there a message can be
        // sent to one phone number or to a whole contact group
        // (for example "All Members") by SMS or WhatsApp.
        private void btnCommunication_Click(object sender, EventArgs e)
        {
            CommunicationForm form = new CommunicationForm();
            form.ShowDialog();
        }

        // One-click overdue reminder. Takes one overdue issue, builds
        // the reminder message for that member's phone number
        // (Members.Phone, reached through the Issues table) and opens
        // the SMS / WhatsApp window pre-filled with it, ready to send.
        // If the grid is showing the overdue-books result and a row is
        // selected, that row's issue is used; otherwise the earliest
        // overdue issue is used. "Today" is 20 November 2026, the same
        // date the overdue query uses, so the sample data matches:
        // Issue 1 is Learn C Programming, Ahmed Raza, due 2026-11-10.
        private void btnSendOverdueReminder_Click(object sender, EventArgs e)
        {
            try
            {
                // Is a row of the overdue-books result selected?
                // That result has the columns Title, Member and DueDate.
                string selectedTitle = null;
                string selectedMember = null;
                DateTime selectedDueDate = DateTime.MinValue;
                if (dgvBooks.CurrentRow != null
                    && dgvBooks.Columns.Contains("Title")
                    && dgvBooks.Columns.Contains("Member")
                    && dgvBooks.Columns.Contains("DueDate"))
                {
                    DataGridViewRow row = dgvBooks.CurrentRow;
                    if (row.Cells["Title"].Value != null
                        && row.Cells["Member"].Value != null
                        && row.Cells["DueDate"].Value != null
                        && DateTime.TryParse(row.Cells["DueDate"].Value.ToString(), out DateTime due))
                    {
                        selectedTitle = row.Cells["Title"].Value.ToString();
                        selectedMember = row.Cells["Member"].Value.ToString();
                        selectedDueDate = due;
                    }
                }

                DataTable result;
                if (selectedTitle != null && selectedMember != null)
                {
                    // The selected overdue issue, with the member's phone.
                    result = DatabaseHelper.GetDataTable(
                        "SELECT TOP 1 b.Title, m.FullName, m.Phone, i.DueDate, i.Fine " +
                        "FROM Issues i " +
                        "INNER JOIN Books b ON i.BookId = b.BookId " +
                        "INNER JOIN Members m ON i.MemberId = m.MemberId " +
                        "WHERE i.ReturnDate IS NULL AND b.Title = @Title " +
                        "AND m.FullName = @Member AND i.DueDate = @DueDate;",
                        new SqlParameter("@Title", selectedTitle),
                        new SqlParameter("@Member", selectedMember),
                        new SqlParameter("@DueDate", selectedDueDate.Date));
                }
                else
                {
                    // No overdue row selected: the earliest overdue issue.
                    result = DatabaseHelper.GetDataTable(
                        "SELECT TOP 1 b.Title, m.FullName, m.Phone, i.DueDate, i.Fine " +
                        "FROM Issues i " +
                        "INNER JOIN Books b ON i.BookId = b.BookId " +
                        "INNER JOIN Members m ON i.MemberId = m.MemberId " +
                        "WHERE i.ReturnDate IS NULL AND i.DueDate < '2026-11-20' " +
                        "ORDER BY i.DueDate;");
                }

                if (result.Rows.Count == 0)
                {
                    MessageBox.Show("No overdue books found.",
                        "No overdue books", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                DataRow issue = result.Rows[0];
                string bookTitle = issue["Title"].ToString();
                string memberName = issue["FullName"].ToString();
                string phone = issue["Phone"] == DBNull.Value ? "" : issue["Phone"].ToString();
                DateTime dueDate = (DateTime)issue["DueDate"];
                decimal fine = issue["Fine"] == DBNull.Value ? 0 : Convert.ToDecimal(issue["Fine"]);
                int daysOverdue = (new DateTime(2026, 11, 20) - dueDate.Date).Days;

                string message = "Reminder: the book '" + bookTitle + "' is overdue by "
                    + daysOverdue + " days. Fine due: Rs " + fine.ToString("0")
                    + ". Please return it. — Library Management System";

                CommunicationForm form = new CommunicationForm();
                form.Prefill(phone, message);
                form.ShowDialog();
                lblStatus.Text = "Overdue reminder prepared for " + memberName + ".";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not find an overdue issue.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
