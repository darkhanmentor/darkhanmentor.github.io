// MainForm.cs
// Medical Store Management System — main window.
// Shows all medicines in a grid and lets the user add, update, delete and
// search medicines. The four query buttons at the bottom run the practical
// queries from the project (low stock, near expiry, daily sales, profit
// per medicine) and show the result in the same grid.
// All database work goes through DatabaseHelper, and every value typed
// by the user is passed as a parameter — never joined into the SQL text.

using System;
using System.Data;
using System.Globalization;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace MedicalStoreManagementSystem
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            LoadMedicines();
        }

        // Show all medicines in the grid.
        private void LoadMedicines()
        {
            try
            {
                DataTable medicines = DatabaseHelper.GetDataTable(
                    "SELECT MedicineId, MedicineName, Category, Manufacturer, " +
                    "UnitPrice, StockQuantity, ExpiryDate, ReorderLevel " +
                    "FROM Medicines ORDER BY MedicineId;");
                dgvMedicines.DataSource = medicines;
                lblStatus.Text = medicines.Rows.Count + " medicines loaded.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not load medicines. Check that MedicalStoreDB exists " +
                    "and the connection string is correct.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // When a grid row is clicked, copy its values into the fields.
        private void dgvMedicines_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
            {
                return;
            }

            DataGridViewRow row = dgvMedicines.Rows[e.RowIndex];
            txtMedicineId.Text = row.Cells["MedicineId"].Value.ToString();
            txtMedicineName.Text = row.Cells["MedicineName"].Value.ToString();
            txtCategory.Text = row.Cells["Category"].Value.ToString();
            txtManufacturer.Text = row.Cells["Manufacturer"].Value.ToString();
            txtUnitPrice.Text = row.Cells["UnitPrice"].Value.ToString();
            txtStockQuantity.Text = row.Cells["StockQuantity"].Value.ToString();
            DateTime expiry = (DateTime)row.Cells["ExpiryDate"].Value;
            txtExpiryDate.Text = expiry.ToString("yyyy-MM-dd");
            txtReorderLevel.Text = row.Cells["ReorderLevel"].Value.ToString();
        }

        // Read the form fields. Returns false and shows a message if
        // anything is missing or in the wrong format.
        private bool ReadFields(out string name, out string category,
            out string manufacturer, out decimal unitPrice,
            out int stockQuantity, out DateTime expiryDate,
            out int reorderLevel)
        {
            name = txtMedicineName.Text.Trim();
            category = txtCategory.Text.Trim();
            manufacturer = txtManufacturer.Text.Trim();
            unitPrice = 0m;
            stockQuantity = 0;
            expiryDate = DateTime.MinValue;
            reorderLevel = 0;

            if (name == "" || category == "" || manufacturer == "")
            {
                MessageBox.Show("Medicine name, category and manufacturer are required.",
                    "Missing data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!decimal.TryParse(txtUnitPrice.Text.Trim(), out unitPrice) || unitPrice < 0)
            {
                MessageBox.Show("Unit price must be a number, for example 50.",
                    "Wrong data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!int.TryParse(txtStockQuantity.Text.Trim(), out stockQuantity) || stockQuantity < 0)
            {
                MessageBox.Show("Stock quantity must be a whole number, zero or more.",
                    "Wrong data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!DateTime.TryParseExact(txtExpiryDate.Text.Trim(), "yyyy-MM-dd",
                CultureInfo.InvariantCulture, DateTimeStyles.None, out expiryDate))
            {
                MessageBox.Show("Expiry date must look like 2027-06-30 (year-month-day).",
                    "Wrong data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!int.TryParse(txtReorderLevel.Text.Trim(), out reorderLevel) || reorderLevel < 0)
            {
                MessageBox.Show("Reorder level must be a whole number, zero or more.",
                    "Wrong data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!ReadFields(out string name, out string category,
                out string manufacturer, out decimal unitPrice,
                out int stockQuantity, out DateTime expiryDate,
                out int reorderLevel))
            {
                return;
            }

            try
            {
                string sql = "INSERT INTO Medicines (MedicineName, Category, Manufacturer, " +
                    "UnitPrice, StockQuantity, ExpiryDate, ReorderLevel) " +
                    "VALUES (@Name, @Category, @Manufacturer, @Price, @Stock, @Expiry, @Reorder);";
                int rows = DatabaseHelper.ExecuteNonQuery(sql,
                    new SqlParameter("@Name", name),
                    new SqlParameter("@Category", category),
                    new SqlParameter("@Manufacturer", manufacturer),
                    new SqlParameter("@Price", unitPrice),
                    new SqlParameter("@Stock", stockQuantity),
                    new SqlParameter("@Expiry", SqlDbType.Date) { Value = expiryDate },
                    new SqlParameter("@Reorder", reorderLevel));
                lblStatus.Text = "Medicine added. Rows affected: " + rows;
                ClearFields();
                LoadMedicines();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not add the medicine.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtMedicineId.Text.Trim() == "")
            {
                MessageBox.Show("Click a medicine in the grid first, then change its details.",
                    "No medicine selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!ReadFields(out string name, out string category,
                out string manufacturer, out decimal unitPrice,
                out int stockQuantity, out DateTime expiryDate,
                out int reorderLevel))
            {
                return;
            }

            try
            {
                string sql = "UPDATE Medicines SET MedicineName = @Name, Category = @Category, " +
                    "Manufacturer = @Manufacturer, UnitPrice = @Price, StockQuantity = @Stock, " +
                    "ExpiryDate = @Expiry, ReorderLevel = @Reorder WHERE MedicineId = @Id;";
                int rows = DatabaseHelper.ExecuteNonQuery(sql,
                    new SqlParameter("@Name", name),
                    new SqlParameter("@Category", category),
                    new SqlParameter("@Manufacturer", manufacturer),
                    new SqlParameter("@Price", unitPrice),
                    new SqlParameter("@Stock", stockQuantity),
                    new SqlParameter("@Expiry", SqlDbType.Date) { Value = expiryDate },
                    new SqlParameter("@Reorder", reorderLevel),
                    new SqlParameter("@Id", int.Parse(txtMedicineId.Text.Trim())));
                lblStatus.Text = "Medicine updated. Rows affected: " + rows;
                ClearFields();
                LoadMedicines();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not update the medicine.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (txtMedicineId.Text.Trim() == "")
            {
                MessageBox.Show("Click a medicine in the grid first.",
                    "No medicine selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult answer = MessageBox.Show(
                "Delete medicine '" + txtMedicineName.Text.Trim() + "'? " +
                "A medicine with purchases or sales cannot be deleted.",
                "Delete medicine", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer != DialogResult.Yes)
            {
                return;
            }

            try
            {
                string sql = "DELETE FROM Medicines WHERE MedicineId = @Id;";
                int rows = DatabaseHelper.ExecuteNonQuery(sql,
                    new SqlParameter("@Id", int.Parse(txtMedicineId.Text.Trim())));
                lblStatus.Text = "Medicine deleted. Rows affected: " + rows;
                ClearFields();
                LoadMedicines();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not delete the medicine. A medicine with purchases " +
                    "or sales cannot be deleted because the Purchases and Sales tables " +
                    "refer to it.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearFields();
            LoadMedicines();
        }

        private void ClearFields()
        {
            txtMedicineId.Text = "";
            txtMedicineName.Text = "";
            txtCategory.Text = "";
            txtManufacturer.Text = "";
            txtUnitPrice.Text = "";
            txtStockQuantity.Text = "";
            txtExpiryDate.Text = "";
            txtReorderLevel.Text = "";
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string keyword = txtSearch.Text.Trim();
            if (keyword == "")
            {
                LoadMedicines();
                return;
            }

            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT MedicineId, MedicineName, Category, Manufacturer, " +
                    "UnitPrice, StockQuantity, ExpiryDate, ReorderLevel " +
                    "FROM Medicines " +
                    "WHERE MedicineName LIKE @Q OR Category LIKE @Q OR Manufacturer LIKE @Q " +
                    "ORDER BY MedicineId;",
                    new SqlParameter("@Q", "%" + keyword + "%"));
                dgvMedicines.DataSource = result;
                lblStatus.Text = result.Rows.Count + " medicines found for '" + keyword + "'.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Search failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadMedicines();
        }

        // Open the SMS / WhatsApp window.
        private void btnCommunication_Click(object sender, EventArgs e)
        {
            CommunicationForm form = new CommunicationForm();
            form.ShowDialog(this);
        }

        // One-click action: build an expiry alert + order SMS for the
        // selected medicine and open the SMS / WhatsApp window with it
        // already filled in. The supplier is the one who last supplied
        // this medicine (latest Purchase), and the order quantity is
        // the medicine's reorder level. The phone number in the
        // Suppliers table is in local form (0300-1111111);
        // CommunicationService turns it into +92 form before sending.
        // If the medicine has no purchase yet, no supplier is found —
        // the window still opens with the message, and the user types
        // the supplier's number by hand.
        private void btnSendExpiryAlert_Click(object sender, EventArgs e)
        {
            if (txtMedicineId.Text.Trim() == "")
            {
                MessageBox.Show("Click a medicine in the grid first, then send the expiry alert.",
                    "No medicine selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string medicineName = txtMedicineName.Text.Trim();
            string expiry = txtExpiryDate.Text.Trim();
            int quantity = 0;
            int.TryParse(txtReorderLevel.Text.Trim(), out quantity);
            string message = "Alert: " + medicineName + " expires on " + expiry +
                ". Please send " + quantity + " units. — Medical Store Management System";

            string phone = "";
            try
            {
                object result = DatabaseHelper.ExecuteScalar(
                    "SELECT TOP 1 s.Phone FROM Suppliers s " +
                    "INNER JOIN Purchases p ON p.SupplierId = s.SupplierId " +
                    "WHERE p.MedicineId = @Id AND s.Phone IS NOT NULL AND s.Phone <> '' " +
                    "ORDER BY p.PurchaseDate DESC;",
                    new SqlParameter("@Id", int.Parse(txtMedicineId.Text.Trim())));
                if (result != null && result != DBNull.Value)
                {
                    phone = result.ToString();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not find the supplier for this medicine.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            CommunicationForm form = new CommunicationForm();
            form.Prefill(phone, message);
            form.ShowDialog(this);
            if (phone == "")
            {
                lblStatus.Text = "Expiry alert ready — no supplier found for this medicine; " +
                    "type the supplier's number in the SMS / WhatsApp window.";
            }
            else
            {
                lblStatus.Text = "Expiry alert ready for " + medicineName + ".";
            }
        }

        // Query 1: Low stock medicines — stock at or below the reorder level.
        // Expected result: 2 rows — Amoxil (20, reorder level 30)
        // and Risek (15, reorder level 25).
        private void btnLowStock_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT MedicineId, MedicineName, Category, StockQuantity, ReorderLevel " +
                    "FROM Medicines WHERE StockQuantity <= ReorderLevel ORDER BY MedicineName;");
                dgvMedicines.DataSource = result;
                lblStatus.Text = result.Rows.Count + " low stock medicines. Order these again.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Query 2: Near-expiry medicines — expiring within 30 days of 2026-11-15.
        // Expected result: 2 rows — Risek (2026-11-30) and Amoxil (2026-12-15).
        private void btnNearExpiry_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT MedicineId, MedicineName, Category, StockQuantity, ExpiryDate " +
                    "FROM Medicines WHERE ExpiryDate <= DATEADD(day, 30, '2026-11-15') " +
                    "ORDER BY ExpiryDate;");
                dgvMedicines.DataSource = result;
                lblStatus.Text = result.Rows.Count + " medicines expiring within 30 days of 15 Nov 2026.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Query 3: Daily sales report for 2026-11-15.
        // Expected result: 3 sales, total 3150
        // (Panadol 500, Amoxil 1750, Risek 900).
        private void btnDailySales_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT m.MedicineName, SUM(s.Quantity) AS TotalQuantity, " +
                    "SUM(s.Quantity * s.SalePrice) AS TotalAmount " +
                    "FROM Sales s " +
                    "INNER JOIN Medicines m ON s.MedicineId = m.MedicineId " +
                    "WHERE s.SaleDate = '2026-11-15' " +
                    "GROUP BY m.MedicineName ORDER BY m.MedicineName;");
                dgvMedicines.DataSource = result;
                lblStatus.Text = "Daily sales report for 15 Nov 2026. Total sales: 3150.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Query 4: Profit per medicine — (sale price - latest purchase price)
        // x total quantity sold.
        // Expected result: Panadol 100, Amoxil 250, Brufen 400, Risek 100, Strepsils 300.
        private void btnProfit_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT m.MedicineName, SUM(s.Quantity) AS TotalSold, " +
                    "SUM((s.SalePrice - p.PurchasePrice) * s.Quantity) AS TotalProfit " +
                    "FROM Sales s " +
                    "INNER JOIN Medicines m ON s.MedicineId = m.MedicineId " +
                    "INNER JOIN Purchases p ON p.MedicineId = s.MedicineId " +
                    "AND p.PurchaseDate = (SELECT MAX(p2.PurchaseDate) FROM Purchases p2 " +
                    "WHERE p2.MedicineId = s.MedicineId) " +
                    "GROUP BY m.MedicineName ORDER BY TotalProfit DESC;");
                dgvMedicines.DataSource = result;
                lblStatus.Text = "Profit per medicine.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
