Medical Store Management System — C# Windows Forms + SQL Server (Oracle option included)
==========================================================================================

A complete desktop project: manage medicines in a medical store (pharmacy),
track stock and expiry dates, record purchases from suppliers and sales to
customers, and see low stock, near-expiry medicines, daily sales and profit
per medicine — all stored in a SQL Server database.

WHAT IS INSIDE THIS PROJECT
- MedicalStoreManagementSystem.sln — double-click this to open the project in Visual Studio.
- MedicalStoreManagementSystem/ folder — the C# source code:
    Program.cs            — starts the app and opens the main window.
    MainForm.cs           — all the screen logic (add / update / delete / search medicines,
                            and the four practical query buttons).
    MainForm.Designer.cs  — the layout of the main window.
    CommunicationForm.cs  — the SMS / WhatsApp window (send to one number or a
                            contact group, open a wa.me chat).
    CommunicationForm.Designer.cs — the layout of the SMS / WhatsApp window.
    CommunicationService.cs — SMS through Twilio + WhatsApp through the official
                            WhatsApp Business Cloud API + contact groups
                            ("All Suppliers", "All Customers").
    App.config            — your Twilio and WhatsApp account details (placeholders
                            only — put your own values in before sending).
    DatabaseHelper.cs     — the connection string and all database calls.
    DatabaseScripts/      — the two database scripts:
        medical-store-management-sqlserver.sql — SQL Server version (default).
        medical-store-management-oracle.sql    — Oracle version.
- Screenshots/ folder — form previews rendered from the Designer.cs files
  (main window, SMS / WhatsApp window, and cropped close-ups of one
  TextBox, one Button, one ComboBox and the DataGridView).
- SETUP-GUIDE.txt — full step-by-step setup for your own Windows laptop,
  including the connection string and troubleshooting. Read it first.
- The matching tutorial article and complete project report (PDF) are on
  the Database blog: https://database-learning-worldwide-dk.blogspot.com/

QUICK START (details in SETUP-GUIDE.txt)
1. Install Visual Studio 2022 Community (free) and SQL Server Express
   LocalDB (it comes with Visual Studio) or SQL Server 2022 Express.
2. In SQL Server Management Studio (SSMS), open and run
   DatabaseScripts/medical-store-management-sqlserver.sql.
3. Double-click MedicalStoreManagementSystem.sln, press F5, and the program runs.
   The main window shows the 6 sample medicines.

DATABASE: MedicalStoreDB — tables: Medicines (6 rows), Suppliers (3 rows),
Customers (4 rows), Purchases (5 rows), Sales (5 rows).
CONNECTION (default, in DatabaseHelper.cs):
  Server=(localdb)\MSSQLLocalDB;Database=MedicalStoreDB;Trusted_Connection=True;
For a full SQL Server Express instance use Server=.\SQLEXPRESS instead.
For Oracle, see the "Oracle option" section of the article and SETUP-GUIDE.txt.

SMS / WHATSAPP: the "SMS / WhatsApp" button on the main window opens a
second window that sends an SMS through Twilio or a WhatsApp template
message through the official WhatsApp Business Cloud API, to one number
or to a contact group ("All Suppliers", "All Customers") from the
database. The "Send expiry alert + order SMS" button builds an expiry
alert + order message for the selected medicine and opens the same
window with it already filled in. Your own Twilio and WhatsApp account
details go in App.config (placeholders only are shipped). Full steps:
SETUP-GUIDE.txt, "SMS AND WHATSAPP SETUP". WhatsApp groups cannot be
created by any software — groups are created in the WhatsApp app itself;
this software manages contact groups inside the app and messages them.
ONLINE: LocalDB works on one laptop only. To use the system online,
point DatabaseHelper.cs at a hosted SQL Server (Server + SQL login
User Id/Password instead of Trusted_Connection) — see SETUP-GUIDE.txt,
"ONLINE SYSTEM (USE IT ONLINE)".

REQUIREMENTS: Windows 10/11, Visual Studio 2022, .NET 8,
SQL Server Express / LocalDB (or Oracle XE for the Oracle version),
internet once for the first NuGet restore (Microsoft.Data.SqlClient,
Twilio, System.Configuration.ConfigurationManager) and every time
you send an SMS or WhatsApp message.
