// CommunicationForm.cs
// Medical Store Management System — SMS / WhatsApp window.
// Sends an SMS (through Twilio) or a WhatsApp template message
// (through the official WhatsApp Business Cloud API) to one phone
// number or to a whole contact group ("All Suppliers" or
// "All Customers") from the database. The "Open WhatsApp chat"
// button opens a wa.me chat link instead — it needs no account.
//
// All sending goes through CommunicationService. Errors are shown
// in a message box and in the status label — they are never
// swallowed silently.

using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace MedicalStoreManagementSystem
{
    public partial class CommunicationForm : Form
    {
        private const string SingleNumberEntry = "Single number";
        private List<ContactGroup> groups = new List<ContactGroup>();

        public CommunicationForm()
        {
            InitializeComponent();
        }

        private void CommunicationForm_Load(object sender, EventArgs e)
        {
            rdoSms.Checked = true;
            cmbGroup.Items.Add(SingleNumberEntry);
            try
            {
                groups = CommunicationService.GetContactGroups();
                foreach (ContactGroup group in groups)
                {
                    cmbGroup.Items.Add(group.Name + " (" + group.Phones.Count + " numbers)");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not load the contact groups from the database. " +
                    "You can still send to a single number.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            cmbGroup.SelectedIndex = 0;
        }

        // Fill the form from another screen — for example the main
        // window's "Send expiry alert + order SMS" button, which
        // pre-fills the supplier's number and the alert message.
        public void Prefill(string toPhone, string message)
        {
            cmbGroup.SelectedIndex = 0;
            txtTo.Text = toPhone ?? "";
            txtMessage.Text = message ?? "";
        }

        private void cmbGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            // A group is selected: the message goes to the whole group,
            // so the single-number box is switched off.
            txtTo.Enabled = cmbGroup.SelectedIndex == 0;
        }

        private ContactGroup SelectedGroup()
        {
            // Item 0 is "Single number". Item 1 is groups[0], item 2 is groups[1].
            if (cmbGroup.SelectedIndex <= 0 || cmbGroup.SelectedIndex - 1 >= groups.Count)
            {
                return null;
            }
            return groups[cmbGroup.SelectedIndex - 1];
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            string message = txtMessage.Text.Trim();
            ContactGroup group = SelectedGroup();

            try
            {
                string result;
                if (group != null)
                {
                    // Send to the whole group.
                    if (rdoSms.Checked)
                    {
                        result = CommunicationService.SendSmsToGroup(group, message);
                    }
                    else
                    {
                        result = CommunicationService.SendWhatsAppToGroup(group, null);
                    }
                }
                else
                {
                    // Send to one number.
                    string to = txtTo.Text.Trim();
                    if (to == "")
                    {
                        MessageBox.Show("Type a phone number, for example +923001234567.",
                            "No phone number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    if (rdoSms.Checked)
                    {
                        string sid = CommunicationService.SendSms(to, message);
                        result = "SMS sent. Twilio message SID: " + sid;
                    }
                    else
                    {
                        CommunicationService.SendWhatsAppTemplate(to, null);
                        result = "WhatsApp template sent to " + to + ".";
                    }
                }

                lblStatus.Text = result;
                MessageBox.Show(result, "Message sent", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Sending failed: " + ex.Message;
                MessageBox.Show("Sending failed.\n\n" + ex.Message,
                    "Sending failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnWhatsAppChat_Click(object sender, EventArgs e)
        {
            string to = txtTo.Text.Trim();
            if (to == "")
            {
                MessageBox.Show("Type a phone number first, for example +923001234567.",
                    "No phone number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                CommunicationService.OpenWhatsAppChat(to, txtMessage.Text.Trim());
                lblStatus.Text = "WhatsApp chat opened for " + to + ". Press Send in WhatsApp.";
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Could not open WhatsApp: " + ex.Message;
                MessageBox.Show("Could not open WhatsApp.\n\n" + ex.Message,
                    "WhatsApp chat", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
