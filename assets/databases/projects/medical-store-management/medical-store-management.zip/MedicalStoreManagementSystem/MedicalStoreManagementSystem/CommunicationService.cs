// CommunicationService.cs
// Medical Store Management System — SMS and WhatsApp messaging.
// SMS is sent through Twilio (NuGet package Twilio, version 7.14.9).
// WhatsApp messages are sent through the OFFICIAL WhatsApp Business
// Cloud API (Meta Graph API v26.0). A wa.me click-to-chat link needs
// no account at all — it simply opens WhatsApp on the user's phone.
//
// All account details come from App.config (appSettings). The values
// shipped in App.config are PLACEHOLDERS ONLY — replace them with your
// own Twilio and WhatsApp Business account details before sending.
// No real account, token or phone number is stored in this project.
//
// IMPORTANT — WhatsApp groups: no software can create a WhatsApp
// group through WhatsApp's official API. Groups are created in the
// WhatsApp app itself. What this class does is manage CONTACT GROUPS
// inside the program (for example "All Suppliers") and send a message
// to every phone number in the group, one message per contact, through
// the official WhatsApp Business API.
//
// Phone numbers: the sample data stores Pakistani numbers in local
// form, for example 0300-1111111. NormalizePhone() turns a local
// number into international form (+923001111111) before sending, and
// ValidatePhone() then checks that the final number starts with "+"
// and contains only digits. A number that cannot be normalised is
// rejected with a plain ArgumentException.
//
// Needs the NuGet packages Twilio 7.14.9 and
// System.Configuration.ConfigurationManager 8.0.1
// (see MedicalStoreManagementSystem.csproj). Sending needs internet.

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Net.Http;
using System.Text;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

namespace MedicalStoreManagementSystem
{
    // One contact group inside the program: a name and the phone
    // numbers that belong to it. Groups are built from the database,
    // not from WhatsApp — see GetContactGroups().
    public class ContactGroup
    {
        public string Name { get; set; }
        public List<string> Phones { get; set; }

        public ContactGroup(string name)
        {
            Name = name;
            Phones = new List<string>();
        }
    }

    public static class CommunicationService
    {
        // Meta Graph API version used for the WhatsApp Business Cloud API.
        // v26.0 was the current version in November 2026. If Meta retires
        // it, change this one value to the new current version.
        private const string GraphApiVersion = "v26.0";

        // Placeholder values shipped in App.config. A setting that still
        // holds its placeholder means "not configured yet".
        private const string TwilioSidPlaceholder = "ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
        private const string TwilioTokenPlaceholder = "YOUR_TWILIO_AUTH_TOKEN";
        private const string TwilioFromPlaceholder = "+10000000000";
        private const string WhatsAppIdPlaceholder = "YOUR_WHATSAPP_PHONE_NUMBER_ID";
        private const string WhatsAppTokenPlaceholder = "YOUR_WHATSAPP_ACCESS_TOKEN";

        private static string Setting(string key)
        {
            return ConfigurationManager.AppSettings[key] ?? "";
        }

        private static string TwilioAccountSid
        {
            get { return Setting("TwilioAccountSid"); }
        }

        private static string TwilioAuthToken
        {
            get { return Setting("TwilioAuthToken"); }
        }

        private static string TwilioFromNumber
        {
            get { return Setting("TwilioFromNumber"); }
        }

        private static string WhatsAppPhoneNumberId
        {
            get { return Setting("WhatsAppPhoneNumberId"); }
        }

        private static string WhatsAppAccessToken
        {
            get { return Setting("WhatsAppAccessToken"); }
        }

        private static string WhatsAppTemplateName
        {
            get
            {
                string name = Setting("WhatsAppTemplateName");
                return name == "" ? "hello_world" : name;
            }
        }

        // True only when the Twilio details in App.config are real values,
        // not the placeholders shipped with the project.
        public static bool IsTwilioConfigured
        {
            get
            {
                return TwilioAccountSid != "" && TwilioAccountSid != TwilioSidPlaceholder
                    && TwilioAuthToken != "" && TwilioAuthToken != TwilioTokenPlaceholder
                    && TwilioFromNumber != "" && TwilioFromNumber != TwilioFromPlaceholder;
            }
        }

        // True only when the WhatsApp Business details in App.config are
        // real values, not the placeholders shipped with the project.
        public static bool IsWhatsAppConfigured
        {
            get
            {
                return WhatsAppPhoneNumberId != "" && WhatsAppPhoneNumberId != WhatsAppIdPlaceholder
                    && WhatsAppAccessToken != "" && WhatsAppAccessToken != WhatsAppTokenPlaceholder;
            }
        }

        // Turn a phone number into international form.
        // "0300-1111111" becomes "+923001111111"; "+923001111111" and
        // "923001111111" are kept as "+923001111111". Spaces and dashes
        // are removed. Numbers from other countries keep their own
        // country code — only a leading 0 is treated as Pakistan (+92).
        public static string NormalizePhone(string phone)
        {
            if (phone == null)
            {
                return "";
            }

            string digits = phone.Trim().Replace(" ", "").Replace("-", "");
            if (digits.StartsWith("+"))
            {
                return digits;
            }
            if (digits.StartsWith("00"))
            {
                return "+" + digits.Substring(2);
            }
            if (digits.StartsWith("0"))
            {
                return "+92" + digits.Substring(1);
            }
            return "+" + digits;
        }

        // A phone number must start with "+" and contain only digits
        // after it, for example +923001234567.
        public static void ValidatePhone(string phone)
        {
            if (phone == null || phone.Length < 2 || !phone.StartsWith("+"))
            {
                throw new ArgumentException(
                    "Phone number must start with + and contain only digits, " +
                    "for example +923001234567.");
            }

            for (int i = 1; i < phone.Length; i++)
            {
                if (phone[i] < '0' || phone[i] > '9')
                {
                    throw new ArgumentException(
                        "Phone number must start with + and contain only digits, " +
                        "for example +923001234567.");
                }
            }
        }

        // Send one SMS through Twilio. Returns the Twilio message SID.
        // Throws InvalidOperationException if Twilio is not configured in
        // App.config, and ArgumentException if the number is not valid.
        public static string SendSms(string to, string message)
        {
            if (!IsTwilioConfigured)
            {
                throw new InvalidOperationException(
                    "Twilio is not configured. Put your own Twilio Account SID, " +
                    "Auth Token and Twilio phone number in App.config " +
                    "(see SETUP-GUIDE.txt, 'SMS AND WHATSAPP SETUP').");
            }

            string number = NormalizePhone(to);
            ValidatePhone(number);
            if (message == null || message.Trim() == "")
            {
                throw new ArgumentException("Message text must not be empty.");
            }

            TwilioClient.Init(TwilioAccountSid, TwilioAuthToken);
            MessageResource sent = MessageResource.Create(
                to: new PhoneNumber(number),
                from: new PhoneNumber(TwilioFromNumber),
                body: message);
            return sent.Sid;
        }

        // Send one WhatsApp template message through the official
        // WhatsApp Business Cloud API. Outside the 24-hour customer
        // service window, WhatsApp only allows template messages, so
        // this method always sends a template, never free text.
        // Returns the WhatsApp message ID from Meta's reply.
        // The phone number is sent without the leading "+" — that is
        // the format the WhatsApp API expects.
        public static string SendWhatsAppTemplate(string to, string templateName)
        {
            if (!IsWhatsAppConfigured)
            {
                throw new InvalidOperationException(
                    "WhatsApp is not configured. Put your own WhatsApp Business " +
                    "phone number ID and access token in App.config " +
                    "(see SETUP-GUIDE.txt, 'SMS AND WHATSAPP SETUP').");
            }

            string number = NormalizePhone(to);
            ValidatePhone(number);
            if (templateName == null || templateName.Trim() == "")
            {
                templateName = WhatsAppTemplateName;
            }

            string url = "https://graph.facebook.com/" + GraphApiVersion + "/" +
                WhatsAppPhoneNumberId + "/messages";
            string json = "{\"messaging_product\":\"whatsapp\",\"to\":\"" +
                number.Substring(1) +
                "\",\"type\":\"template\",\"template\":{\"name\":\"" +
                templateName.Trim() +
                "\",\"language\":{\"code\":\"en_US\"}}}";

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + WhatsAppAccessToken);
                using (HttpContent content = new StringContent(json, Encoding.UTF8, "application/json"))
                using (HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, url))
                {
                    request.Content = content;
                    using (HttpResponseMessage response = client.Send(request))
                    {
                        string reply = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                        if (!response.IsSuccessStatusCode)
                        {
                            throw new InvalidOperationException(
                                "WhatsApp API returned " + (int)response.StatusCode + ": " + reply);
                        }
                        return reply;
                    }
                }
            }
        }

        // Open a WhatsApp chat with this number in the browser or the
        // WhatsApp app (wa.me click-to-chat link). Needs no account,
        // no token and no API — it simply opens WhatsApp with the
        // message already typed. The user still presses Send in WhatsApp.
        public static void OpenWhatsAppChat(string to, string message)
        {
            string number = NormalizePhone(to);
            ValidatePhone(number);
            string digits = number.Substring(1);
            string url = "https://wa.me/" + digits;
            if (message != null && message.Trim() != "")
            {
                url += "?text=" + Uri.EscapeDataString(message);
            }
            Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
        }

        // Contact groups built from the database. "All Suppliers" holds
        // every phone number in the Suppliers table, "All Customers"
        // holds every phone number in the Customers table. Empty phone
        // numbers are left out. These are groups inside the program —
        // they are NOT WhatsApp groups (WhatsApp groups can only be
        // created in the WhatsApp app itself).
        public static List<ContactGroup> GetContactGroups()
        {
            List<ContactGroup> groups = new List<ContactGroup>();

            ContactGroup suppliers = new ContactGroup("All Suppliers");
            DataTable supplierPhones = DatabaseHelper.GetDataTable(
                "SELECT Phone FROM Suppliers WHERE Phone IS NOT NULL AND Phone <> '';");
            foreach (DataRow row in supplierPhones.Rows)
            {
                suppliers.Phones.Add(row["Phone"].ToString());
            }
            groups.Add(suppliers);

            ContactGroup customers = new ContactGroup("All Customers");
            DataTable customerPhones = DatabaseHelper.GetDataTable(
                "SELECT Phone FROM Customers WHERE Phone IS NOT NULL AND Phone <> '';");
            foreach (DataRow row in customerPhones.Rows)
            {
                customers.Phones.Add(row["Phone"].ToString());
            }
            groups.Add(customers);

            return groups;
        }

        // Send the same SMS to every number in a contact group.
        // Returns a short result, for example
        // "SMS sent to 3 of 3 numbers." Failures are listed, never hidden.
        public static string SendSmsToGroup(ContactGroup group, string message)
        {
            if (group == null || group.Phones.Count == 0)
            {
                return "No phone numbers in group '" +
                    (group == null ? "" : group.Name) + "'. Nothing was sent.";
            }

            int sent = 0;
            List<string> failures = new List<string>();
            foreach (string phone in group.Phones)
            {
                try
                {
                    SendSms(phone, message);
                    sent++;
                }
                catch (Exception ex)
                {
                    failures.Add(phone + ": " + ex.Message);
                }
            }

            string result = "SMS sent to " + sent + " of " + group.Phones.Count + " numbers.";
            if (failures.Count > 0)
            {
                result += " Failed: " + string.Join("; ", failures);
            }
            return result;
        }

        // Send the same WhatsApp template to every number in a contact group.
        // Returns a short result with the sent count and any failures.
        public static string SendWhatsAppToGroup(ContactGroup group, string templateName)
        {
            if (group == null || group.Phones.Count == 0)
            {
                return "No phone numbers in group '" +
                    (group == null ? "" : group.Name) + "'. Nothing was sent.";
            }

            int sent = 0;
            List<string> failures = new List<string>();
            foreach (string phone in group.Phones)
            {
                try
                {
                    SendWhatsAppTemplate(phone, templateName);
                    sent++;
                }
                catch (Exception ex)
                {
                    failures.Add(phone + ": " + ex.Message);
                }
            }

            string result = "WhatsApp sent to " + sent + " of " + group.Phones.Count + " numbers.";
            if (failures.Count > 0)
            {
                result += " Failed: " + string.Join("; ", failures);
            }
            return result;
        }
    }
}
