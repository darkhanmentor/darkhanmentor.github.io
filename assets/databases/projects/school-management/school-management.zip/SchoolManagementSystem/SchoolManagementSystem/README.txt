School Management System — C# Windows Forms + SQL Server (Oracle option included)
====================================================================================

A complete desktop project: manage students, teachers, classes and
subjects, record exam marks and monthly fees, and answer the questions
a school office asks every day — class results, fee defaulters,
students by class, the topper of each class and the monthly fee
collection — all stored in a SQL Server database.

WHAT IS INSIDE THIS PROJECT
- SchoolManagementSystem.sln — double-click this to open the project in Visual Studio.
- SchoolManagementSystem/ folder — the C# source code:
    Program.cs            — starts the app and opens the main window.
    MainForm.cs           — all the screen logic (add / update / delete / search students,
                            and the four practical query buttons).
    MainForm.Designer.cs  — the layout of the main window.
    CommunicationService.cs — SMS (Twilio) + WhatsApp (Business Cloud API) sending,
                            contact groups, and phone number checks.
    CommunicationForm.cs  — the SMS / WhatsApp window (group, number, message, Send).
    CommunicationForm.Designer.cs — the layout of the SMS / WhatsApp window.
    App.config            — your Twilio and WhatsApp account details
                            (placeholders only — replace with your own).
    DatabaseHelper.cs     — the connection string and all database calls.
    DatabaseScripts/      — the two database scripts:
        school-management-sqlserver.sql — SQL Server version (default).
        school-management-oracle.sql    — Oracle version.
- Screenshots/ folder — form previews rendered from the Designer.cs files
  (main window + SMS / WhatsApp window + one zoomed control each).
- SETUP-GUIDE.txt — full step-by-step setup for your own Windows laptop,
  including the connection string and troubleshooting. Read it first.
- The matching tutorial article and complete project report (PDF) are on
  the Database blog: https://database-learning-worldwide-dk.blogspot.com/

QUICK START (details in SETUP-GUIDE.txt)
1. Install Visual Studio 2022 Community (free) and SQL Server Express
   LocalDB (it comes with Visual Studio) or SQL Server 2022 Express.
2. In SQL Server Management Studio (SSMS), open and run
   DatabaseScripts/school-management-sqlserver.sql.
3. Double-click SchoolManagementSystem.sln, press F5, and the program runs.
   The main window shows the 6 sample students.

DATABASE: SchoolDB — tables: Teachers (4 rows), Classes (3 rows),
Subjects (4 rows), Students (6 rows), Exams (6 rows), Fees (6 rows).
CONNECTION (default, in DatabaseHelper.cs):
  Server=(localdb)\MSSQLLocalDB;Database=SchoolDB;Trusted_Connection=True;
For a full SQL Server Express instance use Server=.\SQLEXPRESS instead.
For Oracle, see the "Oracle option" section of the article and SETUP-GUIDE.txt.

REQUIREMENTS: Windows 10/11, Visual Studio 2022, .NET 8,
SQL Server Express / LocalDB (or Oracle XE for the Oracle version),
internet once for the first NuGet restore (Microsoft.Data.SqlClient,
Twilio 7.14.9 and System.Configuration.ConfigurationManager 8.0.1).
SMS needs a Twilio account and WhatsApp needs a Meta WhatsApp Business
app — both optional, see SETUP-GUIDE.txt "SMS AND WHATSAPP SETUP".
