// CommunicationService.cs
// School Management System — SMS and WhatsApp sending.
//
// Two channels, both through official services:
//   SMS       — Twilio (NuGet package Twilio, version 7.14.9).
//   WhatsApp  — the official WhatsApp Business Cloud API (Meta Graph
//               API v26.0), plus a wa.me click-to-chat link that needs
//               no account at all and simply opens WhatsApp.
//
// All secrets live in App.config (appSettings), never in this file.
// The values shipped in App.config are PLACEHOLDERS ONLY — replace
// them with your own Twilio and WhatsApp account details before you
// send anything. Until then, every send method throws a clear
// InvalidOperationException that tells you exactly what is missing.
//
// Phone numbers must be in international format, starting with "+",
// for example +923001234567. A Pakistani number typed the local way,
// 0300-1234567, is converted automatically to +923001234567.
//
// WhatsApp groups CANNOT be created by any software through the
// official WhatsApp API — groups are created in the WhatsApp app
// itself. What this file does instead is manage contact groups
// inside the program (for example "All Parents / Guardians") and
// send a message to every phone number in the group, one by one.

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

namespace SchoolManagementSystem
{
    /// <summary>
    /// One named group of phone numbers, for example "All Parents /
    /// Guardians". The group lives inside this program only — it is
    /// not a WhatsApp group (WhatsApp groups cannot be created by
    /// software through the official API).
    /// </summary>
    public class ContactGroup
    {
        public ContactGroup(string name)
        {
            Name = name;
            Phones = new List<string>();
        }

        public string Name { get; set; }
        public List<string> Phones { get; set; }

        public override string ToString()
        {
            return Name + " (" + Phones.Count + " numbers)";
        }
    }

    internal static class CommunicationService
    {
        // ---- Settings from App.config (placeholders until you edit it) ----

        private const string TwilioSidPlaceholder = "ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
        private const string TwilioTokenPlaceholder = "YOUR_TWILIO_AUTH_TOKEN";
        private const string TwilioFromPlaceholder = "+10000000000";
        private const string WhatsAppIdPlaceholder = "YOUR_WHATSAPP_PHONE_NUMBER_ID";
        private const string WhatsAppTokenPlaceholder = "YOUR_WHATSAPP_ACCESS_TOKEN";

        // Current Graph API version (Meta, released 29 July 2026).
        private const string GraphApiVersion = "v26.0";

        private static string Setting(string key)
        {
            return ConfigurationManager.AppSettings[key] ?? "";
        }

        public static string TwilioAccountSid
        {
            get { return Setting("TwilioAccountSid"); }
        }

        public static string TwilioAuthToken
        {
            get { return Setting("TwilioAuthToken"); }
        }

        public static string TwilioFromNumber
        {
            get { return Setting("TwilioFromNumber"); }
        }

        public static string WhatsAppPhoneNumberId
        {
            get { return Setting("WhatsAppPhoneNumberId"); }
        }

        public static string WhatsAppAccessToken
        {
            get { return Setting("WhatsAppAccessToken"); }
        }

        /// <summary>
        /// Approved WhatsApp template name. Default is "hello_world",
        /// the template Meta provides for testing.
        /// </summary>
        public static string WhatsAppTemplateName
        {
            get
            {
                string name = Setting("WhatsAppTemplateName");
                return string.IsNullOrWhiteSpace(name) ? "hello_world" : name.Trim();
            }
        }

        /// <summary>
        /// True only when real Twilio details (not the placeholders)
        /// are present in App.config.
        /// </summary>
        public static bool IsTwilioConfigured()
        {
            return !string.IsNullOrWhiteSpace(TwilioAccountSid)
                && TwilioAccountSid != TwilioSidPlaceholder
                && !string.IsNullOrWhiteSpace(TwilioAuthToken)
                && TwilioAuthToken != TwilioTokenPlaceholder
                && !string.IsNullOrWhiteSpace(TwilioFromNumber)
                && TwilioFromNumber != TwilioFromPlaceholder;
        }

        /// <summary>
        /// True only when real WhatsApp details (not the placeholders)
        /// are present in App.config.
        /// </summary>
        public static bool IsWhatsAppConfigured()
        {
            return !string.IsNullOrWhiteSpace(WhatsAppPhoneNumberId)
                && WhatsAppPhoneNumberId != WhatsAppIdPlaceholder
                && !string.IsNullOrWhiteSpace(WhatsAppAccessToken)
                && WhatsAppAccessToken != WhatsAppTokenPlaceholder;
        }

        // ---- Phone numbers ----

        /// <summary>
        /// Converts a number typed the local Pakistani way
        /// (0300-1234567) into international format (+923001234567).
        /// A number that already starts with "+" is returned as it is
        /// (spaces and dashes removed). Anything else is returned
        /// unchanged, so ValidatePhone below will reject it.
        /// </summary>
        public static string NormalizePhone(string phone)
        {
            if (string.IsNullOrWhiteSpace(phone))
            {
                return "";
            }

            string trimmed = phone.Trim();
            bool hasPlus = trimmed.StartsWith("+");
            string digits = new string(trimmed.Where(char.IsDigit).ToArray());

            if (hasPlus)
            {
                return "+" + digits;
            }

            if (digits.StartsWith("0"))
            {
                return "+92" + digits.Substring(1);
            }

            return digits;
        }

        /// <summary>
        /// A phone number must start with "+" and contain only digits
        /// after it, for example +923001234567.
        /// </summary>
        public static void ValidatePhone(string phone)
        {
            if (string.IsNullOrWhiteSpace(phone) || !phone.StartsWith("+"))
            {
                throw new ArgumentException(
                    "Phone number must start with + and the country code, " +
                    "for example +923001234567.");
            }

            string digits = phone.Substring(1);
            if (digits.Length == 0 || !digits.All(char.IsDigit))
            {
                throw new ArgumentException(
                    "Phone number must contain only digits after the + sign, " +
                    "for example +923001234567.");
            }
        }

        // ---- SMS (Twilio) ----

        /// <summary>
        /// Sends one SMS through Twilio. Returns a short confirmation.
        /// Throws InvalidOperationException when Twilio is not
        /// configured in App.config, and ArgumentException when the
        /// phone number or the message is wrong.
        /// </summary>
        public static string SendSms(string to, string message)
        {
            if (string.IsNullOrWhiteSpace(message))
            {
                throw new ArgumentException("Message text is empty.");
            }

            to = NormalizePhone(to);
            ValidatePhone(to);

            if (!IsTwilioConfigured())
            {
                throw new InvalidOperationException(
                    "Twilio is not configured. Open App.config and put your own " +
                    "Twilio Account SID, Auth Token and Twilio phone number in " +
                    "the appSettings (TwilioAccountSid, TwilioAuthToken, " +
                    "TwilioFromNumber). The values shipped with the project " +
                    "are placeholders only.");
            }

            TwilioClient.Init(TwilioAccountSid, TwilioAuthToken);
            MessageResource sent = MessageResource.Create(
                to: new PhoneNumber(to),
                from: new PhoneNumber(TwilioFromNumber),
                body: message);
            return "SMS sent to " + to + " (Twilio SID " + sent.Sid + ").";
        }

        // ---- WhatsApp (official Business Cloud API) ----

        /// <summary>
        /// Sends one approved WhatsApp template message through the
        /// official WhatsApp Business Cloud API (Graph API v26.0).
        /// Outside the 24-hour conversation window only template
        /// messages are allowed, which is why this method sends a
        /// template, not free text. Returns a short confirmation.
        /// Throws InvalidOperationException when WhatsApp is not
        /// configured in App.config or when Meta rejects the request
        /// (for example a 401 means a bad access token, and a template
        /// error means the template is not approved yet).
        /// </summary>
        public static string SendWhatsAppTemplate(string to, string templateName)
        {
            to = NormalizePhone(to);
            ValidatePhone(to);

            if (!IsWhatsAppConfigured())
            {
                throw new InvalidOperationException(
                    "WhatsApp is not configured. Open App.config and put your own " +
                    "WhatsApp Phone Number ID and Access Token in the appSettings " +
                    "(WhatsAppPhoneNumberId, WhatsAppAccessToken). The values " +
                    "shipped with the project are placeholders only.");
            }

            if (string.IsNullOrWhiteSpace(templateName))
            {
                templateName = WhatsAppTemplateName;
            }

            string url = "https://graph.facebook.com/" + GraphApiVersion + "/"
                + WhatsAppPhoneNumberId + "/messages";

            // The WhatsApp "to" field takes digits without the "+".
            string json = JsonSerializer.Serialize(new
            {
                messaging_product = "whatsapp",
                to = to.TrimStart('+'),
                type = "template",
                template = new
                {
                    name = templateName.Trim(),
                    language = new { code = "en_US" }
                }
            });

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", WhatsAppAccessToken);

                using (StringContent content =
                    new StringContent(json, Encoding.UTF8, "application/json"))
                using (HttpResponseMessage response = client.PostAsync(url, content)
                    .ConfigureAwait(false).GetAwaiter().GetResult())
                {
                    string body = response.Content.ReadAsStringAsync()
                        .ConfigureAwait(false).GetAwaiter().GetResult();

                    if (!response.IsSuccessStatusCode)
                    {
                        throw new InvalidOperationException(
                            "WhatsApp API returned " + (int)response.StatusCode
                            + " " + response.ReasonPhrase + ". " + body
                            + " A 401 means the access token is wrong or expired; " +
                            "a template error means the template is not approved yet.");
                    }

                    return "WhatsApp template '" + templateName.Trim()
                        + "' sent to " + to + ".";
                }
            }
        }

        /// <summary>
        /// Opens a WhatsApp chat with the number in the browser or the
        /// WhatsApp app (wa.me click-to-chat link). Needs no API
        /// account and sends nothing by itself — the user presses Send
        /// in WhatsApp. The message is URL-encoded into the link.
        /// </summary>
        public static void OpenWhatsAppChat(string to, string message)
        {
            to = NormalizePhone(to);
            ValidatePhone(to);

            string url = "https://wa.me/" + to.TrimStart('+')
                + "?text=" + Uri.EscapeDataString(message ?? "");
            Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
        }

        // ---- Contact groups (inside this program, not WhatsApp groups) ----

        /// <summary>
        /// The contact groups of this school, read from the database:
        /// "All Parents / Guardians" (the Phone column of Students —
        /// the parent/guardian number) and "All Teachers" (the Phone
        /// column of Teachers). These are groups inside the software;
        /// they are not WhatsApp groups.
        /// </summary>
        public static List<ContactGroup> GetContactGroups()
        {
            List<ContactGroup> groups = new List<ContactGroup>();

            ContactGroup parents = new ContactGroup("All Parents / Guardians");
            DataTable parentPhones = DatabaseHelper.GetDataTable(
                "SELECT Phone FROM Students WHERE Phone IS NOT NULL AND Phone <> '';");
            foreach (DataRow row in parentPhones.Rows)
            {
                string phone = row["Phone"] == DBNull.Value ? "" : row["Phone"].ToString().Trim();
                if (phone != "")
                {
                    parents.Phones.Add(phone);
                }
            }
            groups.Add(parents);

            ContactGroup teachers = new ContactGroup("All Teachers");
            DataTable teacherPhones = DatabaseHelper.GetDataTable(
                "SELECT Phone FROM Teachers WHERE Phone IS NOT NULL AND Phone <> '';");
            foreach (DataRow row in teacherPhones.Rows)
            {
                string phone = row["Phone"] == DBNull.Value ? "" : row["Phone"].ToString().Trim();
                if (phone != "")
                {
                    teachers.Phones.Add(phone);
                }
            }
            groups.Add(teachers);

            return groups;
        }

        /// <summary>
        /// Sends the same SMS to every number in the group, one by
        /// one. Returns a short result, for example "SMS: 6 of 6 sent
        /// to 'All Parents / Guardians'." Numbers that fail are listed
        /// in the result instead of stopping the whole send.
        /// </summary>
        public static string SendSmsToGroup(ContactGroup group, string message)
        {
            if (group == null)
            {
                throw new ArgumentException("No contact group was selected.");
            }

            int sent = 0;
            List<string> failures = new List<string>();
            foreach (string phone in group.Phones)
            {
                try
                {
                    SendSms(phone, message);
                    sent++;
                }
                catch (Exception ex)
                {
                    failures.Add(phone + ": " + ex.Message);
                }
            }

            string result = "SMS: " + sent + " of " + group.Phones.Count
                + " sent to '" + group.Name + "'.";
            if (failures.Count > 0)
            {
                result += " Failed: " + string.Join("; ", failures) + ".";
            }
            return result;
        }

        /// <summary>
        /// Sends the same approved WhatsApp template to every number
        /// in the group, one by one. Returns a short result with the
        /// sent count and any failures (same shape as SendSmsToGroup).
        /// </summary>
        public static string SendWhatsAppToGroup(ContactGroup group, string templateName)
        {
            if (group == null)
            {
                throw new ArgumentException("No contact group was selected.");
            }

            int sent = 0;
            List<string> failures = new List<string>();
            foreach (string phone in group.Phones)
            {
                try
                {
                    SendWhatsAppTemplate(phone, templateName);
                    sent++;
                }
                catch (Exception ex)
                {
                    failures.Add(phone + ": " + ex.Message);
                }
            }

            string result = "WhatsApp: " + sent + " of " + group.Phones.Count
                + " sent to '" + group.Name + "'.";
            if (failures.Count > 0)
            {
                result += " Failed: " + string.Join("; ", failures) + ".";
            }
            return result;
        }
    }
}
