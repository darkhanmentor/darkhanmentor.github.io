// CommunicationForm.cs
// School Management System — the SMS / WhatsApp window.
// The user picks a contact group (or "Single number"), types a phone
// number and a message, chooses SMS or WhatsApp, and clicks Send.
// "Open WhatsApp Chat" opens a wa.me chat link instead — it needs no
// account and sends nothing by itself. Every error is shown in the
// status label and in a message box, never hidden.

using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace SchoolManagementSystem
{
    public partial class CommunicationForm : Form
    {
        // The groups from CommunicationService.GetContactGroups().
        // cmbGroup index 0 is "Single number"; group i sits at index i + 1.
        private List<ContactGroup> groups = new List<ContactGroup>();

        public CommunicationForm()
        {
            InitializeComponent();
        }

        private void CommunicationForm_Load(object sender, EventArgs e)
        {
            rdoSms.Checked = true;
            LoadGroups();
        }

        // Fill the group drop-down from the database, plus a
        // "Single number" entry for sending to one phone number.
        private void LoadGroups()
        {
            try
            {
                groups = CommunicationService.GetContactGroups();
                cmbGroup.Items.Clear();
                cmbGroup.Items.Add("Single number");
                foreach (ContactGroup group in groups)
                {
                    cmbGroup.Items.Add(group.ToString());
                }
                cmbGroup.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Could not load contact groups: " + ex.Message;
                MessageBox.Show("Could not load contact groups from the database.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cmbGroup.Items.Clear();
                cmbGroup.Items.Add("Single number");
                cmbGroup.SelectedIndex = 0;
            }
        }

        /// <summary>
        /// Fills the form for one recipient — used by the main window's
        /// "Send fee reminder" button. Selects "Single number" so the
        /// message goes to exactly this phone number.
        /// </summary>
        public void Prefill(string toPhone, string message)
        {
            txtTo.Text = toPhone ?? "";
            txtMessage.Text = message ?? "";
            if (cmbGroup.Items.Count > 0)
            {
                cmbGroup.SelectedIndex = 0;
            }
        }

        // The group the user picked, or null when "Single number" is selected.
        private ContactGroup SelectedGroup()
        {
            int index = cmbGroup.SelectedIndex;
            if (index <= 0 || index - 1 >= groups.Count)
            {
                return null;
            }
            return groups[index - 1];
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                string message = txtMessage.Text.Trim();
                ContactGroup group = SelectedGroup();
                string result;

                if (rdoSms.Checked)
                {
                    result = group != null
                        ? CommunicationService.SendSmsToGroup(group, message)
                        : CommunicationService.SendSms(txtTo.Text.Trim(), message);
                }
                else
                {
                    result = group != null
                        ? CommunicationService.SendWhatsAppToGroup(group, CommunicationService.WhatsAppTemplateName)
                        : CommunicationService.SendWhatsAppTemplate(txtTo.Text.Trim(), CommunicationService.WhatsAppTemplateName);
                }

                lblStatus.Text = result;
                MessageBox.Show(result, "Message sent", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Error: " + ex.Message;
                MessageBox.Show(ex.Message, "Could not send", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnWhatsAppChat_Click(object sender, EventArgs e)
        {
            try
            {
                CommunicationService.OpenWhatsAppChat(txtTo.Text.Trim(), txtMessage.Text.Trim());
                lblStatus.Text = "WhatsApp chat opened for " + txtTo.Text.Trim() + ".";
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Error: " + ex.Message;
                MessageBox.Show(ex.Message, "Could not open WhatsApp", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
