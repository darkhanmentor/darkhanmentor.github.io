// MainForm.cs
// School Management System — main window.
// Shows all students in a grid and lets the user add, update, delete and
// search students. The four query buttons at the bottom run the practical
// queries from the project (class result, fee defaulters, students by
// class, monthly fee collection) and show the result in the same grid.
// All database work goes through DatabaseHelper, and every value typed
// by the user is passed as a parameter — never joined into the SQL text.

using System;
using System.Data;
using System.Globalization;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace SchoolManagementSystem
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            LoadClasses();
            LoadStudents();
        }

        // Fill the class drop-down from the Classes table.
        private void LoadClasses()
        {
            DataTable classes = DatabaseHelper.GetDataTable(
                "SELECT ClassId, ClassName FROM Classes ORDER BY ClassName;");

            cmbClass.DataSource = classes;
            cmbClass.DisplayMember = "ClassName";
            cmbClass.ValueMember = "ClassId";
        }

        // Show all students with their class names in the grid.
        private void LoadStudents()
        {
            try
            {
                DataTable students = DatabaseHelper.GetDataTable(
                    "SELECT s.StudentId, s.FullName, c.ClassName, s.RollNo, " +
                    "s.DateOfBirth, s.Phone, s.GuardianName, s.ClassId " +
                    "FROM Students s " +
                    "INNER JOIN Classes c ON s.ClassId = c.ClassId " +
                    "ORDER BY s.StudentId;");
                dgvStudents.DataSource = students;
                dgvStudents.Columns["ClassId"].Visible = false;
                lblStatus.Text = students.Rows.Count + " students loaded.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not load students. Check that SchoolDB exists " +
                    "and the connection string is correct.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // When a grid row is clicked, copy its values into the fields.
        private void dgvStudents_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
            {
                return;
            }

            // The grid also shows query results, which have no StudentId
            // column — only copy values when the full student list is shown.
            if (dgvStudents.Columns["StudentId"] == null)
            {
                return;
            }

            DataGridViewRow row = dgvStudents.Rows[e.RowIndex];
            txtStudentId.Text = row.Cells["StudentId"].Value.ToString();
            txtFullName.Text = row.Cells["FullName"].Value.ToString();
            cmbClass.SelectedValue = row.Cells["ClassId"].Value;
            txtRollNo.Text = row.Cells["RollNo"].Value.ToString();
            object dobValue = row.Cells["DateOfBirth"].Value;
            txtDateOfBirth.Text = (dobValue == null || dobValue == DBNull.Value)
                ? "" : Convert.ToDateTime(dobValue).ToString("yyyy-MM-dd");
            txtPhone.Text = row.Cells["Phone"].Value.ToString();
            txtGuardianName.Text = row.Cells["GuardianName"].Value.ToString();
        }

        // Read the form fields. Returns false and shows a message if
        // anything is missing or in the wrong format.
        private bool ReadFields(out string fullName, out int classId,
            out string rollNo, out DateTime dateOfBirth,
            out string phone, out string guardianName)
        {
            fullName = txtFullName.Text.Trim();
            classId = 0;
            rollNo = txtRollNo.Text.Trim();
            dateOfBirth = DateTime.MinValue;
            phone = txtPhone.Text.Trim();
            guardianName = txtGuardianName.Text.Trim();

            if (fullName == "" || rollNo == "")
            {
                MessageBox.Show("Student name and roll number are required.",
                    "Missing data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (cmbClass.SelectedValue == null)
            {
                MessageBox.Show("Choose a class for the student.",
                    "Missing data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            classId = (int)cmbClass.SelectedValue;

            // The date must be written as year-month-day, for example 2010-05-12.
            if (!DateTime.TryParseExact(txtDateOfBirth.Text.Trim(), "yyyy-MM-dd",
                CultureInfo.InvariantCulture, DateTimeStyles.None, out dateOfBirth))
            {
                MessageBox.Show("Date of birth must look like 2010-05-12 (year-month-day).",
                    "Wrong data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!ReadFields(out string fullName, out int classId,
                out string rollNo, out DateTime dateOfBirth,
                out string phone, out string guardianName))
            {
                return;
            }

            try
            {
                string sql = "INSERT INTO Students (FullName, ClassId, RollNo, " +
                    "DateOfBirth, Phone, GuardianName) " +
                    "VALUES (@Name, @ClassId, @RollNo, @Dob, @Phone, @Guardian);";
                int rows = DatabaseHelper.ExecuteNonQuery(sql,
                    new SqlParameter("@Name", fullName),
                    new SqlParameter("@ClassId", classId),
                    new SqlParameter("@RollNo", rollNo),
                    new SqlParameter("@Dob", SqlDbType.Date) { Value = dateOfBirth },
                    new SqlParameter("@Phone", phone),
                    new SqlParameter("@Guardian", guardianName));
                lblStatus.Text = "Student added. Rows affected: " + rows;
                ClearFields();
                LoadStudents();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not add the student.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtStudentId.Text.Trim() == "")
            {
                MessageBox.Show("Click a student in the grid first, then change the details.",
                    "No student selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!ReadFields(out string fullName, out int classId,
                out string rollNo, out DateTime dateOfBirth,
                out string phone, out string guardianName))
            {
                return;
            }

            try
            {
                string sql = "UPDATE Students SET FullName = @Name, ClassId = @ClassId, " +
                    "RollNo = @RollNo, DateOfBirth = @Dob, Phone = @Phone, " +
                    "GuardianName = @Guardian WHERE StudentId = @Id;";
                int rows = DatabaseHelper.ExecuteNonQuery(sql,
                    new SqlParameter("@Name", fullName),
                    new SqlParameter("@ClassId", classId),
                    new SqlParameter("@RollNo", rollNo),
                    new SqlParameter("@Dob", SqlDbType.Date) { Value = dateOfBirth },
                    new SqlParameter("@Phone", phone),
                    new SqlParameter("@Guardian", guardianName),
                    new SqlParameter("@Id", int.Parse(txtStudentId.Text.Trim())));
                lblStatus.Text = "Student updated. Rows affected: " + rows;
                ClearFields();
                LoadStudents();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not update the student.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (txtStudentId.Text.Trim() == "")
            {
                MessageBox.Show("Click a student in the grid first.",
                    "No student selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult answer = MessageBox.Show(
                "Delete student '" + txtFullName.Text.Trim() + "'? " +
                "A student with exam results or fee records cannot be deleted.",
                "Delete student", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer != DialogResult.Yes)
            {
                return;
            }

            try
            {
                string sql = "DELETE FROM Students WHERE StudentId = @Id;";
                int rows = DatabaseHelper.ExecuteNonQuery(sql,
                    new SqlParameter("@Id", int.Parse(txtStudentId.Text.Trim())));
                lblStatus.Text = "Student deleted. Rows affected: " + rows;
                ClearFields();
                LoadStudents();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not delete the student. A student with exam " +
                    "results or fee records cannot be deleted, because the Exams " +
                    "and Fees tables refer to the student.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearFields();
            LoadStudents();
        }

        private void ClearFields()
        {
            txtStudentId.Text = "";
            txtFullName.Text = "";
            txtRollNo.Text = "";
            txtDateOfBirth.Text = "";
            txtPhone.Text = "";
            txtGuardianName.Text = "";
            if (cmbClass.Items.Count > 0)
            {
                cmbClass.SelectedIndex = 0;
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string keyword = txtSearch.Text.Trim();
            if (keyword == "")
            {
                LoadStudents();
                return;
            }

            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT s.StudentId, s.FullName, c.ClassName, s.RollNo, " +
                    "s.DateOfBirth, s.Phone, s.GuardianName, s.ClassId " +
                    "FROM Students s " +
                    "INNER JOIN Classes c ON s.ClassId = c.ClassId " +
                    "WHERE s.FullName LIKE @Q OR s.RollNo LIKE @Q " +
                    "ORDER BY s.StudentId;",
                    new SqlParameter("@Q", "%" + keyword + "%"));
                dgvStudents.DataSource = result;
                dgvStudents.Columns["ClassId"].Visible = false;
                lblStatus.Text = result.Rows.Count + " students found for '" + keyword + "'.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Search failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadStudents();
        }

        // Open the SMS / WhatsApp window (CommunicationForm).
        private void btnCommunication_Click(object sender, EventArgs e)
        {
            using (CommunicationForm form = new CommunicationForm())
            {
                form.ShowDialog(this);
            }
        }

        // One-click fee reminder: for the student selected in the grid,
        // find the first unpaid fee and open the SMS / WhatsApp window
        // pre-filled with a reminder for the parent's phone number
        // (Students.Phone, the parent/guardian number).
        private void btnSendFeeReminder_Click(object sender, EventArgs e)
        {
            if (txtStudentId.Text.Trim() == "")
            {
                MessageBox.Show("Click a student in the grid first, then click 'Send fee reminder'.",
                    "No student selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtStudentId.Text.Trim(), out int studentId))
            {
                MessageBox.Show("Click a student in the grid first, then click 'Send fee reminder'.",
                    "No student selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                DataTable pending = DatabaseHelper.GetDataTable(
                    "SELECT TOP 1 s.FullName, c.ClassName, f.Month, f.Amount, s.Phone " +
                    "FROM Fees f " +
                    "INNER JOIN Students s ON f.StudentId = s.StudentId " +
                    "INNER JOIN Classes c ON s.ClassId = c.ClassId " +
                    "WHERE f.StudentId = @Id AND f.Status = 'Unpaid' ORDER BY f.FeeId;",
                    new SqlParameter("@Id", studentId));

                if (pending.Rows.Count == 0)
                {
                    MessageBox.Show("This student has no pending (Unpaid) fee.",
                        "No pending fee", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                DataRow row = pending.Rows[0];
                string studentName = row["FullName"].ToString();
                string className = row["ClassName"].ToString();
                string month = row["Month"].ToString();
                string amount = Convert.ToDecimal(row["Amount"]).ToString("0");
                string phone = row["Phone"] == DBNull.Value ? "" : row["Phone"].ToString();

                string message = "Fee reminder: " + studentName + " (" + className + ") " +
                    "has Rs " + amount + " fee pending for " + month + ". " +
                    "Please pay soon. — School Management System";

                using (CommunicationForm form = new CommunicationForm())
                {
                    form.Prefill(phone, message);
                    form.ShowDialog(this);
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not find the pending fee.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Query 1: class result — average marks per student in Class 9.
        // ClassId 1 is Class 9. To see another class, change the value
        // below to that class's id (2 is Class 10, 3 is Class 8).
        // Expected result: Ali Khan 85, Sara Ahmed 92; class average 88.5.
        private void btnClassResult_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT s.FullName AS Student, " +
                    "AVG(CAST(e.MarksObtained AS DECIMAL(5,2))) AS AverageMarks " +
                    "FROM Students s " +
                    "INNER JOIN Exams e ON e.StudentId = s.StudentId " +
                    "WHERE s.ClassId = @ClassId " +
                    "GROUP BY s.FullName ORDER BY s.FullName;",
                    new SqlParameter("@ClassId", 1));
                dgvStudents.DataSource = result;
                lblStatus.Text = "Class 9 result: average marks per student (class average 88.5).";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Query 2: fee defaulters — students whose fee Status is Unpaid.
        // Expected result: 3 rows — Sara Ahmed, Fatima Noor, Maryam Tariq.
        private void btnFeeDefaulters_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT s.FullName AS Student, c.ClassName, f.Month, f.Amount " +
                    "FROM Fees f " +
                    "INNER JOIN Students s ON f.StudentId = s.StudentId " +
                    "INNER JOIN Classes c ON s.ClassId = c.ClassId " +
                    "WHERE f.Status = 'Unpaid' ORDER BY s.FullName;");
                dgvStudents.DataSource = result;
                lblStatus.Text = "Fee defaulters: 3 students have not paid November 2026.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Query 3: students by class — all students of Class 9.
        // Expected result: 2 rows — Ali Khan (Roll No 1), Sara Ahmed (Roll No 2).
        private void btnStudentsByClass_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT s.FullName AS Student, s.RollNo, c.ClassName, c.Section " +
                    "FROM Students s " +
                    "INNER JOIN Classes c ON s.ClassId = c.ClassId " +
                    "WHERE s.ClassId = @ClassId ORDER BY s.RollNo;",
                    new SqlParameter("@ClassId", 1));
                dgvStudents.DataSource = result;
                lblStatus.Text = "Students of Class 9.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Query 5: monthly fee collection for November 2026.
        // Expected result: 15000 collected (3 Paid x 5000),
        // 15000 pending (3 Unpaid x 5000).
        private void btnMonthlyCollection_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT Month, " +
                    "SUM(CASE WHEN Status = 'Paid' THEN Amount ELSE 0 END) AS Collected, " +
                    "SUM(CASE WHEN Status = 'Unpaid' THEN Amount ELSE 0 END) AS Pending " +
                    "FROM Fees WHERE Month = @Month GROUP BY Month;",
                    new SqlParameter("@Month", "November 2026"));
                dgvStudents.DataSource = result;
                lblStatus.Text = "November 2026 fee collection: 15000 collected, 15000 pending.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
