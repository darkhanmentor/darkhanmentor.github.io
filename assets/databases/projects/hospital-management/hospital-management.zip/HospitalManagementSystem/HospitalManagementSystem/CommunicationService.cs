// CommunicationService.cs
// Hospital Management System — SMS and WhatsApp sending.
//
// Two channels, both through official services:
//   * SMS — Twilio (NuGet package Twilio, version 7.14.9).
//     TwilioClient.Init(sid, token), then MessageResource.Create(...).
//   * WhatsApp — the OFFICIAL WhatsApp Business Cloud API (Meta).
//     An HttpClient POST to https://graph.facebook.com/v26.0/<phone-number-id>/messages
//     with a Bearer access token and an approved message template.
//     There is also a wa.me click-to-chat link, which needs no account at
//     all — it simply opens WhatsApp on the phone or in the browser.
//
// All secrets live in App.config (appSettings), NEVER in this file:
//   TwilioAccountSid, TwilioAuthToken, TwilioFromNumber,
//   WhatsAppPhoneNumberId, WhatsAppAccessToken, WhatsAppTemplateName.
// The values shipped in App.config are PLACEHOLDERS ONLY. Put your own
// Twilio and WhatsApp Business account details there before sending.
// Until then, SendSms / SendWhatsAppTemplate throw an
// InvalidOperationException that says exactly that — they never pretend
// a message was sent.
//
// Contact groups: WhatsApp groups cannot be created by any software
// through WhatsApp's official API — groups are created in the WhatsApp
// app itself. What this class does is manage contact groups INSIDE the
// software (for example "All Patients" and "All Doctors") and send a
// message to every phone number in the group, one message per contact,
// through the official API.
//
// Phone numbers: the sample data stores Pakistani numbers in local
// form, for example "0300-1234567". NormalizePhone turns that into
// international form (+923001234567) before sending. A number that
// cannot be understood is rejected with a plain ArgumentException.
//
// Errors are never swallowed: if Twilio or WhatsApp rejects a message,
// the exception reaches the caller, and the group senders report how
// many messages went out and which numbers failed.

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

namespace HospitalManagementSystem
{
    // One contact group inside the software: a name and a list of phone numbers.
    public class ContactGroup
    {
        public string Name { get; set; }
        public List<string> Phones { get; set; }

        public ContactGroup(string name)
        {
            Name = name;
            Phones = new List<string>();
        }
    }

    public static class CommunicationService
    {
        // Placeholder values shipped in App.config. Anything still equal
        // to one of these means "the user has not put their own details in".
        private const string PlaceholderSid = "ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
        private const string PlaceholderToken = "YOUR_TWILIO_AUTH_TOKEN";
        private const string PlaceholderFrom = "+10000000000";
        private const string PlaceholderPhoneNumberId = "YOUR_WHATSAPP_PHONE_NUMBER_ID";
        private const string PlaceholderAccessToken = "YOUR_WHATSAPP_ACCESS_TOKEN";

        // Meta Graph API version used for the WhatsApp Business Cloud API.
        // v26.0 is the current version (released 29 July 2026).
        private const string GraphApiVersion = "v26.0";

        private static string Setting(string key)
        {
            string value = ConfigurationManager.AppSettings[key];
            return value == null ? "" : value.Trim();
        }

        private static string TwilioSid
        {
            get { return Setting("TwilioAccountSid"); }
        }

        private static string TwilioToken
        {
            get { return Setting("TwilioAuthToken"); }
        }

        private static string TwilioFrom
        {
            get { return Setting("TwilioFromNumber"); }
        }

        private static string WhatsAppPhoneNumberId
        {
            get { return Setting("WhatsAppPhoneNumberId"); }
        }

        private static string WhatsAppToken
        {
            get { return Setting("WhatsAppAccessToken"); }
        }

        private static string WhatsAppTemplate
        {
            get
            {
                string template = Setting("WhatsAppTemplateName");
                return template == "" ? "hello_world" : template;
            }
        }

        // True only when the user has replaced the placeholders with
        // their own Twilio account details in App.config.
        public static bool IsTwilioConfigured
        {
            get
            {
                return TwilioSid != "" && TwilioSid != PlaceholderSid
                    && TwilioToken != "" && TwilioToken != PlaceholderToken
                    && TwilioFrom != "" && TwilioFrom != PlaceholderFrom;
            }
        }

        // True only when the user has replaced the placeholders with
        // their own WhatsApp Business account details in App.config.
        public static bool IsWhatsAppConfigured
        {
            get
            {
                return WhatsAppPhoneNumberId != ""
                    && WhatsAppPhoneNumberId != PlaceholderPhoneNumberId
                    && WhatsAppToken != "" && WhatsAppToken != PlaceholderAccessToken;
            }
        }

        // Turn a phone number into international (E.164) form.
        // "0300-1234567" -> "+923001234567"; "+92 300 1234567" -> "+923001234567".
        // A number that is already international is returned as it is.
        public static string NormalizePhone(string phone)
        {
            if (phone == null)
            {
                return "";
            }

            string digits = phone.Trim()
                .Replace(" ", "").Replace("-", "").Replace("(", "").Replace(")", "");

            if (digits.StartsWith("+"))
            {
                return digits;
            }

            if (digits.StartsWith("0") && digits.Length > 1)
            {
                // Pakistani local number: drop the leading 0, add +92.
                return "+92" + digits.Substring(1);
            }

            if (digits.StartsWith("92") && digits.Length > 2)
            {
                return "+" + digits;
            }

            return digits;
        }

        // A phone number is valid only in international form: a leading "+"
        // followed by 10 to 15 digits. Anything else is rejected with a
        // plain message instead of being sent and failing silently.
        private static string ValidatePhone(string phone)
        {
            string normalized = NormalizePhone(phone);

            if (normalized == "" || !normalized.StartsWith("+"))
            {
                throw new ArgumentException(
                    "Phone number must start with '+' and contain only digits, " +
                    "for example +923001234567. Got: '" + phone + "'.");
            }

            string digits = normalized.Substring(1);
            if (digits.Length < 10 || digits.Length > 15)
            {
                throw new ArgumentException(
                    "Phone number must have 10 to 15 digits after '+'. Got: '" + phone + "'.");
            }

            foreach (char c in digits)
            {
                if (c < '0' || c > '9')
                {
                    throw new ArgumentException(
                        "Phone number must contain only digits after '+'. Got: '" + phone + "'.");
                }
            }

            return normalized;
        }

        // Send one SMS through Twilio.
        // Throws InvalidOperationException if Twilio is not configured in
        // App.config, and ArgumentException if the number is not valid.
        public static string SendSms(string to, string message)
        {
            if (!IsTwilioConfigured)
            {
                throw new InvalidOperationException(
                    "Twilio is not configured. Open App.config and put your own " +
                    "Twilio account details there: TwilioAccountSid, TwilioAuthToken " +
                    "and TwilioFromNumber (see SETUP-GUIDE.txt, 'SMS AND WHATSAPP SETUP').");
            }

            string toNumber = ValidatePhone(to);
            if (message == null || message.Trim() == "")
            {
                throw new ArgumentException("Message text must not be empty.");
            }

            TwilioClient.Init(TwilioSid, TwilioToken);
            MessageResource sent = MessageResource.Create(
                to: new PhoneNumber(toNumber),
                from: new PhoneNumber(TwilioFrom),
                body: message);
            return sent.Sid;
        }

        // Send one WhatsApp template message through the OFFICIAL WhatsApp
        // Business Cloud API. Outside the 24-hour customer-service window,
        // WhatsApp only allows template messages, so this sends a template
        // (default "hello_world") instead of free text.
        // Throws InvalidOperationException if WhatsApp is not configured in
        // App.config, and ArgumentException if the number is not valid.
        public static string SendWhatsAppTemplate(string to, string templateName)
        {
            if (!IsWhatsAppConfigured)
            {
                throw new InvalidOperationException(
                    "WhatsApp is not configured. Open App.config and put your own " +
                    "WhatsApp Business account details there: WhatsAppPhoneNumberId " +
                    "and WhatsAppAccessToken (see SETUP-GUIDE.txt, 'SMS AND WHATSAPP SETUP').");
            }

            string toNumber = ValidatePhone(to);
            string template = (templateName == null || templateName.Trim() == "")
                ? WhatsAppTemplate : templateName.Trim();

            string url = "https://graph.facebook.com/" + GraphApiVersion + "/"
                + WhatsAppPhoneNumberId + "/messages";

            string json = JsonSerializer.Serialize(new
            {
                messaging_product = "whatsapp",
                to = toNumber,
                type = "template",
                template = new
                {
                    name = template,
                    language = new { code = "en_US" }
                }
            });

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + WhatsAppToken);
                using (StringContent content = new StringContent(json, Encoding.UTF8, "application/json"))
                using (HttpResponseMessage response = client.PostAsync(url, content).GetAwaiter().GetResult())
                {
                    string body = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                    if (!response.IsSuccessStatusCode)
                    {
                        throw new InvalidOperationException(
                            "WhatsApp API returned " + (int)response.StatusCode + " "
                            + response.ReasonPhrase + ". " + body);
                    }
                    return body;
                }
            }
        }

        // Open a wa.me click-to-chat link in the browser / WhatsApp.
        // Needs NO account and NO configuration — it simply opens a chat
        // with the number and the message already typed, and the user
        // presses Send in WhatsApp itself.
        public static void OpenWhatsAppChat(string to, string message)
        {
            string toNumber = ValidatePhone(to);
            string digits = toNumber.Substring(1); // wa.me takes digits only, no "+"
            string url = "https://wa.me/" + digits + "?text=" + Uri.EscapeDataString(message ?? "");
            Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
        }

        // Contact groups inside the software. These are NOT WhatsApp
        // groups — WhatsApp groups can only be created in the WhatsApp
        // app itself. These groups are lists of phone numbers read from
        // the database, so one message can be sent to all of them.
        public static List<ContactGroup> GetContactGroups()
        {
            List<ContactGroup> groups = new List<ContactGroup>();

            ContactGroup patients = new ContactGroup("All Patients");
            DataTable patientPhones = DatabaseHelper.GetDataTable(
                "SELECT Phone FROM Patients WHERE Phone IS NOT NULL AND Phone <> '';");
            foreach (DataRow row in patientPhones.Rows)
            {
                patients.Phones.Add(row["Phone"].ToString());
            }
            groups.Add(patients);

            ContactGroup doctors = new ContactGroup("All Doctors");
            DataTable doctorPhones = DatabaseHelper.GetDataTable(
                "SELECT Phone FROM Doctors WHERE Phone IS NOT NULL AND Phone <> '';");
            foreach (DataRow row in doctorPhones.Rows)
            {
                doctors.Phones.Add(row["Phone"].ToString());
            }
            groups.Add(doctors);

            return groups;
        }

        // Send the same SMS to every number in a group. Returns a short
        // result, for example: "Sent 6 of 6 SMS messages."
        // A number that fails does not stop the rest — failures are listed.
        public static string SendSmsToGroup(ContactGroup group, string message)
        {
            if (group == null)
            {
                throw new ArgumentException("Choose a contact group first.");
            }

            int sent = 0;
            List<string> failed = new List<string>();
            foreach (string phone in group.Phones)
            {
                try
                {
                    SendSms(phone, message);
                    sent++;
                }
                catch (Exception ex)
                {
                    failed.Add(phone + " (" + ex.Message + ")");
                }
            }

            string result = "Sent " + sent + " of " + group.Phones.Count
                + " SMS messages to '" + group.Name + "'.";
            if (failed.Count > 0)
            {
                result += " Failed: " + string.Join("; ", failed.ToArray());
            }
            return result;
        }

        // Send the same WhatsApp template message to every number in a group.
        public static string SendWhatsAppToGroup(ContactGroup group, string templateName)
        {
            if (group == null)
            {
                throw new ArgumentException("Choose a contact group first.");
            }

            int sent = 0;
            List<string> failed = new List<string>();
            foreach (string phone in group.Phones)
            {
                try
                {
                    SendWhatsAppTemplate(phone, templateName);
                    sent++;
                }
                catch (Exception ex)
                {
                    failed.Add(phone + " (" + ex.Message + ")");
                }
            }

            string result = "Sent " + sent + " of " + group.Phones.Count
                + " WhatsApp messages to '" + group.Name + "'.";
            if (failed.Count > 0)
            {
                result += " Failed: " + string.Join("; ", failed.ToArray());
            }
            return result;
        }
    }
}
