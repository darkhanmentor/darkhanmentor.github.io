// CommunicationForm.cs
// Hospital Management System — the SMS / WhatsApp window.
// The user picks a contact group (or "Single number"), types a message,
// chooses SMS or WhatsApp, and clicks Send. The message is sent through
// CommunicationService: SMS through Twilio, WhatsApp through the official
// WhatsApp Business Cloud API. "Open WhatsApp Chat" opens a wa.me link,
// which needs no account — it simply opens WhatsApp with the message
// already typed.
// Every error is shown to the user in a message box and in lblStatus.
// Errors are never swallowed: if nothing is configured, or a number is
// wrong, the user sees exactly why.

using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace HospitalManagementSystem
{
    public partial class CommunicationForm : Form
    {
        private List<ContactGroup> groups = new List<ContactGroup>();

        public CommunicationForm()
        {
            InitializeComponent();
        }

        private void CommunicationForm_Load(object sender, EventArgs e)
        {
            rdoSms.Checked = true;
            cmbGroup.Items.Add("Single number");
            try
            {
                groups = CommunicationService.GetContactGroups();
                foreach (ContactGroup group in groups)
                {
                    cmbGroup.Items.Add(group.Name + " (" + group.Phones.Count + ")");
                }
            }
            catch (Exception ex)
            {
                // The database could not be read, so groups are not available.
                // Single-number sending still works — say so plainly.
                lblStatus.Text = "Contact groups could not be loaded: " + ex.Message;
            }
            cmbGroup.SelectedIndex = 0;
        }

        // Fill the form from another screen — MainForm uses this for the
        // one-click appointment reminder (phone + message already filled in).
        public void Prefill(string toPhone, string message)
        {
            txtTo.Text = toPhone;
            txtMessage.Text = message;
            cmbGroup.SelectedIndex = 0;
        }

        private void cmbGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            // A group sends to all its members, so the single-number box
            // is only for "Single number".
            txtTo.Enabled = cmbGroup.SelectedIndex == 0;
        }

        private ContactGroup SelectedGroup()
        {
            if (cmbGroup.SelectedIndex <= 0)
            {
                return null;
            }
            return groups[cmbGroup.SelectedIndex - 1];
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            string message = txtMessage.Text.Trim();
            ContactGroup group = SelectedGroup();

            try
            {
                string result;
                if (group != null)
                {
                    if (rdoSms.Checked)
                    {
                        result = CommunicationService.SendSmsToGroup(group, message);
                    }
                    else
                    {
                        result = CommunicationService.SendWhatsAppToGroup(group, null);
                    }
                }
                else
                {
                    string to = txtTo.Text.Trim();
                    if (to == "")
                    {
                        MessageBox.Show("Type a phone number, or pick a contact group.",
                            "No recipient", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    if (rdoSms.Checked)
                    {
                        CommunicationService.SendSms(to, message);
                        result = "SMS sent to " + to + ".";
                    }
                    else
                    {
                        CommunicationService.SendWhatsAppTemplate(to, null);
                        result = "WhatsApp message sent to " + to + ".";
                    }
                }

                lblStatus.Text = result;
                MessageBox.Show(result, "Message sent", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Failed: " + ex.Message;
                MessageBox.Show("Could not send the message.\n\n" + ex.Message,
                    "Send failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnWhatsAppChat_Click(object sender, EventArgs e)
        {
            try
            {
                string to = txtTo.Text.Trim();
                if (to == "")
                {
                    MessageBox.Show("Type a phone number first — the chat opens for that number.",
                        "No number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                CommunicationService.OpenWhatsAppChat(to, txtMessage.Text);
                lblStatus.Text = "WhatsApp chat opened for " + to + ".";
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Failed: " + ex.Message;
                MessageBox.Show("Could not open the WhatsApp chat.\n\n" + ex.Message,
                    "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
