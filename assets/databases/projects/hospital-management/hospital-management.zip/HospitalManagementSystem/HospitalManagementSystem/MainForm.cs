// MainForm.cs
// Hospital Management System — main window.
// Shows all patients in a grid and lets the user add, update, delete and
// search patients. The four query buttons at the bottom run the practical
// queries from the project (a doctor's appointments, a patient's history,
// pending bills, appointments by date) and show the result in the same grid.
// All database work goes through DatabaseHelper, and every value typed
// by the user is passed as a parameter — never joined into the SQL text.

using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace HospitalManagementSystem
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            cmbGender.Items.Add("Male");
            cmbGender.Items.Add("Female");
            LoadPatients();
        }

        // Show all patients in the grid.
        private void LoadPatients()
        {
            try
            {
                DataTable patients = DatabaseHelper.GetDataTable(
                    "SELECT PatientId, FullName, Age, Gender, Phone, Address " +
                    "FROM Patients ORDER BY PatientId;");
                dgvPatients.DataSource = patients;
                lblStatus.Text = patients.Rows.Count + " patients loaded.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not load patients. Check that HospitalDB exists " +
                    "and the connection string is correct.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // When a grid row is clicked, copy its values into the fields.
        private void dgvPatients_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
            {
                return;
            }

            DataGridViewRow row = dgvPatients.Rows[e.RowIndex];
            txtPatientId.Text = row.Cells["PatientId"].Value.ToString();
            txtFullName.Text = row.Cells["FullName"].Value.ToString();
            txtAge.Text = row.Cells["Age"].Value.ToString();
            cmbGender.SelectedItem = row.Cells["Gender"].Value.ToString();
            txtPhone.Text = row.Cells["Phone"].Value.ToString();
            txtAddress.Text = row.Cells["Address"].Value.ToString();
        }

        // Read the form fields. Returns false and shows a message if
        // anything is missing or in the wrong format.
        private bool ReadFields(out string fullName, out int age,
            out string gender, out string phone, out string address)
        {
            fullName = txtFullName.Text.Trim();
            age = 0;
            gender = cmbGender.SelectedItem == null ? "" : cmbGender.SelectedItem.ToString();
            phone = txtPhone.Text.Trim();
            address = txtAddress.Text.Trim();

            if (fullName == "")
            {
                MessageBox.Show("Patient name is required.",
                    "Missing data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!int.TryParse(txtAge.Text.Trim(), out age) || age < 0 || age > 120)
            {
                MessageBox.Show("Age must be a whole number between 0 and 120.",
                    "Wrong data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (gender == "")
            {
                MessageBox.Show("Choose a gender (Male or Female).",
                    "Missing data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!ReadFields(out string fullName, out int age,
                out string gender, out string phone, out string address))
            {
                return;
            }

            try
            {
                string sql = "INSERT INTO Patients (FullName, Age, Gender, Phone, Address) " +
                    "VALUES (@Name, @Age, @Gender, @Phone, @Address);";
                int rows = DatabaseHelper.ExecuteNonQuery(sql,
                    new SqlParameter("@Name", fullName),
                    new SqlParameter("@Age", age),
                    new SqlParameter("@Gender", gender),
                    new SqlParameter("@Phone", phone),
                    new SqlParameter("@Address", address));
                lblStatus.Text = "Patient added. Rows affected: " + rows;
                ClearFields();
                LoadPatients();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not add the patient.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtPatientId.Text.Trim() == "")
            {
                MessageBox.Show("Click a patient in the grid first, then change the details.",
                    "No patient selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!ReadFields(out string fullName, out int age,
                out string gender, out string phone, out string address))
            {
                return;
            }

            try
            {
                string sql = "UPDATE Patients SET FullName = @Name, Age = @Age, " +
                    "Gender = @Gender, Phone = @Phone, Address = @Address " +
                    "WHERE PatientId = @Id;";
                int rows = DatabaseHelper.ExecuteNonQuery(sql,
                    new SqlParameter("@Name", fullName),
                    new SqlParameter("@Age", age),
                    new SqlParameter("@Gender", gender),
                    new SqlParameter("@Phone", phone),
                    new SqlParameter("@Address", address),
                    new SqlParameter("@Id", int.Parse(txtPatientId.Text.Trim())));
                lblStatus.Text = "Patient updated. Rows affected: " + rows;
                ClearFields();
                LoadPatients();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not update the patient.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (txtPatientId.Text.Trim() == "")
            {
                MessageBox.Show("Click a patient in the grid first.",
                    "No patient selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult answer = MessageBox.Show(
                "Delete patient '" + txtFullName.Text.Trim() + "'? " +
                "A patient with appointments cannot be deleted.",
                "Delete patient", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer != DialogResult.Yes)
            {
                return;
            }

            try
            {
                string sql = "DELETE FROM Patients WHERE PatientId = @Id;";
                int rows = DatabaseHelper.ExecuteNonQuery(sql,
                    new SqlParameter("@Id", int.Parse(txtPatientId.Text.Trim())));
                lblStatus.Text = "Patient deleted. Rows affected: " + rows;
                ClearFields();
                LoadPatients();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not delete the patient. A patient with " +
                    "appointments cannot be deleted because the Appointments table " +
                    "refers to them.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearFields();
            LoadPatients();
        }

        private void ClearFields()
        {
            txtPatientId.Text = "";
            txtFullName.Text = "";
            txtAge.Text = "";
            cmbGender.SelectedIndex = -1;
            txtPhone.Text = "";
            txtAddress.Text = "";
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string keyword = txtSearch.Text.Trim();
            if (keyword == "")
            {
                LoadPatients();
                return;
            }

            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT PatientId, FullName, Age, Gender, Phone, Address " +
                    "FROM Patients WHERE FullName LIKE @Q ORDER BY PatientId;",
                    new SqlParameter("@Q", "%" + keyword + "%"));
                dgvPatients.DataSource = result;
                lblStatus.Text = result.Rows.Count + " patients found for '" + keyword + "'.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Search failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadPatients();
        }

        // Query 1: all appointments of one doctor.
        // DoctorId 1 is Dr. Ahmed Khan (Cardiology). Change the number
        // below to see another doctor's appointments — for example 2 for
        // Dr. Sara Malik or 5 for Dr. Usman Raza.
        // Expected result for Dr. Ahmed Khan: 2 rows — Appointment 1
        // (20 Nov, 10:00, Scheduled) and Appointment 6 (21 Nov, 11:00, Cancelled).
        private void btnDoctorAppointments_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT a.AppointmentId, p.FullName AS Patient, " +
                    "a.AppointmentDate, a.AppointmentTime, a.Status " +
                    "FROM Appointments a " +
                    "INNER JOIN Patients p ON a.PatientId = p.PatientId " +
                    "WHERE a.DoctorId = @DoctorId " +
                    "ORDER BY a.AppointmentDate, a.AppointmentTime;",
                    new SqlParameter("@DoctorId", 1));
                dgvPatients.DataSource = result;
                lblStatus.Text = "Appointments of Dr. Ahmed Khan (2 appointments).";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Query 2: full history of one patient — appointments, doctor,
        // treatment and bill. Ali Raza has Appointment 1 with
        // Dr. Ahmed Khan on 2026-11-20 and Bill 1 (3000, Paid).
        // Change 'Ali Raza' below to see another patient's history.
        private void btnPatientHistory_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT p.FullName AS Patient, d.FullName AS Doctor, " +
                    "a.AppointmentDate, a.AppointmentTime, t.Diagnosis, " +
                    "t.Prescription, b.TotalAmount, b.PaidAmount, b.Status AS BillStatus " +
                    "FROM Patients p " +
                    "INNER JOIN Appointments a ON a.PatientId = p.PatientId " +
                    "INNER JOIN Doctors d ON a.DoctorId = d.DoctorId " +
                    "LEFT JOIN Treatments t ON t.AppointmentId = a.AppointmentId " +
                    "LEFT JOIN Bills b ON b.AppointmentId = a.AppointmentId " +
                    "WHERE p.FullName = @Name ORDER BY a.AppointmentDate;",
                    new SqlParameter("@Name", "Ali Raza"));
                dgvPatients.DataSource = result;
                lblStatus.Text = "History of patient Ali Raza.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Query 3: bills that are still pending — Unpaid or only partly paid.
        // Expected result: 2 rows — Bill 2 (Ayesha Khan, Partial) and
        // Bill 3 (Hassan Ali, Unpaid).
        private void btnPendingBills_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT b.BillId, p.FullName AS Patient, " +
                    "b.TotalAmount, b.PaidAmount, b.BillDate, b.Status " +
                    "FROM Bills b " +
                    "INNER JOIN Patients p ON b.PatientId = p.PatientId " +
                    "WHERE b.Status IN ('Unpaid', 'Partial') ORDER BY b.BillId;");
                dgvPatients.DataSource = result;
                lblStatus.Text = "Pending bills: 2 bills.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Query 4: all appointments on one date (2026-11-20).
        // Expected result: 3 rows — Appointments 1, 2 and 3.
        // Change the date below to see another day's appointments.
        private void btnAppointmentsByDate_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT a.AppointmentId, p.FullName AS Patient, " +
                    "d.FullName AS Doctor, a.AppointmentTime, a.Status " +
                    "FROM Appointments a " +
                    "INNER JOIN Patients p ON a.PatientId = p.PatientId " +
                    "INNER JOIN Doctors d ON a.DoctorId = d.DoctorId " +
                    "WHERE a.AppointmentDate = @Date ORDER BY a.AppointmentTime;",
                    new SqlParameter("@Date", new DateTime(2026, 11, 20)));
                dgvPatients.DataSource = result;
                lblStatus.Text = "Appointments on 20 Nov 2026: 3 appointments.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Open the SMS / WhatsApp window. From there the user can send
        // an SMS or a WhatsApp message to one number or to a whole
        // contact group (All Patients or All Doctors).
        private void btnCommunication_Click(object sender, EventArgs e)
        {
            using (CommunicationForm form = new CommunicationForm())
            {
                form.ShowDialog(this);
            }
        }

        // One-click appointment reminder. Uses the row selected in the grid:
        //   * If the grid shows appointments (after "Doctor's Appointments"
        //     or "Appointments by Date"), the AppointmentId column gives the
        //     appointment, and the patient's phone, the doctor's name, the
        //     date and the time are read from the database.
        //   * If the grid shows patients, the PatientId column gives the
        //     patient, and their next Scheduled appointment is used.
        // The reminder message and the patient's phone are then pre-filled
        // in the SMS / WhatsApp window — the user picks SMS or WhatsApp
        // and clicks Send there. Nothing is sent from this button itself.
        private void btnSendReminder_Click(object sender, EventArgs e)
        {
            if (dgvPatients.CurrentRow == null)
            {
                MessageBox.Show("Click an appointment or a patient in the grid first.",
                    "Nothing selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                DataGridViewRow row = dgvPatients.CurrentRow;
                DataTable appointment;

                if (dgvPatients.Columns.Contains("AppointmentId")
                    && row.Cells["AppointmentId"].Value != null)
                {
                    int appointmentId = Convert.ToInt32(row.Cells["AppointmentId"].Value);
                    appointment = DatabaseHelper.GetDataTable(
                        "SELECT p.Phone, d.FullName AS Doctor, " +
                        "a.AppointmentDate, a.AppointmentTime " +
                        "FROM Appointments a " +
                        "INNER JOIN Patients p ON a.PatientId = p.PatientId " +
                        "INNER JOIN Doctors d ON a.DoctorId = d.DoctorId " +
                        "WHERE a.AppointmentId = @Id;",
                        new SqlParameter("@Id", appointmentId));
                }
                else if (dgvPatients.Columns.Contains("PatientId")
                    && row.Cells["PatientId"].Value != null)
                {
                    int patientId = Convert.ToInt32(row.Cells["PatientId"].Value);
                    appointment = DatabaseHelper.GetDataTable(
                        "SELECT TOP 1 p.Phone, d.FullName AS Doctor, " +
                        "a.AppointmentDate, a.AppointmentTime " +
                        "FROM Appointments a " +
                        "INNER JOIN Patients p ON a.PatientId = p.PatientId " +
                        "INNER JOIN Doctors d ON a.DoctorId = d.DoctorId " +
                        "WHERE a.PatientId = @Id AND a.Status = 'Scheduled' " +
                        "ORDER BY a.AppointmentDate, a.AppointmentTime;",
                        new SqlParameter("@Id", patientId));
                }
                else
                {
                    MessageBox.Show("Click an appointment or a patient in the grid first. " +
                        "Run 'Doctor's Appointments' or 'Appointments by Date' to see appointments, " +
                        "or click a patient row in the patient list.",
                        "Nothing selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (appointment.Rows.Count == 0)
                {
                    MessageBox.Show("No appointment was found for the selected row. " +
                        "For a patient, only a future Scheduled appointment can be reminded about.",
                        "No appointment", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DataRow appt = appointment.Rows[0];
                string phone = appt["Phone"] == DBNull.Value ? "" : appt["Phone"].ToString();
                // Doctor names in the database already start with "Dr. ",
                // so strip it first to avoid "Dr. Dr. Ahmed Khan".
                string doctorName = appt["Doctor"].ToString();
                if (doctorName.StartsWith("Dr. "))
                {
                    doctorName = doctorName.Substring(4);
                }
                DateTime date = Convert.ToDateTime(appt["AppointmentDate"]);
                TimeSpan time = (TimeSpan)appt["AppointmentTime"];

                string message = "Reminder: your appointment with Dr. " + doctorName
                    + " is on " + date.ToString("dd MMM yyyy")
                    + " at " + time.ToString(@"hh\:mm")
                    + ". — Hospital Management System";

                using (CommunicationForm form = new CommunicationForm())
                {
                    form.Prefill(phone, message);
                    form.ShowDialog(this);
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not read the appointment.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
