// MainForm.cs
// Airport Management System — main window.
// Shows all flights in a grid and lets the user add, update, delete and
// search flights. The four query buttons at the bottom run the practical
// queries from the project (flight status, passengers per flight, flights
// by date, revenue per airline) and show the result in the same grid.
// All database work goes through DatabaseHelper, and every value typed
// by the user is passed as a parameter — never joined into the SQL text.

using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace AirportManagementSystem
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            LoadAirlines();
            LoadFlights();
        }

        // Fill the airline drop-down from the Airlines table.
        private void LoadAirlines()
        {
            DataTable airlines = DatabaseHelper.GetDataTable(
                "SELECT AirlineId, AirlineName FROM Airlines ORDER BY AirlineName;");

            cmbAirline.DataSource = airlines;
            cmbAirline.DisplayMember = "AirlineName";
            cmbAirline.ValueMember = "AirlineId";
        }

        // Show all flights with their airline names in the grid.
        private void LoadFlights()
        {
            try
            {
                DataTable flights = DatabaseHelper.GetDataTable(
                    "SELECT f.FlightId, f.FlightNumber, a.AirlineName, " +
                    "f.SourceAirport, f.DestinationAirport, " +
                    "f.DepartureTime, f.ArrivalTime, f.Status, " +
                    "f.TotalSeats, f.FarePerSeat, f.AirlineId " +
                    "FROM Flights f " +
                    "INNER JOIN Airlines a ON f.AirlineId = a.AirlineId " +
                    "ORDER BY f.FlightId;");
                dgvFlights.DataSource = flights;
                dgvFlights.Columns["AirlineId"].Visible = false;
                lblStatus.Text = flights.Rows.Count + " flights loaded.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not load flights. Check that AirportDB exists " +
                    "and the connection string is correct.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // When a grid row is clicked, copy its values into the fields.
        private void dgvFlights_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
            {
                return;
            }

            DataGridViewRow row = dgvFlights.Rows[e.RowIndex];
            txtFlightId.Text = row.Cells["FlightId"].Value.ToString();
            txtFlightNumber.Text = row.Cells["FlightNumber"].Value.ToString();
            cmbAirline.SelectedValue = row.Cells["AirlineId"].Value;
            txtSource.Text = row.Cells["SourceAirport"].Value.ToString();
            txtDestination.Text = row.Cells["DestinationAirport"].Value.ToString();
            txtDeparture.Text = row.Cells["DepartureTime"].Value.ToString();
            txtArrival.Text = row.Cells["ArrivalTime"].Value.ToString();
            cmbStatus.Text = row.Cells["Status"].Value.ToString();
            txtTotalSeats.Text = row.Cells["TotalSeats"].Value.ToString();
            txtFare.Text = row.Cells["FarePerSeat"].Value.ToString();
        }

        // Read the form fields. Returns false and shows a message if
        // anything is missing or in the wrong format.
        private bool ReadFields(out string number, out int airlineId,
            out string source, out string destination,
            out DateTime departure, out DateTime arrival,
            out string status, out int seats, out decimal fare)
        {
            number = txtFlightNumber.Text.Trim();
            airlineId = 0;
            source = txtSource.Text.Trim();
            destination = txtDestination.Text.Trim();
            departure = DateTime.MinValue;
            arrival = DateTime.MinValue;
            status = cmbStatus.Text.Trim();
            seats = 0;
            fare = 0m;

            if (number == "" || source == "" || destination == "")
            {
                MessageBox.Show("Flight number, source airport and destination airport are required.",
                    "Missing data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (cmbAirline.SelectedValue == null)
            {
                MessageBox.Show("Choose an airline.",
                    "Missing data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            airlineId = (int)cmbAirline.SelectedValue;

            if (!DateTime.TryParse(txtDeparture.Text.Trim(), out departure) ||
                !DateTime.TryParse(txtArrival.Text.Trim(), out arrival))
            {
                MessageBox.Show("Departure and arrival must look like 2026-11-20 09:00.",
                    "Wrong data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (arrival <= departure)
            {
                MessageBox.Show("Arrival time must be after departure time.",
                    "Wrong data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (status != "Scheduled" && status != "Delayed" && status != "Cancelled")
            {
                MessageBox.Show("Status must be Scheduled, Delayed or Cancelled.",
                    "Wrong data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!int.TryParse(txtTotalSeats.Text.Trim(), out seats) || seats <= 0)
            {
                MessageBox.Show("Total seats must be a whole number above zero.",
                    "Wrong data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!decimal.TryParse(txtFare.Text.Trim(), out fare) || fare < 0)
            {
                MessageBox.Show("Fare must be a number, for example 85000.",
                    "Wrong data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!ReadFields(out string number, out int airlineId,
                out string source, out string destination,
                out DateTime departure, out DateTime arrival,
                out string status, out int seats, out decimal fare))
            {
                return;
            }

            try
            {
                string sql = "INSERT INTO Flights (FlightNumber, AirlineId, SourceAirport, " +
                    "DestinationAirport, DepartureTime, ArrivalTime, Status, TotalSeats, FarePerSeat) " +
                    "VALUES (@Number, @Airline, @Source, @Destination, @Departure, @Arrival, @Status, @Seats, @Fare);";
                int rows = DatabaseHelper.ExecuteNonQuery(sql,
                    new SqlParameter("@Number", number),
                    new SqlParameter("@Airline", airlineId),
                    new SqlParameter("@Source", source),
                    new SqlParameter("@Destination", destination),
                    new SqlParameter("@Departure", SqlDbType.DateTime) { Value = departure },
                    new SqlParameter("@Arrival", SqlDbType.DateTime) { Value = arrival },
                    new SqlParameter("@Status", status),
                    new SqlParameter("@Seats", seats),
                    new SqlParameter("@Fare", fare));
                lblStatus.Text = "Flight added. Rows affected: " + rows;
                ClearFields();
                LoadFlights();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not add the flight.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtFlightId.Text.Trim() == "")
            {
                MessageBox.Show("Click a flight in the grid first, then change its details.",
                    "No flight selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!ReadFields(out string number, out int airlineId,
                out string source, out string destination,
                out DateTime departure, out DateTime arrival,
                out string status, out int seats, out decimal fare))
            {
                return;
            }

            try
            {
                string sql = "UPDATE Flights SET FlightNumber = @Number, AirlineId = @Airline, " +
                    "SourceAirport = @Source, DestinationAirport = @Destination, " +
                    "DepartureTime = @Departure, ArrivalTime = @Arrival, " +
                    "Status = @Status, TotalSeats = @Seats, FarePerSeat = @Fare WHERE FlightId = @Id;";
                int rows = DatabaseHelper.ExecuteNonQuery(sql,
                    new SqlParameter("@Number", number),
                    new SqlParameter("@Airline", airlineId),
                    new SqlParameter("@Source", source),
                    new SqlParameter("@Destination", destination),
                    new SqlParameter("@Departure", SqlDbType.DateTime) { Value = departure },
                    new SqlParameter("@Arrival", SqlDbType.DateTime) { Value = arrival },
                    new SqlParameter("@Status", status),
                    new SqlParameter("@Seats", seats),
                    new SqlParameter("@Fare", fare),
                    new SqlParameter("@Id", int.Parse(txtFlightId.Text.Trim())));
                lblStatus.Text = "Flight updated. Rows affected: " + rows;
                ClearFields();
                LoadFlights();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not update the flight.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (txtFlightId.Text.Trim() == "")
            {
                MessageBox.Show("Click a flight in the grid first.",
                    "No flight selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult answer = MessageBox.Show(
                "Delete flight '" + txtFlightNumber.Text.Trim() + "'? " +
                "A flight with bookings cannot be deleted.",
                "Delete flight", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer != DialogResult.Yes)
            {
                return;
            }

            try
            {
                string sql = "DELETE FROM Flights WHERE FlightId = @Id;";
                int rows = DatabaseHelper.ExecuteNonQuery(sql,
                    new SqlParameter("@Id", int.Parse(txtFlightId.Text.Trim())));
                lblStatus.Text = "Flight deleted. Rows affected: " + rows;
                ClearFields();
                LoadFlights();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not delete the flight. A flight with bookings " +
                    "cannot be deleted because the Bookings table refers to it.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearFields();
            LoadFlights();
        }

        private void ClearFields()
        {
            txtFlightId.Text = "";
            txtFlightNumber.Text = "";
            txtSource.Text = "";
            txtDestination.Text = "";
            txtDeparture.Text = "";
            txtArrival.Text = "";
            txtTotalSeats.Text = "";
            txtFare.Text = "";
            if (cmbAirline.Items.Count > 0)
            {
                cmbAirline.SelectedIndex = 0;
            }
            if (cmbStatus.Items.Count > 0)
            {
                cmbStatus.SelectedIndex = 0;
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string keyword = txtSearch.Text.Trim();
            if (keyword == "")
            {
                LoadFlights();
                return;
            }

            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT f.FlightId, f.FlightNumber, a.AirlineName, " +
                    "f.SourceAirport, f.DestinationAirport, " +
                    "f.DepartureTime, f.ArrivalTime, f.Status, " +
                    "f.TotalSeats, f.FarePerSeat, f.AirlineId " +
                    "FROM Flights f " +
                    "INNER JOIN Airlines a ON f.AirlineId = a.AirlineId " +
                    "WHERE f.FlightNumber LIKE @Q OR f.SourceAirport LIKE @Q " +
                    "OR f.DestinationAirport LIKE @Q " +
                    "ORDER BY f.FlightId;",
                    new SqlParameter("@Q", "%" + keyword + "%"));
                dgvFlights.DataSource = result;
                dgvFlights.Columns["AirlineId"].Visible = false;
                lblStatus.Text = result.Rows.Count + " flights found for '" + keyword + "'.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Search failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadFlights();
        }

        // Query 1: flight status by flight number. Type a flight number
        // (for example PK-701) in the Search box first; if the box is
        // empty, PK-701 is used. Expected: PK-701, Scheduled,
        // Lahore to Dubai, departure 2026-11-20 09:00, 180 seats.
        private void btnFlightStatus_Click(object sender, EventArgs e)
        {
            string flightNumber = txtSearch.Text.Trim();
            if (flightNumber == "")
            {
                flightNumber = "PK-701";
            }

            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT f.FlightNumber, a.AirlineName, f.SourceAirport, " +
                    "f.DestinationAirport, f.DepartureTime, f.ArrivalTime, " +
                    "f.Status, f.TotalSeats, f.FarePerSeat " +
                    "FROM Flights f " +
                    "INNER JOIN Airlines a ON f.AirlineId = a.AirlineId " +
                    "WHERE f.FlightNumber = @Number;",
                    new SqlParameter("@Number", flightNumber));
                dgvFlights.DataSource = result;
                lblStatus.Text = "Flight status for '" + flightNumber + "'.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Query 2: passenger list per flight. Click a flight in the grid
        // first. Expected for flight 1 (PK-701): 2 rows, Ahmed Raza
        // (seat 12A) and Ayesha Malik (seat 12B).
        private void btnPassengersPerFlight_Click(object sender, EventArgs e)
        {
            if (txtFlightId.Text.Trim() == "")
            {
                MessageBox.Show("Click a flight in the grid first.",
                    "No flight selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT p.FullName AS Passenger, p.PassportNo, " +
                    "b.SeatNumber, b.TicketClass, b.Fare " +
                    "FROM Bookings b " +
                    "INNER JOIN Passengers p ON b.PassengerId = p.PassengerId " +
                    "INNER JOIN Flights f ON b.FlightId = f.FlightId " +
                    "WHERE f.FlightId = @Id ORDER BY b.SeatNumber;",
                    new SqlParameter("@Id", int.Parse(txtFlightId.Text.Trim())));
                dgvFlights.DataSource = result;
                lblStatus.Text = result.Rows.Count + " passengers on this flight.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Query 3: flights departing on a date. Type a date
        // (for example 2026-11-20) in the Search box first; if the box
        // is empty, 2026-11-20 is used. Expected: 2 flights,
        // PK-701 and EK-612.
        private void btnFlightsByDate_Click(object sender, EventArgs e)
        {
            string dateText = txtSearch.Text.Trim();
            DateTime date;
            if (dateText == "")
            {
                date = new DateTime(2026, 11, 20);
            }
            else if (!DateTime.TryParse(dateText, out date))
            {
                MessageBox.Show("Type a date like 2026-11-20 in the Search box.",
                    "Wrong data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT f.FlightNumber, a.AirlineName, f.SourceAirport, " +
                    "f.DestinationAirport, f.DepartureTime, f.Status " +
                    "FROM Flights f " +
                    "INNER JOIN Airlines a ON f.AirlineId = a.AirlineId " +
                    "WHERE CAST(f.DepartureTime AS DATE) = @Date " +
                    "ORDER BY f.DepartureTime;",
                    new SqlParameter("@Date", SqlDbType.Date) { Value = date.Date });
                dgvFlights.DataSource = result;
                lblStatus.Text = result.Rows.Count + " flights departing on " + date.ToString("yyyy-MM-dd") + ".";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Query 4: total revenue per airline.
        // Expected: PIA 195000, Emirates 45000, Qatar Airways 52000,
        // Turkish Airlines 120000.
        private void btnRevenue_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT a.AirlineName, COUNT(b.BookingId) AS TotalBookings, " +
                    "ISNULL(SUM(b.Fare), 0) AS TotalRevenue " +
                    "FROM Airlines a " +
                    "LEFT JOIN Flights f ON f.AirlineId = a.AirlineId " +
                    "LEFT JOIN Bookings b ON b.FlightId = f.FlightId " +
                    "GROUP BY a.AirlineName ORDER BY TotalRevenue DESC;");
                dgvFlights.DataSource = result;
                lblStatus.Text = "Total revenue per airline.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
