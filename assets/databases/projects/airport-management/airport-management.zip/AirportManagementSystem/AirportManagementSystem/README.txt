Airport Management System — C# Windows Forms + SQL Server (Oracle option included)
==================================================================================

A complete desktop project: manage airlines, flights, passengers and
staff, record bookings, check a flight's status, list the passengers
on a flight, list flights by date, and see the total revenue earned
by each airline — all stored in a SQL Server database.

WHAT IS INSIDE THIS PROJECT
- AirportManagementSystem.sln — double-click this to open the project in Visual Studio.
- AirportManagementSystem/ folder — the C# source code:
    Program.cs            — starts the app and opens the main window.
    MainForm.cs           — all the screen logic (add / update / delete / search flights,
                            and the four practical query buttons).
    MainForm.Designer.cs  — the layout of the main window.
    DatabaseHelper.cs     — the connection string and all database calls.
    DatabaseScripts/      — the two database scripts:
        airport-management-sqlserver.sql — SQL Server version (default).
        airport-management-oracle.sql    — Oracle version.
- SETUP-GUIDE.txt — full step-by-step setup for your own Windows laptop,
  including the connection string and troubleshooting. Read it first.
- The matching tutorial article and complete project report (PDF) are on
  the Database blog: https://database-learning-worldwide-dk.blogspot.com/

QUICK START (details in SETUP-GUIDE.txt)
1. Install Visual Studio 2022 Community (free) and SQL Server Express
   LocalDB (it comes with Visual Studio) or SQL Server 2022 Express.
2. In SQL Server Management Studio (SSMS), open and run
   DatabaseScripts/airport-management-sqlserver.sql.
3. Double-click AirportManagementSystem.sln, press F5, and the program runs.
   The main window shows the 5 sample flights.

DATABASE: AirportDB — tables: Airlines (4 rows), Flights (5 rows),
Passengers (6 rows), Bookings (6 rows), Staff (5 rows).
CONNECTION (default, in DatabaseHelper.cs):
  Server=(localdb)\MSSQLLocalDB;Database=AirportDB;Trusted_Connection=True;
For a full SQL Server Express instance use Server=.\SQLEXPRESS instead.
For Oracle, see the "Oracle option" section of the article and SETUP-GUIDE.txt.

REQUIREMENTS: Windows 10/11, Visual Studio 2022, .NET 8,
SQL Server Express / LocalDB (or Oracle XE for the Oracle version),
internet once for the first NuGet restore (Microsoft.Data.SqlClient).
