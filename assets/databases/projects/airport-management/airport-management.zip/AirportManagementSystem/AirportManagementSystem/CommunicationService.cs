// CommunicationService.cs
// Airport Management System — SMS and WhatsApp sending.
// SMS goes through Twilio (NuGet package Twilio, version 7.14.9).
// WhatsApp goes through Meta's official WhatsApp Business Cloud API
// (Graph API v26.0). The wa.me chat link needs no account at all —
// it simply opens WhatsApp in the browser or on the phone.
//
// All account details come from App.config (appSettings). The values
// shipped in App.config are PLACEHOLDERS ONLY — put your own Twilio
// and WhatsApp Business account details there before sending anything.
// No message is ever sent while the placeholders are still in place:
// SendSms and SendWhatsAppTemplate throw an InvalidOperationException
// telling you to fill in App.config first.
//
// Phone numbers: Twilio and WhatsApp both want the international
// format, for example +923001234567. The sample data in this project
// stores Pakistani numbers in local form (0300-1234567), so
// NormalizePhone converts a leading 0 to +92 and removes spaces and
// dashes before the number is validated and sent. A number that is
// still not in international form after that is rejected with an
// ArgumentException.
//
// Honest limits (see also the article and SETUP-GUIDE.txt):
// (1) WhatsApp groups cannot be created by any software through
// WhatsApp's official API — groups are created in the WhatsApp app
// itself. What this class does is manage contact groups inside the
// software (for example "All Passengers") and send a message to each
// contact in the group, one by one, through the official API.
// (2) The code was checked by reading it carefully, not by compiling
// it (this computer has no .NET SDK) — the first build in Visual
// Studio is the real test.

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

namespace AirportManagementSystem
{
    /// <summary>
    /// One contact group inside the software: a name and the phone
    /// numbers of its members. Groups are NOT WhatsApp groups — they
    /// are lists of contacts held in this program (see the note at the
    /// top of this file).
    /// </summary>
    public class ContactGroup
    {
        public string Name { get; set; }
        public List<string> Phones { get; set; }

        public ContactGroup(string name)
        {
            Name = name;
            Phones = new List<string>();
        }

        public override string ToString()
        {
            return Name + " (" + Phones.Count + " contacts)";
        }
    }

    /// <summary>
    /// Sends SMS through Twilio and WhatsApp messages through the
    /// official WhatsApp Business Cloud API, and builds the contact
    /// groups from the Passengers and Staff tables.
    /// </summary>
    public static class CommunicationService
    {
        // Placeholder values shipped in App.config. A setting is only
        // treated as configured when it is set to something else.
        private const string TwilioSidPlaceholder = "ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
        private const string TwilioTokenPlaceholder = "YOUR_TWILIO_AUTH_TOKEN";
        private const string TwilioFromPlaceholder = "+10000000000";
        private const string WhatsAppIdPlaceholder = "YOUR_WHATSAPP_PHONE_NUMBER_ID";
        private const string WhatsAppTokenPlaceholder = "YOUR_WHATSAPP_ACCESS_TOKEN";

        // Current Meta Graph API version (v26.0, released 29 July 2026).
        // If Meta releases a newer version, change this one line.
        private const string GraphApiVersion = "v26.0";

        private static string Setting(string key)
        {
            string value = ConfigurationManager.AppSettings[key];
            return value == null ? "" : value.Trim();
        }

        public static string TwilioAccountSid
        {
            get { return Setting("TwilioAccountSid"); }
        }

        public static string TwilioAuthToken
        {
            get { return Setting("TwilioAuthToken"); }
        }

        public static string TwilioFromNumber
        {
            get { return Setting("TwilioFromNumber"); }
        }

        public static string WhatsAppPhoneNumberId
        {
            get { return Setting("WhatsAppPhoneNumberId"); }
        }

        public static string WhatsAppAccessToken
        {
            get { return Setting("WhatsAppAccessToken"); }
        }

        public static string WhatsAppTemplateName
        {
            get
            {
                string value = Setting("WhatsAppTemplateName");
                return value == "" ? "hello_world" : value;
            }
        }

        /// <summary>
        /// True only when real Twilio details (not the placeholders)
        /// have been put in App.config.
        /// </summary>
        public static bool IsTwilioConfigured
        {
            get
            {
                return TwilioAccountSid != "" &&
                       TwilioAccountSid != TwilioSidPlaceholder &&
                       TwilioAuthToken != "" &&
                       TwilioAuthToken != TwilioTokenPlaceholder &&
                       TwilioFromNumber != "" &&
                       TwilioFromNumber != TwilioFromPlaceholder;
            }
        }

        /// <summary>
        /// True only when real WhatsApp Business details (not the
        /// placeholders) have been put in App.config.
        /// </summary>
        public static bool IsWhatsAppConfigured
        {
            get
            {
                return WhatsAppPhoneNumberId != "" &&
                       WhatsAppPhoneNumberId != WhatsAppIdPlaceholder &&
                       WhatsAppAccessToken != "" &&
                       WhatsAppAccessToken != WhatsAppTokenPlaceholder;
            }
        }

        /// <summary>
        /// Cleans a phone number and returns it in international form.
        /// Spaces, dashes and brackets are removed; a leading 0 (the
        /// Pakistani local form used in the sample data, 0300-1234567)
        /// becomes +92. The result must start with "+" and contain only
        /// digits after it, otherwise an ArgumentException is thrown.
        /// </summary>
        public static string NormalizePhone(string phone)
        {
            if (phone == null || phone.Trim() == "")
            {
                throw new ArgumentException("Phone number is empty.");
            }

            string cleaned = phone.Trim()
                .Replace(" ", "")
                .Replace("-", "")
                .Replace("(", "")
                .Replace(")", "");

            if (cleaned.StartsWith("0"))
            {
                cleaned = "+92" + cleaned.Substring(1);
            }

            if (!cleaned.StartsWith("+"))
            {
                throw new ArgumentException(
                    "Phone number must be in international format, for example +923001234567.");
            }

            string digits = cleaned.Substring(1);
            if (digits.Length < 8 || digits.Length > 15)
            {
                throw new ArgumentException(
                    "Phone number must have between 8 and 15 digits after the + sign.");
            }

            foreach (char c in digits)
            {
                if (c < '0' || c > '9')
                {
                    throw new ArgumentException(
                        "Phone number must contain only digits after the + sign.");
                }
            }

            return cleaned;
        }

        /// <summary>
        /// Sends one SMS through Twilio. Returns the Twilio message SID.
        /// Throws InvalidOperationException if Twilio is not configured
        /// in App.config, and ArgumentException for a bad phone number.
        /// </summary>
        public static string SendSms(string to, string message)
        {
            if (!IsTwilioConfigured)
            {
                throw new InvalidOperationException(
                    "Twilio is not configured. Open App.config and put your own " +
                    "Twilio Account SID, Auth Token and Twilio phone number in " +
                    "TwilioAccountSid, TwilioAuthToken and TwilioFromNumber. " +
                    "See SETUP-GUIDE.txt, section \"SMS AND WHATSAPP SETUP\".");
            }

            if (message == null || message.Trim() == "")
            {
                throw new ArgumentException("Message text is empty.");
            }

            string toNumber = NormalizePhone(to);

            TwilioClient.Init(TwilioAccountSid, TwilioAuthToken);
            MessageResource result = MessageResource.Create(
                to: new PhoneNumber(toNumber),
                from: new PhoneNumber(TwilioFromNumber),
                body: message);
            return result.Sid;
        }

        /// <summary>
        /// Sends one WhatsApp template message through the official
        /// WhatsApp Business Cloud API (Graph API v26.0). Outside the
        /// 24-hour customer-service window, WhatsApp only allows
        /// approved template messages, so this method sends a template,
        /// not free text. Returns the WhatsApp message ID.
        /// Throws InvalidOperationException if WhatsApp is not
        /// configured in App.config.
        /// </summary>
        public static string SendWhatsAppTemplate(string to, string templateName)
        {
            if (!IsWhatsAppConfigured)
            {
                throw new InvalidOperationException(
                    "WhatsApp is not configured. Open App.config and put your own " +
                    "WhatsApp Business phone number ID and access token in " +
                    "WhatsAppPhoneNumberId and WhatsAppAccessToken. " +
                    "See SETUP-GUIDE.txt, section \"SMS AND WHATSAPP SETUP\".");
            }

            if (templateName == null || templateName.Trim() == "")
            {
                templateName = WhatsAppTemplateName;
            }

            // WhatsApp wants the number as digits only, without the +.
            string toNumber = NormalizePhone(to).Substring(1);

            string url = "https://graph.facebook.com/" + GraphApiVersion +
                "/" + WhatsAppPhoneNumberId + "/messages";

            string json = "{\"messaging_product\":\"whatsapp\"," +
                "\"to\":\"" + toNumber + "\"," +
                "\"type\":\"template\"," +
                "\"template\":{\"name\":\"" + templateName.Trim() + "\"," +
                "\"language\":{\"code\":\"en_US\"}}}";

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization",
                    "Bearer " + WhatsAppAccessToken);
                using (StringContent content = new StringContent(
                    json, Encoding.UTF8, "application/json"))
                {
                    HttpResponseMessage response = client.PostAsync(url, content).Result;
                    string body = response.Content.ReadAsStringAsync().Result;

                    if (!response.IsSuccessStatusCode)
                    {
                        throw new InvalidOperationException(
                            "WhatsApp send failed (" + (int)response.StatusCode +
                            " " + response.ReasonPhrase + "). " + body +
                            " A 401 usually means a wrong or expired access token; " +
                            "a 400 about the template means the template is not " +
                            "approved yet. See SETUP-GUIDE.txt troubleshooting.");
                    }

                    using (JsonDocument doc = JsonDocument.Parse(body))
                    {
                        JsonElement root = doc.RootElement;
                        JsonElement messages = root.GetProperty("messages");
                        return messages[0].GetProperty("id").GetString();
                    }
                }
            }
        }

        /// <summary>
        /// Opens a WhatsApp chat with the given number in the browser
        /// (wa.me click-to-chat link) with the message already typed.
        /// Needs no Twilio account and no WhatsApp Business account —
        /// the user presses Send in WhatsApp itself.
        /// </summary>
        public static void OpenWhatsAppChat(string to, string message)
        {
            string toNumber = NormalizePhone(to).Substring(1);
            string url = "https://wa.me/" + toNumber +
                "?text=" + Uri.EscapeDataString(message == null ? "" : message);
            Process.Start(new ProcessStartInfo
            {
                FileName = url,
                UseShellExecute = true
            });
        }

        /// <summary>
        /// Builds the contact groups from the database: every passenger
        /// with a phone number, and every staff member with a phone
        /// number. These are groups inside this software, not WhatsApp
        /// groups — each member is messaged one by one.
        /// </summary>
        public static List<ContactGroup> GetContactGroups()
        {
            List<ContactGroup> groups = new List<ContactGroup>();

            ContactGroup passengers = new ContactGroup("All Passengers");
            DataTable passengerPhones = DatabaseHelper.GetDataTable(
                "SELECT Phone FROM Passengers " +
                "WHERE Phone IS NOT NULL AND Phone <> '';");
            foreach (DataRow row in passengerPhones.Rows)
            {
                passengers.Phones.Add(row["Phone"].ToString());
            }
            groups.Add(passengers);

            ContactGroup staff = new ContactGroup("All Staff");
            DataTable staffPhones = DatabaseHelper.GetDataTable(
                "SELECT Phone FROM Staff " +
                "WHERE Phone IS NOT NULL AND Phone <> '';");
            foreach (DataRow row in staffPhones.Rows)
            {
                staff.Phones.Add(row["Phone"].ToString());
            }
            groups.Add(staff);

            return groups;
        }

        /// <summary>
        /// Sends the same SMS to every member of a contact group.
        /// Returns a short result, for example
        /// "SMS sent to 5 of 6 contacts. Failed: 0300-9999999 (bad number)."
        /// No error is swallowed silently — failures are listed in the
        /// returned text and also shown by the calling form.
        /// </summary>
        public static string SendSmsToGroup(ContactGroup group, string message)
        {
            if (group == null || group.Phones.Count == 0)
            {
                return "Group '" + (group == null ? "" : group.Name) +
                    "' has no phone numbers.";
            }

            int sent = 0;
            List<string> failures = new List<string>();
            foreach (string phone in group.Phones)
            {
                try
                {
                    SendSms(phone, message);
                    sent++;
                }
                catch (Exception ex)
                {
                    failures.Add(phone + " (" + ex.Message + ")");
                }
            }

            string result = "SMS sent to " + sent + " of " +
                group.Phones.Count + " contacts in '" + group.Name + "'.";
            if (failures.Count > 0)
            {
                result += " Failed: " + string.Join("; ", failures) + ".";
            }
            return result;
        }

        /// <summary>
        /// Sends the same WhatsApp template message to every member of
        /// a contact group. Returns a short result with the sent count
        /// and any failures (same shape as SendSmsToGroup).
        /// </summary>
        public static string SendWhatsAppToGroup(ContactGroup group, string templateName)
        {
            if (group == null || group.Phones.Count == 0)
            {
                return "Group '" + (group == null ? "" : group.Name) +
                    "' has no phone numbers.";
            }

            int sent = 0;
            List<string> failures = new List<string>();
            foreach (string phone in group.Phones)
            {
                try
                {
                    SendWhatsAppTemplate(phone, templateName);
                    sent++;
                }
                catch (Exception ex)
                {
                    failures.Add(phone + " (" + ex.Message + ")");
                }
            }

            string result = "WhatsApp sent to " + sent + " of " +
                group.Phones.Count + " contacts in '" + group.Name + "'.";
            if (failures.Count > 0)
            {
                result += " Failed: " + string.Join("; ", failures) + ".";
            }
            return result;
        }
    }
}
