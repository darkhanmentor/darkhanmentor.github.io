// CommunicationForm.cs
// Airport Management System — the SMS / WhatsApp window.
// The user picks a contact group (or types one phone number), picks
// SMS or WhatsApp, types a message and clicks Send. Groups come from
// the database through CommunicationService.GetContactGroups():
// "All Passengers" and "All Staff". Sending a message to a group
// sends it to each member one by one — these are contact groups
// inside this software, NOT WhatsApp groups (WhatsApp groups cannot
// be created by any software through the official API).
//
// The "Open WhatsApp Chat" button needs no account at all: it opens
// a wa.me chat link with the message already typed, and the user
// presses Send in WhatsApp itself.

using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace AirportManagementSystem
{
    public partial class CommunicationForm : Form
    {
        // The groups loaded from the database, in the same order as
        // they appear in cmbGroup after the "Single number" entry.
        private List<ContactGroup> _groups = new List<ContactGroup>();

        public CommunicationForm()
        {
            InitializeComponent();
        }

        private void CommunicationForm_Load(object sender, EventArgs e)
        {
            rdoSms.Checked = true;
            cmbGroup.Items.Add("Single number");
            try
            {
                _groups = CommunicationService.GetContactGroups();
                foreach (ContactGroup group in _groups)
                {
                    cmbGroup.Items.Add(group.ToString());
                }
                lblStatus.Text = "Ready. " + _groups.Count +
                    " contact groups loaded from the database.";
            }
            catch (Exception ex)
            {
                // The database is not reachable: the form still works
                // for a single typed number. The error is shown, never
                // swallowed silently.
                lblStatus.Text = "Groups could not be loaded: " + ex.Message;
            }
            cmbGroup.SelectedIndex = 0;
        }

        /// <summary>
        /// Fills the form from another screen — for example MainForm's
        /// "Send flight update" button, which passes the passenger's
        /// phone number and the flight-update message.
        /// </summary>
        public void Prefill(string toPhone, string message)
        {
            if (cmbGroup.Items.Count > 0)
            {
                cmbGroup.SelectedIndex = 0;
            }
            txtTo.Text = toPhone == null ? "" : toPhone;
            txtMessage.Text = message == null ? "" : message;
        }

        private void cmbGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbGroup.SelectedIndex <= 0)
            {
                // "Single number": the user types the phone number.
                txtTo.Enabled = true;
                txtTo.Text = "";
            }
            else
            {
                // A group: the number box is not used, it shows how
                // many contacts the message will go to.
                ContactGroup group = _groups[cmbGroup.SelectedIndex - 1];
                txtTo.Enabled = false;
                txtTo.Text = group.Phones.Count + " numbers in " + group.Name;
            }
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            string message = txtMessage.Text.Trim();

            try
            {
                string result;

                if (cmbGroup.SelectedIndex > 0)
                {
                    // Send to a whole contact group, one member at a time.
                    ContactGroup group = _groups[cmbGroup.SelectedIndex - 1];
                    if (rdoSms.Checked)
                    {
                        if (message == "")
                        {
                            MessageBox.Show("Type a message first.",
                                "Missing data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                        result = CommunicationService.SendSmsToGroup(group, message);
                    }
                    else
                    {
                        result = CommunicationService.SendWhatsAppToGroup(
                            group, CommunicationService.WhatsAppTemplateName);
                    }
                }
                else
                {
                    // Send to the single number typed in txtTo.
                    string to = txtTo.Text.Trim();
                    if (to == "")
                    {
                        MessageBox.Show("Type a phone number first, or pick a contact group.",
                            "Missing data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    if (rdoSms.Checked)
                    {
                        if (message == "")
                        {
                            MessageBox.Show("Type a message first.",
                                "Missing data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                        string sid = CommunicationService.SendSms(to, message);
                        result = "SMS sent to " + to + ". Twilio message SID: " + sid;
                    }
                    else
                    {
                        string id = CommunicationService.SendWhatsAppTemplate(
                            to, CommunicationService.WhatsAppTemplateName);
                        result = "WhatsApp template sent to " + to +
                            ". WhatsApp message ID: " + id;
                    }
                }

                lblStatus.Text = result;
                MessageBox.Show(result, "Sent",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                // Errors are shown to the user, never swallowed: a
                // missing Twilio/WhatsApp setup, a bad phone number,
                // no internet, or a rejected template all land here.
                lblStatus.Text = "Send failed: " + ex.Message;
                MessageBox.Show("Send failed.\n\n" + ex.Message,
                    "Send failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnWhatsAppChat_Click(object sender, EventArgs e)
        {
            if (cmbGroup.SelectedIndex > 0)
            {
                MessageBox.Show("A chat link is for one person. Pick 'Single number' " +
                    "and type a phone number first.",
                    "Chat link", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string to = txtTo.Text.Trim();
            if (to == "")
            {
                MessageBox.Show("Type a phone number first.",
                    "Missing data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                CommunicationService.OpenWhatsAppChat(to, txtMessage.Text);
                lblStatus.Text = "WhatsApp chat opened for " + to + ".";
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Could not open WhatsApp: " + ex.Message;
                MessageBox.Show("Could not open WhatsApp.\n\n" + ex.Message,
                    "WhatsApp chat", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
