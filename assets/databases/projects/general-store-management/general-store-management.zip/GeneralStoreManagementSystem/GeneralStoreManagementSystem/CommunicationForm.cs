// CommunicationForm.cs
// General Store Management System — the SMS / WhatsApp form.
// Lets the shopkeeper send a message to one phone number or to a
// whole contact group ("All Customers" or "All Suppliers", read from
// the database by CommunicationService.GetContactGroups()).
// SMS goes through Twilio, WhatsApp through the official WhatsApp
// Business Cloud API. The "Open WhatsApp Chat" button needs no
// account — it opens a wa.me link in the browser / WhatsApp.
// Errors are shown in lblStatus and in a MessageBox — never swallowed.

using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace GeneralStoreManagementSystem
{
    public partial class CommunicationForm : Form
    {
        private const string SingleNumberEntry = "Single number";
        private List<ContactGroup> groups = new List<ContactGroup>();

        public CommunicationForm()
        {
            InitializeComponent();
        }

        private void CommunicationForm_Load(object sender, EventArgs e)
        {
            rdoSms.Checked = true;
            LoadGroups();
        }

        // Fill cmbGroup from the database groups, plus one extra entry
        // for sending to a single number typed in txtTo.
        private void LoadGroups()
        {
            cmbGroup.Items.Clear();
            try
            {
                groups = CommunicationService.GetContactGroups();
                foreach (ContactGroup group in groups)
                {
                    cmbGroup.Items.Add(group.ToString());
                }
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Could not load contact groups: " + ex.Message;
                groups = new List<ContactGroup>();
            }

            cmbGroup.Items.Add(SingleNumberEntry);
            if (cmbGroup.Items.Count > 0)
            {
                cmbGroup.SelectedIndex = 0;
            }
        }

        // Pre-fill the form from the main window. If toPhone is the
        // name of a contact group (for example "All Customers"), that
        // group is selected; otherwise toPhone is treated as a single
        // phone number and put in txtTo.
        public void Prefill(string toPhone, string message)
        {
            txtMessage.Text = message == null ? "" : message;

            if (!string.IsNullOrWhiteSpace(toPhone))
            {
                int groupIndex = -1;
                for (int i = 0; i < groups.Count; i++)
                {
                    if (groups[i].Name == toPhone.Trim())
                    {
                        groupIndex = i;
                        break;
                    }
                }

                if (groupIndex >= 0)
                {
                    cmbGroup.SelectedIndex = groupIndex;
                    txtTo.Text = "";
                }
                else
                {
                    cmbGroup.SelectedItem = SingleNumberEntry;
                    txtTo.Text = toPhone.Trim();
                }
            }
        }

        private void cmbGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            // When a group is selected, the number comes from the
            // group, so txtTo is disabled. "Single number" enables it.
            bool single = cmbGroup.SelectedItem != null &&
                cmbGroup.SelectedItem.ToString() == SingleNumberEntry;
            txtTo.Enabled = single;
            if (!single)
            {
                txtTo.Text = "";
            }
        }

        private ContactGroup SelectedGroup()
        {
            if (cmbGroup.SelectedItem == null)
            {
                return null;
            }
            if (cmbGroup.SelectedItem.ToString() == SingleNumberEntry)
            {
                return null;
            }
            foreach (ContactGroup group in groups)
            {
                if (group.ToString() == cmbGroup.SelectedItem.ToString())
                {
                    return group;
                }
            }
            return null;
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            string message = txtMessage.Text.Trim();
            if (message == "")
            {
                MessageBox.Show("Type a message first.",
                    "Missing message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string result;
                ContactGroup group = SelectedGroup();
                if (group != null)
                {
                    if (rdoSms.Checked)
                    {
                        result = CommunicationService.SendSmsToGroup(group, message);
                    }
                    else
                    {
                        result = CommunicationService.SendWhatsAppToGroup(group, CommunicationService.WhatsAppTemplateName);
                    }
                }
                else
                {
                    string to = txtTo.Text.Trim();
                    if (rdoSms.Checked)
                    {
                        CommunicationService.SendSms(to, message);
                        result = "SMS sent to " + to + ".";
                    }
                    else
                    {
                        CommunicationService.SendWhatsAppTemplate(to, CommunicationService.WhatsAppTemplateName);
                        result = "WhatsApp message sent to " + to + ".";
                    }
                }

                lblStatus.Text = result;
                MessageBox.Show(result, "Sent", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Send failed: " + ex.Message;
                MessageBox.Show("Could not send the message.\n\n" + ex.Message,
                    "Send failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnWhatsAppChat_Click(object sender, EventArgs e)
        {
            string to = txtTo.Text.Trim();
            if (to == "")
            {
                MessageBox.Show("Type a phone number first (international format, for example +923001234567).",
                    "Missing number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                CommunicationService.OpenWhatsAppChat(to, txtMessage.Text.Trim());
                lblStatus.Text = "WhatsApp chat opened for " + to + ".";
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Could not open WhatsApp chat: " + ex.Message;
                MessageBox.Show("Could not open the WhatsApp chat.\n\n" + ex.Message,
                    "WhatsApp chat failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
