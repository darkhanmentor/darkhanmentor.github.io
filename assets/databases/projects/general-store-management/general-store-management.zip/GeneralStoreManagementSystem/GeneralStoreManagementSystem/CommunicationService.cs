// CommunicationService.cs
// General Store Management System — SMS and WhatsApp messaging.
//
// Two channels, both through OFFICIAL services:
//   * SMS — Twilio (NuGet package Twilio, version 7.14.9).
//     TwilioClient.Init(sid, token), then MessageResource.Create.
//   * WhatsApp — the OFFICIAL WhatsApp Business Cloud API, which is a
//     set of endpoints on Meta's Graph API (current version v26.0,
//     released 29 July 2026). A plain HttpClient POST to
//     https://graph.facebook.com/v26.0/<phoneNumberId>/messages
//     with a Bearer access token.
//   * wa.me links — click-to-chat links that open WhatsApp in the
//     browser or app. They need NO account at all.
//
// All secrets come from App.config (appSettings). The values shipped
// with this project are PLACEHOLDERS ONLY — replace them with your own
// Twilio and WhatsApp Business account details before sending anything.
// No real credential and no real phone number is stored in this project.
//
// Honest limits — please read:
//   (1) WhatsApp groups cannot be created by any software through
//       WhatsApp's official API — groups are created in the WhatsApp
//       app itself. What this class does is manage contact groups
//       INSIDE the software (for example "All Customers") and send
//       messages to those contacts, one by one, through the official
//       WhatsApp Business API.
//   (2) No SMS or WhatsApp message is actually sent until you add
//       your own accounts: a Twilio account for SMS (the free trial
//       gives a small credit; real bulk SMS needs a paid gateway
//       account) and a WhatsApp Business account for the WhatsApp API.
//       The wa.me chat links work without any account — they simply
//       open WhatsApp.

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

namespace GeneralStoreManagementSystem
{
    // One contact group inside the software: a name and the phone
    // numbers of its members. Groups are NOT WhatsApp groups — they
    // are lists kept by this program, filled from the database.
    public class ContactGroup
    {
        public string Name { get; set; }
        public List<string> Phones { get; set; }

        public ContactGroup(string name)
        {
            Name = name;
            Phones = new List<string>();
        }

        public override string ToString()
        {
            return Name + " (" + Phones.Count + " contacts)";
        }
    }

    public static class CommunicationService
    {
        // Placeholder values — the shipped App.config contains these.
        // A value is "configured" only when it is not the placeholder.
        public const string TwilioSidPlaceholder = "ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
        public const string TwilioTokenPlaceholder = "YOUR_TWILIO_AUTH_TOKEN";
        public const string TwilioFromPlaceholder = "+10000000000";
        public const string WhatsAppPhoneIdPlaceholder = "YOUR_WHATSAPP_PHONE_NUMBER_ID";
        public const string WhatsAppTokenPlaceholder = "YOUR_WHATSAPP_ACCESS_TOKEN";

        // Meta Graph API version used for the WhatsApp Business Cloud
        // API. Current version at the time of writing: v26.0
        // (released 29 July 2026). If Meta releases a newer version,
        // change this one value.
        public const string GraphApiVersion = "v26.0";

        public const string DefaultTemplateName = "hello_world";

        private static string Setting(string key)
        {
            string value = ConfigurationManager.AppSettings[key];
            return value == null ? "" : value.Trim();
        }

        public static string TwilioAccountSid
        {
            get { return Setting("TwilioAccountSid"); }
        }

        public static string TwilioAuthToken
        {
            get { return Setting("TwilioAuthToken"); }
        }

        public static string TwilioFromNumber
        {
            get { return Setting("TwilioFromNumber"); }
        }

        public static string WhatsAppPhoneNumberId
        {
            get { return Setting("WhatsAppPhoneNumberId"); }
        }

        public static string WhatsAppAccessToken
        {
            get { return Setting("WhatsAppAccessToken"); }
        }

        public static string WhatsAppTemplateName
        {
            get
            {
                string name = Setting("WhatsAppTemplateName");
                return name == "" ? DefaultTemplateName : name;
            }
        }

        // True only when real Twilio details (not the placeholders)
        // have been put into App.config.
        public static bool IsTwilioConfigured
        {
            get
            {
                return TwilioAccountSid != "" &&
                    TwilioAccountSid != TwilioSidPlaceholder &&
                    TwilioAuthToken != "" &&
                    TwilioAuthToken != TwilioTokenPlaceholder &&
                    TwilioFromNumber != "" &&
                    TwilioFromNumber != TwilioFromPlaceholder;
            }
        }

        // True only when real WhatsApp Business details (not the
        // placeholders) have been put into App.config.
        public static bool IsWhatsAppConfigured
        {
            get
            {
                return WhatsAppPhoneNumberId != "" &&
                    WhatsAppPhoneNumberId != WhatsAppPhoneIdPlaceholder &&
                    WhatsAppAccessToken != "" &&
                    WhatsAppAccessToken != WhatsAppTokenPlaceholder;
            }
        }

        // A phone number must be in international format: it starts
        // with "+" and the rest is digits, for example +923001234567.
        // Numbers stored in the sample data (0300-1234567) are local
        // format and must be converted before sending.
        public static void ValidatePhone(string to)
        {
            if (string.IsNullOrWhiteSpace(to))
            {
                throw new ArgumentException("Phone number is empty. Type a phone number in international format, for example +923001234567.");
            }

            string number = to.Trim();
            if (!number.StartsWith("+"))
            {
                throw new ArgumentException("Phone number '" + number + "' must start with '+' (international format, for example +923001234567).");
            }

            for (int i = 1; i < number.Length; i++)
            {
                if (!char.IsDigit(number[i]))
                {
                    throw new ArgumentException("Phone number '" + number + "' must contain only digits after the '+'. Remove spaces and dashes.");
                }
            }

            if (number.Length < 8)
            {
                throw new ArgumentException("Phone number '" + number + "' is too short to be a real phone number.");
            }
        }

        // Send one SMS through Twilio.
        public static void SendSms(string to, string message)
        {
            ValidatePhone(to);
            if (string.IsNullOrWhiteSpace(message))
            {
                throw new ArgumentException("Message is empty. Type a message before sending.");
            }

            if (!IsTwilioConfigured)
            {
                throw new InvalidOperationException("Twilio is not configured. Put your own Twilio account details (Account SID, Auth Token and Twilio phone number) in App.config first — see SETUP-GUIDE.txt, 'SMS AND WHATSAPP SETUP'.");
            }

            TwilioClient.Init(TwilioAccountSid, TwilioAuthToken);
            MessageResource.Create(
                to: new PhoneNumber(to.Trim()),
                from: new PhoneNumber(TwilioFromNumber),
                body: message);
        }

        // Send one WhatsApp template message through the OFFICIAL
        // WhatsApp Business Cloud API (Meta Graph API, version v26.0).
        // Template messages are required for messages a business
        // starts outside the 24-hour customer-service window; the
        // template must be approved by Meta first.
        public static void SendWhatsAppTemplate(string to, string templateName)
        {
            ValidatePhone(to);

            if (!IsWhatsAppConfigured)
            {
                throw new InvalidOperationException("WhatsApp is not configured. Put your own WhatsApp Business details (Phone Number ID and Access Token) in App.config first — see SETUP-GUIDE.txt, 'SMS AND WHATSAPP SETUP'.");
            }

            string template = string.IsNullOrWhiteSpace(templateName)
                ? WhatsAppTemplateName
                : templateName.Trim();

            // The Cloud API expects the number as digits only, without
            // the leading "+".
            string digits = to.Trim().Substring(1);

            string url = "https://graph.facebook.com/" + GraphApiVersion + "/" +
                WhatsAppPhoneNumberId + "/messages";

            var payload = new
            {
                messaging_product = "whatsapp",
                to = digits,
                type = "template",
                template = new
                {
                    name = template,
                    language = new { code = "en_US" }
                }
            };
            string json = JsonSerializer.Serialize(payload);

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", WhatsAppAccessToken);
                using (StringContent content = new StringContent(json, Encoding.UTF8, "application/json"))
                {
                    Task<HttpResponseMessage> task = client.PostAsync(url, content);
                    HttpResponseMessage response = task.GetAwaiter().GetResult();
                    if (!response.IsSuccessStatusCode)
                    {
                        string body = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                        throw new InvalidOperationException("WhatsApp API returned " +
                            (int)response.StatusCode + " (" + response.ReasonPhrase + "). " + body +
                            " A 401 means a wrong or expired access token; a 400 about the template means the template is not approved yet.");
                    }
                }
            }
        }

        // Open a wa.me click-to-chat link in the browser / WhatsApp.
        // Needs NO account at all — it simply opens WhatsApp with the
        // message already typed, and the user presses Send there.
        public static void OpenWhatsAppChat(string to, string message)
        {
            ValidatePhone(to);
            string digits = to.Trim().Substring(1);
            string url = "https://wa.me/" + digits;
            if (!string.IsNullOrWhiteSpace(message))
            {
                url += "?text=" + Uri.EscapeDataString(message);
            }

            ProcessStartInfo start = new ProcessStartInfo(url);
            start.UseShellExecute = true;
            Process.Start(start);
        }

        // Contact groups inside the software, filled from the database.
        // "All Customers" reads the Phone column of the Customers table;
        // "All Suppliers" reads the Phone column of the Suppliers table.
        // Empty phone numbers are skipped. These are NOT WhatsApp
        // groups — WhatsApp groups can only be created in the
        // WhatsApp app itself.
        public static List<ContactGroup> GetContactGroups()
        {
            List<ContactGroup> groups = new List<ContactGroup>();

            ContactGroup customers = new ContactGroup("All Customers");
            DataTable customerPhones = DatabaseHelper.GetDataTable(
                "SELECT Phone FROM Customers WHERE Phone IS NOT NULL AND Phone <> '' ORDER BY FullName;");
            foreach (DataRow row in customerPhones.Rows)
            {
                customers.Phones.Add(row["Phone"].ToString().Trim());
            }
            groups.Add(customers);

            ContactGroup suppliers = new ContactGroup("All Suppliers");
            DataTable supplierPhones = DatabaseHelper.GetDataTable(
                "SELECT Phone FROM Suppliers WHERE Phone IS NOT NULL AND Phone <> '' ORDER BY SupplierName;");
            foreach (DataRow row in supplierPhones.Rows)
            {
                suppliers.Phones.Add(row["Phone"].ToString().Trim());
            }
            groups.Add(suppliers);

            return groups;
        }

        // Send an SMS to every member of a group, one by one.
        // A member whose number is invalid is counted as a failure,
        // not as a reason to stop the whole send. Returns a short
        // result string with the sent count and any failures.
        public static string SendSmsToGroup(ContactGroup group, string message)
        {
            if (group == null)
            {
                throw new ArgumentException("No contact group was selected.");
            }

            int sent = 0;
            List<string> failures = new List<string>();
            foreach (string phone in group.Phones)
            {
                try
                {
                    SendSms(phone, message);
                    sent++;
                }
                catch (Exception ex)
                {
                    failures.Add(phone + ": " + ex.Message);
                }
            }

            string result = "SMS sent to " + sent + " of " + group.Phones.Count +
                " contacts in '" + group.Name + "'.";
            if (failures.Count > 0)
            {
                result += " Failures (" + failures.Count + "): " + string.Join("; ", failures);
            }
            return result;
        }

        // Send a WhatsApp template message to every member of a group,
        // one by one. Returns a short result string with the sent
        // count and any failures.
        public static string SendWhatsAppToGroup(ContactGroup group, string templateName)
        {
            if (group == null)
            {
                throw new ArgumentException("No contact group was selected.");
            }

            int sent = 0;
            List<string> failures = new List<string>();
            foreach (string phone in group.Phones)
            {
                try
                {
                    SendWhatsAppTemplate(phone, templateName);
                    sent++;
                }
                catch (Exception ex)
                {
                    failures.Add(phone + ": " + ex.Message);
                }
            }

            string result = "WhatsApp sent to " + sent + " of " + group.Phones.Count +
                " contacts in '" + group.Name + "'.";
            if (failures.Count > 0)
            {
                result += " Failures (" + failures.Count + "): " + string.Join("; ", failures);
            }
            return result;
        }
    }
}
