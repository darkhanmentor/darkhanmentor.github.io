General Store Management System — C# Windows Forms + SQL Server (Oracle option included)
==================================================================================

A complete desktop project: manage the products of a general (grocery)
store, record purchases from suppliers and sales to customers, and see
low stock products, daily sales, monthly sales and profit per product —
all stored in a SQL Server database.

WHAT IS INSIDE THIS PROJECT
- GeneralStoreManagementSystem.sln — double-click this to open the project in Visual Studio.
- GeneralStoreManagementSystem/ folder — the C# source code:
    Program.cs            — starts the app and opens the main window.
    MainForm.cs           — all the screen logic (add / update / delete / search products,
                            and the four practical query buttons).
    MainForm.Designer.cs  — the layout of the main window.
    CommunicationService.cs — SMS (Twilio) and WhatsApp (official Business API) sending,
                            contact groups ("All Customers", "All Suppliers") and wa.me links.
    CommunicationForm.cs  — the SMS / WhatsApp form logic.
    CommunicationForm.Designer.cs — the layout of the SMS / WhatsApp form.
    App.config            — Twilio and WhatsApp account settings (PLACEHOLDERS ONLY —
                            put your own details in before sending anything).
    DatabaseHelper.cs     — the connection string and all database calls.
- Screenshots/ (next to the .sln, at solution level) — form previews
  rendered from the Designer.cs files (mainform-preview.png,
  commform-preview.png and control crops).
    DatabaseScripts/      — the two database scripts:
        general-store-management-sqlserver.sql — SQL Server version (default).
        general-store-management-oracle.sql    — Oracle version.
- SETUP-GUIDE.txt — full step-by-step setup for your own Windows laptop,
  including the connection string and troubleshooting. Read it first.
- The matching tutorial article and complete project report (PDF) are on
  the Database blog: https://database-learning-worldwide-dk.blogspot.com/

QUICK START (details in SETUP-GUIDE.txt)
1. Install Visual Studio 2022 Community (free) and SQL Server Express
   LocalDB (it comes with Visual Studio) or SQL Server 2022 Express.
2. In SQL Server Management Studio (SSMS), open and run
   DatabaseScripts/general-store-management-sqlserver.sql.
3. Double-click GeneralStoreManagementSystem.sln, press F5, and the program runs.
   The main window shows the 6 sample products.

DATABASE: GeneralStoreDB — tables: Categories (4 rows), Products (6 rows),
Suppliers (3 rows), Customers (4 rows), Purchases (4 rows), Sales (6 rows).
CONNECTION (default, in DatabaseHelper.cs):
  Server=(localdb)\MSSQLLocalDB;Database=GeneralStoreDB;Trusted_Connection=True;
For a full SQL Server Express instance use Server=.\SQLEXPRESS instead.
For Oracle, see the "Oracle option" section of the article and SETUP-GUIDE.txt.

REQUIREMENTS: Windows 10/11, Visual Studio 2022, .NET 8,
SQL Server Express / LocalDB (or Oracle XE for the Oracle version),
internet once for the first NuGet restore (Microsoft.Data.SqlClient).
