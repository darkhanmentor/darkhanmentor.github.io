// MainForm.cs
// General Store Management System — main window.
// Shows all products in a grid and lets the user add, update, delete and
// search products. The four query buttons at the bottom run the practical
// queries from the project (low stock, daily sales, monthly sales, profit
// per product) and show the result in the same grid.
// All database work goes through DatabaseHelper, and every value typed
// by the user is passed as a parameter — never joined into the SQL text.

using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace GeneralStoreManagementSystem
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            LoadCategories();
            LoadProducts();
        }

        // Fill the category drop-down from the Categories table.
        private void LoadCategories()
        {
            DataTable categories = DatabaseHelper.GetDataTable(
                "SELECT CategoryId, CategoryName FROM Categories ORDER BY CategoryName;");

            cmbCategory.DataSource = categories;
            cmbCategory.DisplayMember = "CategoryName";
            cmbCategory.ValueMember = "CategoryId";
        }

        // Show all products with their category names in the grid.
        private void LoadProducts()
        {
            try
            {
                DataTable products = DatabaseHelper.GetDataTable(
                    "SELECT p.ProductId, p.ProductName, c.CategoryName, " +
                    "p.UnitPrice, p.StockQuantity, p.ReorderLevel, p.CategoryId " +
                    "FROM Products p " +
                    "INNER JOIN Categories c ON p.CategoryId = c.CategoryId " +
                    "ORDER BY p.ProductId;");
                dgvProducts.DataSource = products;
                dgvProducts.Columns["CategoryId"].Visible = false;
                lblStatus.Text = products.Rows.Count + " products loaded.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not load products. Check that GeneralStoreDB exists " +
                    "and the connection string is correct.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // When a grid row is clicked, copy its values into the fields.
        private void dgvProducts_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
            {
                return;
            }

            DataGridViewRow row = dgvProducts.Rows[e.RowIndex];
            txtProductId.Text = row.Cells["ProductId"].Value.ToString();
            txtProductName.Text = row.Cells["ProductName"].Value.ToString();
            cmbCategory.SelectedValue = row.Cells["CategoryId"].Value;
            txtUnitPrice.Text = row.Cells["UnitPrice"].Value.ToString();
            txtStockQuantity.Text = row.Cells["StockQuantity"].Value.ToString();
            txtReorderLevel.Text = row.Cells["ReorderLevel"].Value.ToString();
        }

        // Read the form fields. Returns false and shows a message if
        // anything is missing or in the wrong format.
        private bool ReadFields(out string name, out int categoryId,
            out decimal unitPrice, out int stockQuantity, out int reorderLevel)
        {
            name = txtProductName.Text.Trim();
            categoryId = 0;
            unitPrice = 0m;
            stockQuantity = 0;
            reorderLevel = 0;

            if (name == "")
            {
                MessageBox.Show("Product name is required.",
                    "Missing data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (cmbCategory.SelectedValue == null)
            {
                MessageBox.Show("Choose a category for the product.",
                    "Missing data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            categoryId = (int)cmbCategory.SelectedValue;

            if (!decimal.TryParse(txtUnitPrice.Text.Trim(), out unitPrice) || unitPrice < 0)
            {
                MessageBox.Show("Unit price must be a number, for example 320.",
                    "Wrong data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!int.TryParse(txtStockQuantity.Text.Trim(), out stockQuantity) || stockQuantity < 0)
            {
                MessageBox.Show("Stock quantity must be a whole number, zero or more.",
                    "Wrong data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!int.TryParse(txtReorderLevel.Text.Trim(), out reorderLevel) || reorderLevel < 0)
            {
                MessageBox.Show("Reorder level must be a whole number, zero or more.",
                    "Wrong data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!ReadFields(out string name, out int categoryId,
                out decimal unitPrice, out int stockQuantity, out int reorderLevel))
            {
                return;
            }

            try
            {
                string sql = "INSERT INTO Products (ProductName, CategoryId, UnitPrice, " +
                    "StockQuantity, ReorderLevel) " +
                    "VALUES (@Name, @Category, @Price, @Stock, @Reorder);";
                int rows = DatabaseHelper.ExecuteNonQuery(sql,
                    new SqlParameter("@Name", name),
                    new SqlParameter("@Category", categoryId),
                    new SqlParameter("@Price", unitPrice),
                    new SqlParameter("@Stock", stockQuantity),
                    new SqlParameter("@Reorder", reorderLevel));
                lblStatus.Text = "Product added. Rows affected: " + rows;
                ClearFields();
                LoadProducts();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not add the product.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtProductId.Text.Trim() == "")
            {
                MessageBox.Show("Click a product in the grid first, then change its details.",
                    "No product selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!ReadFields(out string name, out int categoryId,
                out decimal unitPrice, out int stockQuantity, out int reorderLevel))
            {
                return;
            }

            try
            {
                string sql = "UPDATE Products SET ProductName = @Name, CategoryId = @Category, " +
                    "UnitPrice = @Price, StockQuantity = @Stock, ReorderLevel = @Reorder " +
                    "WHERE ProductId = @Id;";
                int rows = DatabaseHelper.ExecuteNonQuery(sql,
                    new SqlParameter("@Name", name),
                    new SqlParameter("@Category", categoryId),
                    new SqlParameter("@Price", unitPrice),
                    new SqlParameter("@Stock", stockQuantity),
                    new SqlParameter("@Reorder", reorderLevel),
                    new SqlParameter("@Id", int.Parse(txtProductId.Text.Trim())));
                lblStatus.Text = "Product updated. Rows affected: " + rows;
                ClearFields();
                LoadProducts();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not update the product.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (txtProductId.Text.Trim() == "")
            {
                MessageBox.Show("Click a product in the grid first.",
                    "No product selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult answer = MessageBox.Show(
                "Delete product '" + txtProductName.Text.Trim() + "'? " +
                "A product with purchases or sales cannot be deleted.",
                "Delete product", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer != DialogResult.Yes)
            {
                return;
            }

            try
            {
                string sql = "DELETE FROM Products WHERE ProductId = @Id;";
                int rows = DatabaseHelper.ExecuteNonQuery(sql,
                    new SqlParameter("@Id", int.Parse(txtProductId.Text.Trim())));
                lblStatus.Text = "Product deleted. Rows affected: " + rows;
                ClearFields();
                LoadProducts();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Could not delete the product. A product with purchases " +
                    "or sales cannot be deleted because the Purchases and Sales tables " +
                    "refer to it.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearFields();
            LoadProducts();
        }

        private void ClearFields()
        {
            txtProductId.Text = "";
            txtProductName.Text = "";
            txtUnitPrice.Text = "";
            txtStockQuantity.Text = "";
            txtReorderLevel.Text = "";
            if (cmbCategory.Items.Count > 0)
            {
                cmbCategory.SelectedIndex = 0;
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string keyword = txtSearch.Text.Trim();
            if (keyword == "")
            {
                LoadProducts();
                return;
            }

            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT p.ProductId, p.ProductName, c.CategoryName, " +
                    "p.UnitPrice, p.StockQuantity, p.ReorderLevel, p.CategoryId " +
                    "FROM Products p " +
                    "INNER JOIN Categories c ON p.CategoryId = c.CategoryId " +
                    "WHERE p.ProductName LIKE @Q " +
                    "ORDER BY p.ProductId;",
                    new SqlParameter("@Q", "%" + keyword + "%"));
                dgvProducts.DataSource = result;
                dgvProducts.Columns["CategoryId"].Visible = false;
                lblStatus.Text = result.Rows.Count + " products found for '" + keyword + "'.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Search failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadProducts();
        }

        // Open the SMS / WhatsApp form. From there the shopkeeper can
        // send a message to one number or to a contact group
        // ("All Customers" or "All Suppliers") by SMS (Twilio) or
        // WhatsApp (official WhatsApp Business API).
        private void btnCommunication_Click(object sender, EventArgs e)
        {
            using (CommunicationForm form = new CommunicationForm())
            {
                form.ShowDialog(this);
            }
        }

        // One-click offer: open the SMS / WhatsApp form pre-filled with
        // an offer message addressed to the "All Customers" group.
        // NOTE: the offer below is an EXAMPLE — change the discount text
        // to your own real offer before sending it to customers.
        private void btnSendOffer_Click(object sender, EventArgs e)
        {
            string offerText = "Example offer: 10% off on all grocery items this week";
            string message = "Special offer for our customers: " + offerText +
                " Visit us today! — General Store Management System";

            using (CommunicationForm form = new CommunicationForm())
            {
                form.Prefill("All Customers", message);
                form.ShowDialog(this);
            }
        }

        // Query 1: low stock products — stock at or below the reorder level.
        // Expected result: 3 rows — Rice (40 <= 50), Milk (30 <= 40),
        // Detergent (15 <= 25).
        private void btnLowStock_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT p.ProductId, p.ProductName, c.CategoryName, " +
                    "p.StockQuantity, p.ReorderLevel " +
                    "FROM Products p " +
                    "INNER JOIN Categories c ON p.CategoryId = c.CategoryId " +
                    "WHERE p.StockQuantity <= p.ReorderLevel " +
                    "ORDER BY p.ProductName;");
                dgvProducts.DataSource = result;
                lblStatus.Text = "Low stock products: " + result.Rows.Count + " found.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Query 2: daily sales for 2026-11-15.
        // Expected result: 4 sales, total 7220
        // (Rice 1600 + Sugar 1800 + Tea 1900 + Detergent 1920).
        private void btnDailySales_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT s.SaleId, c.FullName AS Customer, p.ProductName, " +
                    "s.Quantity, s.SalePrice, s.Quantity * s.SalePrice AS Amount " +
                    "FROM Sales s " +
                    "INNER JOIN Customers c ON s.CustomerId = c.CustomerId " +
                    "INNER JOIN Products p ON s.ProductId = p.ProductId " +
                    "WHERE s.SaleDate = '2026-11-15' " +
                    "ORDER BY s.SaleId;");
                dgvProducts.DataSource = result;
                lblStatus.Text = "Daily sales for 15 Nov 2026: 4 sales, total 7220.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Query 3: monthly sales for November 2026.
        // Expected result: 6 sales, total 10930
        // (1600 + 1800 + 1760 + 1900 + 1950 + 1920).
        private void btnMonthlySales_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT COUNT(s.SaleId) AS TotalSales, " +
                    "SUM(s.Quantity * s.SalePrice) AS MonthlyTotal " +
                    "FROM Sales s " +
                    "WHERE YEAR(s.SaleDate) = 2026 AND MONTH(s.SaleDate) = 11;");
                dgvProducts.DataSource = result;
                lblStatus.Text = "Monthly sales for November 2026: 6 sales, total 10930.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Query 4: profit per product — (sale price - purchase price)
        // multiplied by the total quantity sold.
        // Expected result: Rice 150, Milk 160, Tea 200, Detergent 200.
        // Sugar and Cooking Oil have no purchases, so the INNER JOIN
        // leaves them out of this result.
        private void btnProfit_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = DatabaseHelper.GetDataTable(
                    "SELECT p.ProductName, pu.PurchasePrice, s.SalePrice, " +
                    "SUM(s.Quantity) AS TotalSold, " +
                    "(s.SalePrice - pu.PurchasePrice) * SUM(s.Quantity) AS Profit " +
                    "FROM Sales s " +
                    "INNER JOIN Products p ON s.ProductId = p.ProductId " +
                    "INNER JOIN Purchases pu ON pu.ProductId = p.ProductId " +
                    "GROUP BY p.ProductName, pu.PurchasePrice, s.SalePrice " +
                    "ORDER BY Profit DESC;");
                dgvProducts.DataSource = result;
                lblStatus.Text = "Profit per product.";
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Query failed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
